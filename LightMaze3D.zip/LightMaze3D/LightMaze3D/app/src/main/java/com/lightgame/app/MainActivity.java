package com.lightgame.app;

import android.app.NativeActivity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

// النشاط الرئيسي: يشغّل كود C++ ويوفّر له رسم النص العربي والأيقونات والصوت
public class MainActivity extends NativeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    // ---------- نص (يدعم العربية والتشكيل) ----------
    // يرجع [عرض، ارتفاع، بكسلات ARGB ...]
    public int[] renderText(String s, float size, boolean bold) {
        try {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
            p.setTextSize(size);
            p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setColor(Color.WHITE);
            int w = (int) Math.ceil(p.measureText(s)) + 8;
            Paint.FontMetrics fm = p.getFontMetrics();
            int h = (int) Math.ceil(fm.descent - fm.ascent) + 6;
            if (w < 2) w = 2;
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.drawText(s, 4, 3 - fm.ascent, p);
            int[] out = new int[2 + w * h];
            out[0] = w;
            out[1] = h;
            bmp.getPixels(out, 2, w, 0, 0, w, h);
            bmp.recycle();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- أيقونات متجهة ----------
    public int[] renderIcon(int id, int size) {
        try {
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            float S = size;
            Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
            st.setColor(Color.WHITE);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeWidth(S * 0.09f);
            st.setStrokeCap(Paint.Cap.ROUND);
            st.setStrokeJoin(Paint.Join.ROUND);
            Paint fl = new Paint(Paint.ANTI_ALIAS_FLAG);
            fl.setColor(Color.WHITE);
            fl.setStyle(Paint.Style.FILL);
            switch (id) {
                case 0: // قائمة
                    for (int i = 0; i < 3; i++) c.drawLine(S * 0.2f, S * (0.3f + 0.2f * i), S * 0.8f, S * (0.3f + 0.2f * i), st);
                    break;
                case 1: { // مصباح
                    c.drawCircle(S * 0.5f, S * 0.4f, S * 0.22f, st);
                    c.drawLine(S * 0.4f, S * 0.74f, S * 0.6f, S * 0.74f, st);
                    c.drawLine(S * 0.43f, S * 0.85f, S * 0.57f, S * 0.85f, st);
                    c.drawLine(S * 0.5f, S * 0.62f, S * 0.5f, S * 0.74f, st);
                    break;
                }
                case 2:
                case 12: { // إعادة
                    RectF r = new RectF(S * 0.2f, S * 0.2f, S * 0.8f, S * 0.8f);
                    c.drawArc(r, -50, 290, false, st);
                    Path a = new Path();
                    a.moveTo(S * 0.64f, S * 0.14f);
                    a.lineTo(S * 0.84f, S * 0.30f);
                    a.lineTo(S * 0.58f, S * 0.36f);
                    a.close();
                    c.drawPath(a, fl);
                    break;
                }
                case 3:
                case 4: { // صوت
                    Path sp = new Path();
                    sp.moveTo(S * 0.18f, S * 0.4f);
                    sp.lineTo(S * 0.34f, S * 0.4f);
                    sp.lineTo(S * 0.52f, S * 0.24f);
                    sp.lineTo(S * 0.52f, S * 0.76f);
                    sp.lineTo(S * 0.34f, S * 0.6f);
                    sp.lineTo(S * 0.18f, S * 0.6f);
                    sp.close();
                    c.drawPath(sp, fl);
                    if (id == 3) {
                        c.drawArc(new RectF(S * 0.42f, S * 0.34f, S * 0.7f, S * 0.66f), -50, 100, false, st);
                        c.drawArc(new RectF(S * 0.42f, S * 0.22f, S * 0.86f, S * 0.78f), -50, 100, false, st);
                    } else {
                        c.drawLine(S * 0.62f, S * 0.38f, S * 0.86f, S * 0.62f, st);
                        c.drawLine(S * 0.86f, S * 0.38f, S * 0.62f, S * 0.62f, st);
                    }
                    break;
                }
                case 5: { // مكعب (زاوية الكاميرا)
                    Path h = new Path();
                    h.moveTo(S * 0.5f, S * 0.14f);
                    h.lineTo(S * 0.82f, S * 0.32f);
                    h.lineTo(S * 0.82f, S * 0.68f);
                    h.lineTo(S * 0.5f, S * 0.86f);
                    h.lineTo(S * 0.18f, S * 0.68f);
                    h.lineTo(S * 0.18f, S * 0.32f);
                    h.close();
                    c.drawPath(h, st);
                    c.drawLine(S * 0.18f, S * 0.32f, S * 0.5f, S * 0.5f, st);
                    c.drawLine(S * 0.82f, S * 0.32f, S * 0.5f, S * 0.5f, st);
                    c.drawLine(S * 0.5f, S * 0.5f, S * 0.5f, S * 0.86f, st);
                    break;
                }
                case 6: // رجوع
                    c.drawLine(S * 0.62f, S * 0.2f, S * 0.34f, S * 0.5f, st);
                    c.drawLine(S * 0.34f, S * 0.5f, S * 0.62f, S * 0.8f, st);
                    break;
                case 7:
                case 8: { // نجمة
                    Path p = new Path();
                    for (int i = 0; i < 10; i++) {
                        double a = -Math.PI / 2 + i * Math.PI / 5;
                        float r = (i % 2 == 0) ? S * 0.46f : S * 0.19f;
                        float x = S * 0.5f + (float) Math.cos(a) * r, y = S * 0.53f + (float) Math.sin(a) * r;
                        if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                    }
                    p.close();
                    if (id == 7) { c.drawPath(p, fl); } else { st.setStrokeWidth(S * 0.07f); c.drawPath(p, st); }
                    break;
                }
                case 9: { // قفل
                    c.drawRoundRect(new RectF(S * 0.24f, S * 0.44f, S * 0.76f, S * 0.84f), S * 0.08f, S * 0.08f, fl);
                    c.drawArc(new RectF(S * 0.31f, S * 0.14f, S * 0.69f, S * 0.7f), 180, 180, false, st);
                    c.drawLine(S * 0.31f, S * 0.42f, S * 0.31f, S * 0.46f, st);
                    c.drawLine(S * 0.69f, S * 0.42f, S * 0.69f, S * 0.46f, st);
                    break;
                }
                case 10: { // التالي
                    Path p = new Path();
                    p.moveTo(S * 0.35f, S * 0.2f);
                    p.lineTo(S * 0.8f, S * 0.5f);
                    p.lineTo(S * 0.35f, S * 0.8f);
                    p.close();
                    c.drawPath(p, fl);
                    break;
                }
                case 11: { // شبكة المراحل
                    float g = S * 0.06f;
                    c.drawRoundRect(new RectF(S * 0.18f, S * 0.18f, S * 0.46f, S * 0.46f), g, g, fl);
                    c.drawRoundRect(new RectF(S * 0.54f, S * 0.18f, S * 0.82f, S * 0.46f), g, g, fl);
                    c.drawRoundRect(new RectF(S * 0.18f, S * 0.54f, S * 0.46f, S * 0.82f), g, g, fl);
                    c.drawRoundRect(new RectF(S * 0.54f, S * 0.54f, S * 0.82f, S * 0.82f), g, g, fl);
                    break;
                }
                default: // جودة
                    c.drawCircle(S * 0.5f, S * 0.5f, S * 0.3f, st);
                    c.drawCircle(S * 0.5f, S * 0.5f, S * 0.1f, fl);
                    break;
            }
            int[] out = new int[2 + size * size];
            out[0] = size;
            out[1] = size;
            bmp.getPixels(out, 2, size, 0, 0, size, size);
            bmp.recycle();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------- صوت ----------
    public void playTone(final float hz, final int ms, final float vol, final int delay) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (delay > 0) Thread.sleep(delay);
                    int rate = 22050;
                    int n = rate * ms / 1000;
                    short[] buf = new short[n];
                    for (int i = 0; i < n; i++) {
                        double t = (double) i / rate;
                        double env = Math.min(1.0, i / (rate * 0.02)) * Math.exp(-3.5 * i / (double) n);
                        buf[i] = (short) (Math.sin(2 * Math.PI * hz * t) * env * vol * 32767 * 3);
                    }
                    AudioTrack tr = new AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC);
                    tr.write(buf, 0, n);
                    tr.play();
                    Thread.sleep(ms + 100);
                    tr.release();
                } catch (Throwable ignored) {
                }
            }
        }).start();
    }
}
