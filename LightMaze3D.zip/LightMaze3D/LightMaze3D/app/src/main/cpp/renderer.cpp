#include "renderer.h"
#include "shaders.h"
#include "log.h"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>

static const vec3 SUN_DIR_RAW = {-0.55f, 0.85f, -0.40f};

static inline vec3 Wp(double x, double y, float h) {
    return {(float)((x - 288.0) / 40.0), h, (float)((y - 280.0) / 40.0)};
}

// ---------------------------------------------------------------- GpuMesh
void GpuMesh::upload(const MeshData& m) {
    destroy();
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, m.v.size() * sizeof(float), m.v.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m.i.size() * sizeof(uint16_t), m.i.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (void*)12);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (void*)24);
    glBindVertexArray(0);
    count = (int)m.i.size();
}
void GpuMesh::draw() const {
    if (!vao || !count) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_SHORT, 0);
}
void GpuMesh::destroy() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ibo) glDeleteBuffers(1, &ibo);
    vao = vbo = ibo = 0;
    count = 0;
}

// ---------------------------------------------------------------- shaders
static GLuint compileShader(GLenum type, const std::string& src, const char* name) {
    GLuint s = glCreateShader(type);
    const char* c = src.c_str();
    glShaderSource(s, 1, &c, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[2048];
        glGetShaderInfoLog(s, sizeof(buf), nullptr, buf);
        LOGE("shader %s failed: %s", name, buf);
        glDeleteShader(s);
        return 0;
    }
    return s;
}
static bool makeProg(Prog& p, const std::string& vs, const std::string& fs, const char* name) {
    GLuint v = compileShader(GL_VERTEX_SHADER, vs, name);
    GLuint f = compileShader(GL_FRAGMENT_SHADER, fs, name);
    if (!v || !f) return false;
    GLuint id = glCreateProgram();
    glAttachShader(id, v);
    glAttachShader(id, f);
    glLinkProgram(id);
    GLint ok = 0;
    glGetProgramiv(id, GL_LINK_STATUS, &ok);
    glDeleteShader(v);
    glDeleteShader(f);
    if (!ok) {
        char buf[2048];
        glGetProgramInfoLog(id, sizeof(buf), nullptr, buf);
        LOGE("program %s link failed: %s", name, buf);
        return false;
    }
    p.id = id;
    p.cache.clear();
    return true;
}

bool Renderer::buildPrograms() {
    std::string common = FS_COMMON;
    bool ok = true;
    ok &= makeProg(pFloor_, VS_MESH, common + FS_FLOOR_MAIN, "floor");
    ok &= makeProg(pWall_, VS_MESH, common + FS_WALL_MAIN, "wall");
    ok &= makeProg(pObj_, VS_MESH, common + FS_OBJ_MAIN, "obj");
    ok &= makeProg(pMirror_, VS_MESH, common + FS_MIRROR_MAIN, "mirror");
    ok &= makeProg(pGlass_, VS_MESH, common + FS_GLASS_MAIN, "glass");
    ok &= makeProg(pShadow_, VS_SHADOW, FS_SHADOW, "shadow");
    ok &= makeProg(pBeam_, VS_FX, FS_BEAM, "beam");
    ok &= makeProg(pGlow_, VS_FX, FS_GLOW, "glow");
    ok &= makeProg(pStar_, VS_FX, FS_STAR, "star");
    ok &= makeProg(pBright_, VS_FULL, FS_BRIGHT, "bright");
    ok &= makeProg(pDown_, VS_FULL, FS_DOWN, "down");
    ok &= makeProg(pBlur_, VS_FULL, FS_BLUR, "blur");
    ok &= makeProg(pComp_, VS_FULL, FS_COMPOSITE, "composite");
    return ok;
}

// ---------------------------------------------------------------- init
float Renderer::rnd() {
    rng_ = rng_ * 1664525u + 1013904223u;
    return (float)((rng_ >> 8) & 0xFFFFFF) / 16777216.0f;
}

void Renderer::buildStaticMeshes() {
    // مرايا بطولين: 38 -> 0.95 ، 34 -> 0.85 (وحدات العالم)
    const float halfL[2] = {0.95f, 0.85f};
    for (int k = 0; k < 2; k++) {
        float L = halfL[k];
        MeshData g, f;
        addBox(g, {0, 0.55f, 0}, {L, 0.36f, 0.025f});
        addBox(f, {0, 0.55f + 0.36f + 0.03f, 0}, {L + 0.05f, 0.03f, 0.06f});
        addBox(f, {0, 0.55f - 0.36f - 0.03f, 0}, {L + 0.05f, 0.03f, 0.06f});
        addBox(f, {-L - 0.03f, 0.55f, 0}, {0.04f, 0.4f, 0.06f});
        addBox(f, {L + 0.03f, 0.55f, 0}, {0.04f, 0.4f, 0.06f});
        addSphere(f, {-L - 0.03f, 0.55f, 0.07f}, 0.05f, 8, 12);
        addSphere(f, {L + 0.03f, 0.55f, 0.07f}, 0.05f, 8, 12);
        mMirrorGlass_[k].upload(g);
        mMirrorFrame_[k].upload(f);
    }
    {
        MeshData m;
        addCyl(m, {0, 0, 0}, 0.34f, 0.27f, 0.11f, 28);
        addCyl(m, {0, 0.11f, 0}, 0.07f, 0.07f, 0.1f, 14, false);
        mPedestal_.upload(m);
    }
    { MeshData m; addTriPrism(m, {0, 0.1f, 0}, 0.6f, 0.9f); mPrism_.upload(m); }
    { MeshData m; addOcta(m, {0, 0, 0}, 0.26f, 0.42f, 0.26f); mCrystal_.upload(m); }
    {
        MeshData m;
        addCyl(m, {0, 0, 0}, 0.56f, 0.5f, 0.1f, 36);
        addCyl(m, {0, 0.1f, 0}, 0.44f, 0.38f, 0.1f, 36);
        mTargetBase_.upload(m);
    }
    { MeshData m; addTorus(m, {0, 0, 0}, 0.4f, 0.032f, 40, 8); mTargetRing_.upload(m); }
    { MeshData m; addTorus(m, {0, 0, 0}, 1.0f, 0.035f, 48, 8); mRing_.upload(m); }
    { MeshData m; addSphere(m, {0, 0, 0}, 1.0f, 14, 20); mSphere_.upload(m); }
    { MeshData m; addBox(m, {0, 0, 0}, {0.5f, 0.5f, 0.5f}); mUnitBox_.upload(m); }
    {
        MeshData m;
        addBox(m, {-0.6f, 0.55f, 0}, {0.5f, 0.3f, 0.34f});
        addBox(m, {-0.62f, 0.9f, 0}, {0.36f, 0.05f, 0.26f});
        addCylX(m, {0.0f, 0.55f, 0}, 0.14f, 0.28f, 20);
        mEmitter_.upload(m);
    }
    { MeshData m; addSphere(m, {0.08f, 0.55f, 0}, 0.11f, 10, 16); mLens_.upload(m); }
    {   // الأرضية والمنصّة
        MeshData fl;
        float e = 6.9f;
        meshFace(fl, {-e, 0, e}, {e, 0, e}, {e, 0, -e}, {-e, 0, -e}, {0, 1, 0});
        mFloor_.upload(fl);
        MeshData pl;
        addBox(pl, {0, -0.3f, 0}, {e, 0.298f, e});
        mPlatform_.upload(pl);
    }
    // غبار
    dust_.clear();
    for (int i = 0; i < 90; i++) dust_.push_back({{rnd(-6.2f, 6.2f), rnd(0.05f, 1.6f), rnd(-6.2f, 6.2f)}, rnd(0.02f, 0.07f), rnd(0, 6.28f)});
}

bool Renderer::createTargets() {
    // ---- الهدف الرئيسي (مع MSAA اختياري) ----
    sceneW_ = std::max(64, (int)(W_ * (quality_ == 0 ? 0.7f : (quality_ == 1 ? 0.85f : 1.0f))));
    sceneH_ = std::max(64, (int)(H_ * (quality_ == 0 ? 0.7f : (quality_ == 1 ? 0.85f : 1.0f))));
    int mx = std::max(sceneW_, sceneH_);
    if (mx > 2200) { float k = 2200.f / mx; sceneW_ = (int)(sceneW_ * k); sceneH_ = (int)(sceneH_ * k); }

    glGenTextures(1, &sceneTex_);
    glBindTexture(GL_TEXTURE_2D, sceneTex_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, sceneW_, sceneH_, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenRenderbuffers(1, &sceneDepth_);
    glBindRenderbuffer(GL_RENDERBUFFER, sceneDepth_);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, sceneW_, sceneH_);
    glGenFramebuffers(1, &sceneFbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, sceneFbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, sceneTex_, 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, sceneDepth_);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { LOGE("scene fbo incomplete"); return false; }

    samples_ = 0;
    if (quality_ >= 2) {
        GLint maxS = 0;
        glGetIntegerv(GL_MAX_SAMPLES, &maxS);
        int s = std::min(4, (int)maxS);
        if (s >= 2) {
            glGenRenderbuffers(1, &msColor_);
            glBindRenderbuffer(GL_RENDERBUFFER, msColor_);
            glRenderbufferStorageMultisample(GL_RENDERBUFFER, s, GL_RGBA8, sceneW_, sceneH_);
            glGenRenderbuffers(1, &msDepth_);
            glBindRenderbuffer(GL_RENDERBUFFER, msDepth_);
            glRenderbufferStorageMultisample(GL_RENDERBUFFER, s, GL_DEPTH_COMPONENT24, sceneW_, sceneH_);
            glGenFramebuffers(1, &msFbo_);
            glBindFramebuffer(GL_FRAMEBUFFER, msFbo_);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, msColor_);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, msDepth_);
            if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE) samples_ = s;
            else {
                LOGE("msaa fbo incomplete, disabling");
                glDeleteFramebuffers(1, &msFbo_); glDeleteRenderbuffers(1, &msColor_); glDeleteRenderbuffers(1, &msDepth_);
                msFbo_ = msColor_ = msDepth_ = 0;
            }
        }
    }

    // ---- الظلال ----
    shadowSize_ = quality_ == 0 ? 0 : (quality_ == 1 ? 1024 : 2048);
    if (shadowSize_ > 0) {
        glGenTextures(1, &shadowTex_);
        glBindTexture(GL_TEXTURE_2D, shadowTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
        glGenFramebuffers(1, &shadowFbo_);
        glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex_, 0);
        GLenum none = GL_NONE;
        glDrawBuffers(1, &none);
        glReadBuffer(GL_NONE);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
            LOGE("shadow fbo incomplete, disabling shadows");
            glDeleteFramebuffers(1, &shadowFbo_); glDeleteTextures(1, &shadowTex_);
            shadowFbo_ = shadowTex_ = 0; shadowSize_ = 0;
        }
    }

    // ---- التوهج (Bloom) ----
    bW_[0] = std::max(8, sceneW_ / 4); bH_[0] = std::max(8, sceneH_ / 4);
    bW_[1] = std::max(8, sceneW_ / 8); bH_[1] = std::max(8, sceneH_ / 8);
    for (int i = 0; i < 4; i++) {
        int lv = i / 2;
        glGenTextures(1, &bTex_[i]);
        glBindTexture(GL_TEXTURE_2D, bTex_[i]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, bW_[lv], bH_[lv], 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glGenFramebuffers(1, &bFbo_[i]);
        glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, bTex_[i], 0);
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) { LOGE("bloom fbo incomplete"); return false; }
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return true;
}

void Renderer::destroyTargets() {
    if (sceneFbo_) glDeleteFramebuffers(1, &sceneFbo_);
    if (sceneTex_) glDeleteTextures(1, &sceneTex_);
    if (sceneDepth_) glDeleteRenderbuffers(1, &sceneDepth_);
    if (msFbo_) glDeleteFramebuffers(1, &msFbo_);
    if (msColor_) glDeleteRenderbuffers(1, &msColor_);
    if (msDepth_) glDeleteRenderbuffers(1, &msDepth_);
    if (shadowFbo_) glDeleteFramebuffers(1, &shadowFbo_);
    if (shadowTex_) glDeleteTextures(1, &shadowTex_);
    for (int i = 0; i < 4; i++) {
        if (bFbo_[i]) glDeleteFramebuffers(1, &bFbo_[i]);
        if (bTex_[i]) glDeleteTextures(1, &bTex_[i]);
        bFbo_[i] = bTex_[i] = 0;
    }
    sceneFbo_ = sceneTex_ = sceneDepth_ = msFbo_ = msColor_ = msDepth_ = shadowFbo_ = shadowTex_ = 0;
}

bool Renderer::init(int w, int h, int quality) {
    W_ = w; H_ = h; quality_ = quality;
    ready_ = false;
    if (!buildPrograms()) return false;
    buildStaticMeshes();
    glGenVertexArrays(1, &emptyVao_);
    glGenVertexArrays(1, &fxVao_);
    glBindVertexArray(fxVao_);
    glGenBuffers(1, &fxVbo_);
    glBindBuffer(GL_ARRAY_BUFFER, fxVbo_);
    glBufferData(GL_ARRAY_BUFFER, 1024, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 36, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 36, (void*)12);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, 36, (void*)20);
    glBindVertexArray(0);
    // نسيج ظل وهمي (عندما تكون الظلال مطفأة)
    glGenTextures(1, &dummyShadow_);
    glBindTexture(GL_TEXTURE_2D, dummyShadow_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, 1, 1, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    if (!createTargets()) return false;
    ready_ = true;
    return true;
}

void Renderer::shutdown() {
    destroyTargets();
    GpuMesh* all[] = {&mWalls_, &mPlatform_, &mFloor_, &mUnitBox_, &mRing_, &mSphere_, &mMirrorGlass_[0], &mMirrorGlass_[1],
                      &mMirrorFrame_[0], &mMirrorFrame_[1], &mPedestal_, &mBolt_, &mPrism_, &mCrystal_, &mTargetBase_,
                      &mTargetRing_, &mEmitter_, &mLens_, &mGlassZone_};
    for (auto* m : all) m->destroy();
    Prog* ps[] = {&pFloor_, &pWall_, &pObj_, &pMirror_, &pGlass_, &pShadow_, &pBeam_, &pGlow_, &pStar_, &pBright_, &pDown_, &pBlur_, &pComp_};
    for (auto* p : ps) { if (p->id) glDeleteProgram(p->id); p->id = 0; p->cache.clear(); }
    if (fxVbo_) glDeleteBuffers(1, &fxVbo_);
    if (fxVao_) glDeleteVertexArrays(1, &fxVao_);
    if (emptyVao_) glDeleteVertexArrays(1, &emptyVao_);
    if (dummyShadow_) glDeleteTextures(1, &dummyShadow_);
    fxVbo_ = fxVao_ = emptyVao_ = dummyShadow_ = 0;
    ready_ = false;
}

void Renderer::resize(int w, int h) {
    if (w == W_ && h == H_) return;
    W_ = w; H_ = h;
    if (!ready_) return;
    destroyTargets();
    createTargets();
}

void Renderer::setQuality(int q) {
    if (q == quality_) return;
    quality_ = q;
    if (!ready_) return;
    destroyTargets();
    createTargets();
}

void Renderer::setBoard(const Board* B) {
    board_ = B;
    mWalls_.destroy();
    mGlassZone_.destroy();
    parts_.clear();
    if (!B) return;
    MeshData m;
    const float ht = 0.85f, hw = 0.15f;
    auto addWall = [&](const Seg4& s, bool border) {
        float x1 = (float)((s.x1 - 288) / 40), x2 = (float)((s.x2 - 288) / 40);
        float z1 = (float)((s.y1 - 280) / 40), z2 = (float)((s.y2 - 280) / 40);
        float ext = border ? hw : 0.0f;
        float cx = (x1 + x2) * 0.5f, cz = (z1 + z2) * 0.5f;
        float hx = std::fabs(x2 - x1) * 0.5f, hz = std::fabs(z2 - z1) * 0.5f;
        if (hx >= hz) { hx += ext; hz = hw; } else { hz += ext; hx = hw; }
        addBox(m, {cx, ht * 0.5f, cz}, {hx, ht * 0.5f, hz});
    };
    for (int i = 0; i < 4; i++) addWall(BORDERS[i], true);
    for (const auto& w : B->walls) addWall(w, false);
    mWalls_.upload(m);
    if (!B->glass.empty()) {
        MeshData g;
        for (const auto& r : B->glass) {
            float x0 = (float)((r.x1 - 288) / 40), z0 = (float)((r.y1 - 280) / 40);
            float x1 = (float)((r.x1 + r.x2 - 288) / 40), z1 = (float)((r.y1 + r.y2 - 280) / 40);
            addBox(g, {(x0 + x1) * 0.5f, 0.05f, (z0 + z1) * 0.5f}, {(x1 - x0) * 0.5f, 0.05f, (z1 - z0) * 0.5f});
        }
        mGlassZone_.upload(g);
    }
}

// ---------------------------------------------------------------- الكاميرا
static void projExtents(const mat4& vp, float hx, float hz, float hy, float& x0, float& x1, float& y0, float& y1, bool& ok) {
    x0 = y0 = 1e9f; x1 = y1 = -1e9f; ok = true;
    for (int i = 0; i < 8; i++) {
        vec3 p = {(i & 1) ? hx : -hx, (i & 2) ? hy : 0.f, (i & 4) ? hz : -hz};
        float sx, sy;
        if (!project4(vp, p, sx, sy)) { ok = false; return; }
        x0 = std::min(x0, sx); x1 = std::max(x1, sx);
        y0 = std::min(y0, sy); y1 = std::max(y1, sy);
    }
}

void Renderer::updateCamera(const SceneState& s) {
    float aspect = (float)W_ / (float)std::max(1, H_);
    float fov = 0.62f;
    pitchTarget_ = s.menuMode ? 40.f : s.pitchDeg;
    pitchCur_ += (pitchTarget_ - pitchCur_) * std::min(1.f, s.dt * 6.f);
    float pitch = pitchCur_ * 3.14159265f / 180.f;
    float sway = s.menuMode ? 0.f : (s.dragMode ? 0.f : 1.f);
    static float swayAmt = 1.f;
    swayAmt += (sway - swayAmt) * std::min(1.f, s.dt * 3.f);
    float yaw = s.menuMode ? s.t * 0.10f : std::sin(s.t * 0.32f) * 0.05f * swayAmt;
    camYaw_ = yaw;
    float pitchEff = pitch + (s.menuMode ? 0.f : std::sin(s.t * 0.27f) * 0.012f * swayAmt);
    proj_ = perspective(fov, aspect, 0.5f, 140.f);
    vec3 tgt = s.menuMode ? vec3(0, 0.1f, 0) : camTarget_;
    auto viewFor = [&](float d) {
        vec3 dir = {std::sin(yaw) * std::cos(pitchEff), std::sin(pitchEff), std::cos(yaw) * std::cos(pitchEff)};
        return lookAt(tgt + dir * d, tgt, {0, 1, 0});
    };
    if (s.menuMode) {
        camDist_ = 19.f * (aspect < 1 ? 1.35f : 1.f);
    } else {
        float yTop = 1.f - 2.f * s.uiTopPx / std::max(1, H_);
        float yBot = -1.f + 2.f * s.uiBottomPx / std::max(1, H_);
        if (yTop - yBot < 0.5f) { yTop = 0.85f; yBot = -0.85f; }
        float lo = 6.f, hi = 90.f;
        for (int it = 0; it < 28; it++) {
            float mid = (lo + hi) * 0.5f;
            mat4 v = viewFor(mid), vpp = mul(proj_, v);
            float x0, x1, y0, y1; bool ok;
            projExtents(vpp, 6.6f, 6.6f, 1.0f, x0, x1, y0, y1, ok);
            bool fits = ok && (x1 - x0) <= 1.92f && (y1 - y0) <= (yTop - yBot);
            if (fits) hi = mid; else lo = mid;
        }
        camDist_ = hi;
        mat4 v = viewFor(camDist_), vpp = mul(proj_, v);
        float x0, x1, y0, y1; bool ok;
        projExtents(vpp, 6.6f, 6.6f, 1.0f, x0, x1, y0, y1, ok);
        float shiftX = -(x0 + x1) * 0.5f;
        float shiftY = (yTop + yBot) * 0.5f - (y0 + y1) * 0.5f;
        proj_.m[8] = -shiftX;
        proj_.m[9] = -shiftY;
    }
    view_ = viewFor(camDist_);
    vec3 dir = {std::sin(yaw) * std::cos(pitchEff), std::sin(pitchEff), std::cos(yaw) * std::cos(pitchEff)};
    camEye_ = tgt + dir * camDist_;
    vp_ = mul(proj_, view_);
    if (!invert4(vp_, invVp_)) invVp_ = identity4();
    // مصفوفة الضوء
    vec3 sun = normalize(SUN_DIR_RAW);
    mat4 lv = lookAt(sun * 24.f, {0, 0, 0}, {0, 0, 1});
    lightVP_ = mul(ortho(-9.6f, 9.6f, -9.6f, 9.6f, 2.f, 50.f), lv);
}

bool Renderer::screenToPlay(float sx, float sy, float planeY, double& px, double& py) const {
    if (W_ <= 0 || H_ <= 0) return false;
    float nx = sx / W_ * 2.f - 1.f, ny = 1.f - sy / H_ * 2.f;
    vec3 a = unprojectPoint(invVp_, nx, ny, -1.f), b = unprojectPoint(invVp_, nx, ny, 1.f);
    vec3 d = b - a;
    if (std::fabs(d.y) < 1e-6f) return false;
    float t = (planeY - a.y) / d.y;
    vec3 p = a + d * t;
    px = p.x * 40.0 + 288.0;
    py = p.z * 40.0 + 280.0;
    return true;
}

// ---------------------------------------------------------------- الأضواء والمؤثرات
static void beamPalette(char c, float halo[3], float light[3], float& strength) {
    switch (c) {
        case 'r': halo[0] = 1.0f; halo[1] = 0.26f; halo[2] = 0.10f; light[0] = 1.0f; light[1] = 0.30f; light[2] = 0.12f; strength = 1.25f; break;
        case 'g': halo[0] = 0.18f; halo[1] = 1.0f; halo[2] = 0.40f; light[0] = 0.25f; light[1] = 1.0f; light[2] = 0.40f; strength = 1.25f; break;
        case 'b': halo[0] = 0.26f; halo[1] = 0.50f; halo[2] = 1.0f; light[0] = 0.30f; light[1] = 0.50f; light[2] = 1.0f; strength = 1.25f; break;
        default:  halo[0] = 0.62f; halo[1] = 0.76f; halo[2] = 1.0f; light[0] = 1.0f; light[1] = 0.88f; light[2] = 0.72f; strength = 1.7f; break;
    }
}
static void targetColor(char c, float k[3]) {
    switch (c) {
        case 'r': k[0] = 1.0f; k[1] = 0.32f; k[2] = 0.14f; break;
        case 'g': k[0] = 0.30f; k[1] = 1.0f; k[2] = 0.55f; break;
        case 'b': k[0] = 0.32f; k[1] = 0.58f; k[2] = 1.0f; break;
        default:  k[0] = 0.50f; k[1] = 0.66f; k[2] = 1.0f; break;
    }
}

void Renderer::collectLights(const SceneState& s) {
    nSeg_ = 0;
    if (!s.B) return;
    auto push = [&](vec3 a, vec3 b, const float* c, float st) {
        if (nSeg_ >= 32) return;
        int i = nSeg_++;
        segA_[i * 4] = a.x; segA_[i * 4 + 1] = a.y; segA_[i * 4 + 2] = a.z; segA_[i * 4 + 3] = 0;
        segB_[i * 4] = b.x; segB_[i * 4 + 1] = b.y; segB_[i * 4 + 2] = b.z; segB_[i * 4 + 3] = 0;
        segC_[i * 4] = c[0]; segC_[i * 4 + 1] = c[1]; segC_[i * 4 + 2] = c[2]; segC_[i * 4 + 3] = st;
    };
    float by = beamY();
    // المرسل
    vec3 e = Wp(s.B->ex, s.B->ey, by);
    float ec[3] = {1.0f, 0.85f, 0.6f};
    push(e, e, ec, 0.9f);
    // الأهداف المضيئة
    for (const auto& t : s.B->T) {
        if (t.v < 0.02f) continue;
        float k[3]; targetColor(t.c, k);
        float c[3] = {k[0] * t.v, k[1] * t.v, k[2] * t.v};
        vec3 p = Wp(t.x, t.y, 0.8f);
        push(p, p, c, 1.8f);
    }
    if (!s.R) return;
    int budget = 32 - nSeg_;
    for (const auto& poly : s.R->polys) {
        float halo[3], lc[3], st;
        beamPalette(poly.c, halo, lc, st);
        for (size_t i = 1; i < poly.pts.size() && budget > 0; i++) {
            vec3 a = Wp(poly.pts[i - 1].x, poly.pts[i - 1].y, by), b = Wp(poly.pts[i].x, poly.pts[i].y, by);
            if (length(b - a) < 1e-3f) continue;
            push(a, b, lc, st);
            budget--;
        }
    }
}

void Renderer::addRibbon(std::vector<float>& v, vec3 a, vec3 b, float hw, const float* col, float fa, float fb) {
    vec3 mid = (a + b) * 0.5f;
    vec3 ab = b - a;
    vec3 side = cross(ab, camEye_ - mid);
    if (length(side) < 1e-5f) side = cross(ab, vec3(0, 1, 0));
    side = normalize(side) * hw;
    float len = length(ab);
    auto vtx = [&](vec3 p, float u, float w, float alpha) {
        v.push_back(p.x); v.push_back(p.y); v.push_back(p.z);
        v.push_back(u); v.push_back(w);
        v.push_back(col[0]); v.push_back(col[1]); v.push_back(col[2]); v.push_back(col[3] * alpha);
    };
    // رباعي = مثلثان
    vtx(a - side, -1, 0, fa); vtx(a + side, 1, 0, fa); vtx(b + side, 1, len, fb);
    vtx(a - side, -1, 0, fa); vtx(b + side, 1, len, fb); vtx(b - side, -1, len, fb);
}

void Renderer::addSprite(std::vector<float>& v, vec3 c, float size, const float* col, float rot) {
    vec3 r = {view_.m[0], view_.m[4], view_.m[8]}, u = {view_.m[1], view_.m[5], view_.m[9]};
    float cs = std::cos(rot), sn = std::sin(rot);
    vec3 rr = r * cs + u * sn, uu = u * cs - r * sn;
    vec3 p[4] = {c - rr * size - uu * size, c + rr * size - uu * size, c + rr * size + uu * size, c - rr * size + uu * size};
    float uv[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
    int idx[6] = {0, 1, 2, 0, 2, 3};
    for (int k = 0; k < 6; k++) {
        int i = idx[k];
        v.push_back(p[i].x); v.push_back(p[i].y); v.push_back(p[i].z);
        v.push_back(uv[i][0]); v.push_back(uv[i][1]);
        v.push_back(col[0]); v.push_back(col[1]); v.push_back(col[2]); v.push_back(col[3]);
    }
}

void Renderer::burst(vec3 pos, vec3 col, int n, float speed) {
    for (int i = 0; i < n; i++) {
        float a = rnd(0, 6.2831f), el = rnd(0.2f, 1.2f);
        float sp = speed * rnd(0.4f, 1.0f);
        Particle p;
        p.p = pos;
        p.v = {std::cos(a) * std::cos(el) * sp, std::sin(el) * sp, std::sin(a) * std::cos(el) * sp};
        p.col = col;
        p.maxLife = rnd(0.8f, 1.8f);
        p.life = p.maxLife;
        p.size = rnd(0.05f, 0.12f);
        if (parts_.size() < 600) parts_.push_back(p);
    }
}

void Renderer::update(const SceneState& s) {
    float dt = std::min(0.05f, s.dt);
    // جسيمات
    for (auto& p : parts_) {
        p.p = p.p + p.v * dt;
        p.v.y -= 2.4f * dt;
        p.v = p.v * (1.f - 0.6f * dt);
        if (p.p.y < 0.02f) { p.p.y = 0.02f; p.v.y *= -0.35f; }
        p.life -= dt;
    }
    parts_.erase(std::remove_if(parts_.begin(), parts_.end(), [](const Particle& p) { return p.life <= 0; }), parts_.end());
    if (s.R && s.B) {
        for (const auto& poly : s.R->polys) {
            if (poly.pts.size() < 2) continue;
            const TracePt& e = poly.pts.back();
            if ((e.kind == 'w' || e.kind == 'e') && rnd() < dt * 22.f) {
                float halo[3], lc[3], st; beamPalette(poly.c, halo, lc, st);
                vec3 pos = Wp(e.x, e.y, beamY());
                const TracePt& pr = poly.pts[poly.pts.size() - 2];
                vec3 back = normalize(Wp(pr.x, pr.y, 0) - Wp(e.x, e.y, 0));
                Particle p;
                p.p = pos;
                float sp = rnd(0.8f, 2.6f);
                p.v = back * sp + vec3(rnd(-0.8f, 0.8f), rnd(0.4f, 2.0f), rnd(-0.8f, 0.8f));
                p.col = {lc[0], lc[1], lc[2]};
                p.maxLife = rnd(0.35f, 0.8f);
                p.life = p.maxLife;
                p.size = rnd(0.03f, 0.07f);
                if (parts_.size() < 600) parts_.push_back(p);
            }
        }
        for (const auto& t : s.B->T) {
            if (t.v > 0.5f && rnd() < dt * 8.f) {
                float k[3]; targetColor(t.c, k);
                Particle p;
                p.p = Wp(t.x, t.y, 0.9f) + vec3(rnd(-0.25f, 0.25f), 0, rnd(-0.25f, 0.25f));
                p.v = {rnd(-0.2f, 0.2f), rnd(0.6f, 1.4f), rnd(-0.2f, 0.2f)};
                p.col = {k[0], k[1], k[2]};
                p.maxLife = rnd(0.8f, 1.6f);
                p.life = p.maxLife;
                p.size = rnd(0.03f, 0.06f);
                if (parts_.size() < 600) parts_.push_back(p);
            }
        }
    }
    for (auto& d : dust_) {
        d.p.y += d.s * dt;
        d.p.x += std::sin(s.t * 0.6f + d.ph) * 0.12f * dt;
        d.p.z += std::cos(s.t * 0.5f + d.ph * 1.3f) * 0.12f * dt;
        if (d.p.y > 1.7f) { d.p.y = 0.05f; d.p.x = rnd(-6.2f, 6.2f); d.p.z = rnd(-6.2f, 6.2f); }
    }
}

void Renderer::collectFx(const SceneState& s) {
    fxBeam_.clear(); fxGlow_.clear(); fxStar_.clear();
    if (!s.B) return;
    float by = beamY();
    if (s.R) {
        for (const auto& poly : s.R->polys) {
            float halo[3], lc[3], st; beamPalette(poly.c, halo, lc, st);
            float col[4] = {halo[0], halo[1], halo[2], poly.c == 'w' ? 1.0f : 0.9f};
            for (size_t i = 1; i < poly.pts.size(); i++) {
                vec3 a = Wp(poly.pts[i - 1].x, poly.pts[i - 1].y, by), b = Wp(poly.pts[i].x, poly.pts[i].y, by);
                if (length(b - a) < 1e-3f) continue;
                addRibbon(fxBeam_, a, b, 0.26f, col, 1.f, 1.f);
            }
            for (size_t i = 1; i < poly.pts.size(); i++) {
                vec3 p = Wp(poly.pts[i].x, poly.pts[i].y, by);
                bool last = i + 1 == poly.pts.size();
                char kind = poly.pts[i].kind;
                float gc[4] = {halo[0], halo[1], halo[2], last ? 0.8f : 0.5f};
                addSprite(fxGlow_, p, last ? 0.75f : 0.5f, gc);
                float wc[4] = {1.f, 1.f, 1.f, kind == 'e' ? 0.55f : 0.4f};
                addSprite(fxGlow_, p, 0.2f, wc);
                if (kind == 'e' || kind == 'p') {
                    float sc[4] = {lc[0], lc[1], lc[2], 0.55f};
                    addSprite(fxStar_, p, 0.9f, sc, s.t * 0.15f);
                }
            }
        }
    }
    // المرسل
    {
        vec3 e = Wp(s.B->ex, s.B->ey, by);
        float c[4] = {1.f, 0.85f, 0.6f, 0.9f};
        addSprite(fxGlow_, e, 0.8f, c);
        float w[4] = {1, 1, 1, 0.8f};
        addSprite(fxGlow_, e, 0.25f, w);
        float sc[4] = {1.f, 0.9f, 0.7f, 0.5f};
        addSprite(fxStar_, e, 1.0f, sc, s.t * 0.1f);
    }
    // الأهداف: هالة + شعاع عمودي عند الإضاءة
    for (const auto& t : s.B->T) {
        float k[3]; targetColor(t.c, k);
        vec3 p = Wp(t.x, t.y, 0.82f);
        float a = 0.25f + 0.75f * t.v;
        float c[4] = {k[0], k[1], k[2], 0.35f * a};
        addSprite(fxGlow_, p, 1.2f + 0.8f * t.v, c);
        if (t.v > 0.05f) {
            float w[4] = {1, 1, 1, 0.5f * t.v};
            addSprite(fxGlow_, p, 0.45f, w);
            float col[4] = {k[0], k[1], k[2], 0.55f * t.v};
            addRibbon(fxBeam_, Wp(t.x, t.y, 0.85f), Wp(t.x, t.y, 0.85f) + vec3(0, 3.6f, 0), 0.42f, col, 1.0f, 0.0f);
            float sc[4] = {k[0], k[1], k[2], 0.55f * t.v};
            addSprite(fxStar_, p, 1.3f, sc, s.t * 0.4f);
        }
    }
    // مقبض التدوير والعنصر المحدّد
    if (s.sel >= 0 && s.sel < (int)s.B->els.size() && !s.menuMode) {
        const Element& e = s.B->els[s.sel];
        vec3 h = Wp(e.x + std::cos(e.a - 1.5707963) * 52, e.y + std::sin(e.a - 1.5707963) * 52, by);
        float c[4] = {1.0f, 0.62f, 0.2f, 0.8f};
        addSprite(fxGlow_, h, 0.5f, c);
    }
    // غبار متفاعل مع الشعاع
    for (const auto& d : dust_) {
        float near = 1e9f;
        if (s.R)
            for (const auto& poly : s.R->polys)
                for (size_t i = 1; i < poly.pts.size(); i++) {
                    vec3 a = Wp(poly.pts[i - 1].x, poly.pts[i - 1].y, by), b = Wp(poly.pts[i].x, poly.pts[i].y, by);
                    vec3 ab = b - a;
                    float l2 = dot(ab, ab);
                    float t = l2 > 1e-6f ? clampf(dot(d.p - a, ab) / l2, 0, 1) : 0;
                    near = std::min(near, length(a + ab * t - d.p));
                }
        float al = near < 1.4f ? 0.55f * (1.f - near / 1.4f) + 0.05f : 0.05f;
        float c[4] = {0.75f, 0.85f, 1.0f, al};
        addSprite(fxGlow_, d.p, 0.05f + d.s * 0.4f, c);
    }
    for (const auto& p : parts_) {
        float k = p.life / p.maxLife;
        float c[4] = {p.col.x, p.col.y, p.col.z, std::min(1.f, k * 1.4f)};
        addSprite(fxGlow_, p.p, p.size * (0.6f + 0.6f * k) * 2.2f, c);
    }
}

// ---------------------------------------------------------------- رسم
void Renderer::setModelUniform(Prog& p, const mat4& m) { glUniformMatrix4fv(p.u("uModel"), 1, GL_FALSE, m.m); }
void Renderer::drawMesh(Prog& p, const GpuMesh& m, const mat4& model) {
    setModelUniform(p, model);
    m.draw();
}

void Renderer::setLit(Prog& p, const SceneState& s) {
    glUseProgram(p.id);
    glUniformMatrix4fv(p.u("uVP"), 1, GL_FALSE, vp_.m);
    glUniform3f(p.u("uCam"), camEye_.x, camEye_.y, camEye_.z);
    vec3 sun = normalize(SUN_DIR_RAW);
    glUniform3f(p.u("uSunDir"), sun.x, sun.y, sun.z);
    glUniform3f(p.u("uSunCol"), 0.40f, 0.47f, 0.80f);
    glUniform3f(p.u("uAmbSky"), 0.06f, 0.085f, 0.17f);
    glUniform3f(p.u("uAmbGnd"), 0.035f, 0.045f, 0.085f);
    glUniform1i(p.u("uNSeg"), nSeg_);
    if (nSeg_ > 0) {
        glUniform4fv(p.u("uSegA"), nSeg_, segA_);
        glUniform4fv(p.u("uSegB"), nSeg_, segB_);
        glUniform4fv(p.u("uSegC"), nSeg_, segC_);
    }
    glUniformMatrix4fv(p.u("uLightVP"), 1, GL_FALSE, lightVP_.m);
    float ts = shadowSize_ > 0 ? 1.0f / shadowSize_ : 0.001f;
    glUniform2f(p.u("uShadowTexel"), ts, ts);
    glUniform1f(p.u("uShadowOn"), shadowSize_ > 0 ? 1.f : 0.f);
    glUniform1f(p.u("uTime"), s.t);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, shadowSize_ > 0 ? shadowTex_ : dummyShadow_);
    glUniform1i(p.u("uShadow"), 5);
    glActiveTexture(GL_TEXTURE0);
}

static void setObj(Prog& p, vec3 alb, float metal, float rough, vec3 emis, vec3 rim = {0, 0, 0}) {
    glUniform3f(p.u("uAlbedo"), alb.x, alb.y, alb.z);
    glUniform1f(p.u("uMetal"), metal);
    glUniform1f(p.u("uRough"), rough);
    glUniform3f(p.u("uEmis"), emis.x, emis.y, emis.z);
    glUniform3f(p.u("uRim"), rim.x, rim.y, rim.z);
}
static void setGlass(Prog& p, vec3 tint, float alpha, float glow, float rainbow, float stripe) {
    glUniform3f(p.u("uTint"), tint.x, tint.y, tint.z);
    glUniform1f(p.u("uAlpha"), alpha);
    glUniform1f(p.u("uGlow"), glow);
    glUniform1f(p.u("uRainbow"), rainbow);
    glUniform1f(p.u("uStripe"), stripe);
}
static inline int lenIdx(const Element& e) { return e.len > 36 ? 0 : 1; }

void Renderer::drawShadowPass(const SceneState& s) {
    if (shadowSize_ <= 0 || !s.B) return;
    glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
    glViewport(0, 0, shadowSize_, shadowSize_);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(2.0f, 4.0f);
    glUseProgram(pShadow_.id);
    glUniformMatrix4fv(pShadow_.u("uLightVP"), 1, GL_FALSE, lightVP_.m);
    mat4 I = identity4();
    drawMesh(pShadow_, mWalls_, I);
    for (const auto& e : s.B->els) {
        mat4 m = modelYaw(Wp(e.x, e.y, 0), (float)e.a);
        drawMesh(pShadow_, mPedestal_, m);
        if (e.prism) drawMesh(pShadow_, mPrism_, m);
        else {
            drawMesh(pShadow_, mMirrorGlass_[lenIdx(e)], m);
            drawMesh(pShadow_, mMirrorFrame_[lenIdx(e)], m);
        }
    }
    for (const auto& t : s.B->T) drawMesh(pShadow_, mTargetBase_, translate4(Wp(t.x, t.y, 0)));
    float ang = (float)std::atan2(s.B->edy, s.B->edx);
    drawMesh(pShadow_, mEmitter_, modelYaw(Wp(s.B->ex, s.B->ey, 0), ang));
    glDisable(GL_POLYGON_OFFSET_FILL);
}

void Renderer::drawElementsOpaque(const SceneState& s, bool) {
    const Board& B = *s.B;
    // العناصر
    for (size_t i = 0; i < B.els.size(); i++) {
        const Element& e = B.els[i];
        mat4 m = modelYaw(Wp(e.x, e.y, 0), (float)e.a);
        bool selected = (int)i == s.sel && !s.menuMode;
        glUseProgram(pObj_.id);
        setObj(pObj_, {0.10f, 0.115f, 0.15f}, 0.85f, 0.35f, {0, 0, 0});
        drawMesh(pObj_, mPedestal_, modelYaw(Wp(e.x, e.y, 0), 0));
        if (e.prism) continue;
        vec3 frame = e.split ? vec3(0.22f, 0.62f, 0.68f) : (e.fixed ? vec3(0.62f, 0.42f, 0.20f) : vec3(0.60f, 0.68f, 0.84f));
        vec3 rim = selected ? vec3(0.55f, 0.28f, 0.04f) : vec3(0, 0, 0);
        setObj(pObj_, frame, 0.9f, 0.25f, {0, 0, 0}, rim);
        drawMesh(pObj_, mMirrorFrame_[lenIdx(e)], m);
        if (!e.split) {
            glUseProgram(pMirror_.id);
            glUniform3f(pMirror_.u("uRim"), rim.x * 0.8f, rim.y * 0.8f, rim.z * 0.8f);
            drawMesh(pMirror_, mMirrorGlass_[lenIdx(e)], m);
        }
    }
}

void Renderer::drawElementsTransparent(const SceneState& s) {
    const Board& B = *s.B;
    // مناطق الزجاج
    if (mGlassZone_.count) {
        glUseProgram(pGlass_.id);
        setGlass(pGlass_, {0.30f, 0.62f, 1.0f}, 0.30f, 0.05f, 0.f, 0.35f);
        drawMesh(pGlass_, mGlassZone_, identity4());
    }
    for (size_t i = 0; i < B.els.size(); i++) {
        const Element& e = B.els[i];
        mat4 m = modelYaw(Wp(e.x, e.y, 0), (float)e.a);
        if (e.prism) {
            glUseProgram(pGlass_.id);
            setGlass(pGlass_, {0.65f, 0.82f, 1.0f}, 0.22f, 0.04f, 1.0f, 0.f);
            drawMesh(pGlass_, mPrism_, m);
        } else if (e.split) {
            glUseProgram(pGlass_.id);
            setGlass(pGlass_, {0.30f, 0.90f, 1.0f}, 0.42f, 0.12f, 0.f, 1.0f);
            drawMesh(pGlass_, mMirrorGlass_[lenIdx(e)], m);
        }
    }
    // بلّورات الأهداف
    for (const auto& t : B.T) {
        float k[3]; targetColor(t.c, k);
        float bob = 0.05f * std::sin(s.t * 1.7f + (float)t.x);
        mat4 m = mul(translate4(Wp(t.x, t.y, 0.82f + bob)), mul(rotY(s.t * (0.5f + 1.5f * t.v)), rotZ(0.12f * std::sin(s.t))));
        glUseProgram(pGlass_.id);
        setGlass(pGlass_, {k[0], k[1], k[2]}, 0.55f, 0.35f + 2.4f * t.v, 0.f, 0.f);
        drawMesh(pGlass_, mCrystal_, m);
    }
    // أشباح التلميح
    if (s.hint > 0.01f) {
        float pulse = 0.55f + 0.45f * std::sin(s.t * 6.f);
        for (const auto& e : B.els) {
            if (e.fixed) continue;
            mat4 m = modelYaw(Wp(e.sx, e.sy, 0), (float)e.sa);
            glUseProgram(pGlass_.id);
            setGlass(pGlass_, {0.2f, 1.0f, 0.6f}, 0.35f * s.hint, (0.6f + 0.8f * pulse) * s.hint, 0.f, 0.f);
            if (e.prism) drawMesh(pGlass_, mPrism_, m);
            else drawMesh(pGlass_, mMirrorGlass_[lenIdx(e)], m);
        }
    }
}

void Renderer::flushBatch(std::vector<float>& v, Prog& p, const SceneState& s) {
    if (v.empty()) return;
    glUseProgram(p.id);
    glUniformMatrix4fv(p.u("uVP"), 1, GL_FALSE, vp_.m);
    glUniform1f(p.u("uTime"), s.t);
    glBindVertexArray(fxVao_);
    glBindBuffer(GL_ARRAY_BUFFER, fxVbo_);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(float), v.data(), GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(v.size() / 9));
}

void Renderer::drawScene(const SceneState& s) {
    GLuint fbo = samples_ > 0 ? msFbo_ : sceneFbo_;
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(0, 0, sceneW_, sceneH_);
    glClearColor(0.006f, 0.010f, 0.022f, 1.f);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    if (!s.B) return;
    const Board& B = *s.B;
    mat4 I = identity4();

    setLit(pFloor_, s);
    drawMesh(pFloor_, mFloor_, I);
    setLit(pWall_, s);
    drawMesh(pWall_, mPlatform_, I);
    drawMesh(pWall_, mWalls_, I);

    setLit(pObj_, s);
    setLit(pMirror_, s);
    setLit(pGlass_, s);
    glUseProgram(pObj_.id);

    // المرسل
    float ang = (float)std::atan2(B.edy, B.edx);
    mat4 em = modelYaw(Wp(B.ex, B.ey, 0), ang);
    setObj(pObj_, {0.13f, 0.14f, 0.18f}, 0.85f, 0.3f, {0, 0, 0});
    drawMesh(pObj_, mEmitter_, em);
    setObj(pObj_, {0, 0, 0}, 0.0f, 0.5f, {2.2f, 1.9f, 1.4f});
    drawMesh(pObj_, mLens_, em);

    // قواعد الأهداف + حلقاتها
    for (const auto& t : B.T) {
        float k[3]; targetColor(t.c, k);
        vec3 p = Wp(t.x, t.y, 0);
        setObj(pObj_, {0.20f, 0.23f, 0.31f}, 0.25f, 0.55f, {0, 0, 0});
        drawMesh(pObj_, mTargetBase_, translate4(p));
        float em1 = 0.35f + 1.8f * t.v;
        setObj(pObj_, {0, 0, 0}, 0.f, 0.5f, {k[0] * em1, k[1] * em1, k[2] * em1});
        drawMesh(pObj_, mTargetRing_, mul(translate4(p + vec3(0, 0.215f, 0)), rotY(s.t * (0.5f + 1.2f * t.v))));
        mat4 m2 = mul(translate4(p + vec3(0, 0.82f, 0)), mul(rotY(-s.t * (0.8f + 1.4f * t.v)), rotX(1.2f + 0.2f * std::sin(s.t * 0.8f))));
        mat4 sc = mul(m2, scale4({1.25f, 1.25f, 1.25f}));
        drawMesh(pObj_, mTargetRing_, sc);
    }
    drawElementsOpaque(s, false);

    // حلقات التحديد والمقبض
    if (!s.menuMode) {
        glUseProgram(pObj_.id);
        for (size_t i = 0; i < B.els.size(); i++) {
            const Element& e = B.els[i];
            if (e.fixed) continue;
            bool sel = (int)i == s.sel;
            float r = sel ? 0.85f : 0.5f;
            float g = sel ? 1.0f : 0.35f;
            setObj(pObj_, {0, 0, 0}, 0.f, 0.5f, {1.6f * g, 0.85f * g, 0.2f * g});
            drawMesh(pObj_, mRing_, mul(translate4(Wp(e.x, e.y, 0.03f)), scale4({r, 1.f, r})));
            if (sel) {
                vec3 c = Wp(e.x, e.y, beamY());
                vec3 h = Wp(e.x + std::cos(e.a - 1.5707963) * 52, e.y + std::sin(e.a - 1.5707963) * 52, beamY());
                vec3 mid = (c + h) * 0.5f;
                float len = length(h - c);
                float yaw = std::atan2(h.z - c.z, h.x - c.x);
                setObj(pObj_, {0, 0, 0}, 0.f, 0.5f, {1.2f, 0.65f, 0.15f});
                mat4 lm = mul(modelYaw(mid, yaw), scale4({len, 0.025f, 0.025f}));
                drawMesh(pObj_, mUnitBox_, lm);
                float hs = s.dragMode == 2 ? 0.2f : 0.15f;
                setObj(pObj_, {0, 0, 0}, 0.f, 0.5f, {2.6f, 1.5f, 0.4f});
                drawMesh(pObj_, mSphere_, mul(translate4(h), scale4({hs, hs, hs})));
            }
        }
        if (s.hint > 0.01f) {
            for (const auto& e : B.els) {
                if (e.fixed) continue;
                float a = (0.6f + 0.4f * std::sin(s.t * 6.f)) * s.hint;
                setObj(pObj_, {0, 0, 0}, 0.f, 0.5f, {0.2f * a * 3.f, 1.4f * a, 0.8f * a});
                drawMesh(pObj_, mRing_, mul(translate4(Wp(e.sx, e.sy, 0.03f)), scale4({0.7f, 1.f, 0.7f})));
            }
        }
    }

    // ---- الشفاف ثم الإضافي ----
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    drawElementsTransparent(s);

    glBlendFunc(GL_ONE, GL_ONE);
    collectFx(s);
    flushBatch(fxBeam_, pBeam_, s);
    flushBatch(fxGlow_, pGlow_, s);
    flushBatch(fxStar_, pStar_, s);
    glBindVertexArray(0);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);

    if (samples_ > 0) {
        glBindFramebuffer(GL_READ_FRAMEBUFFER, msFbo_);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, sceneFbo_);
        glBlitFramebuffer(0, 0, sceneW_, sceneH_, 0, 0, sceneW_, sceneH_, GL_COLOR_BUFFER_BIT, GL_NEAREST);
    }
}

void Renderer::postProcess(const SceneState& s) {
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glBindVertexArray(emptyVao_);
    float bloomI = 0.f;
    GLuint t1 = sceneTex_, t2 = sceneTex_;
    if (quality_ >= 1) {
        bloomI = quality_ >= 2 ? 1.0f : 0.8f;
        // نقاط ساطعة -> ربع الدقة
        glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[0]);
        glViewport(0, 0, bW_[0], bH_[0]);
        glUseProgram(pBright_.id);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneTex_);
        glUniform1i(pBright_.u("uTex"), 0);
        glUniform2f(pBright_.u("uTexel"), 1.f / sceneW_, 1.f / sceneH_);
        glUniform1f(pBright_.u("uThresh"), 0.72f);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        // تمويه مستوى 1 (مرتين)
        glUseProgram(pBlur_.id);
        glUniform1i(pBlur_.u("uTex"), 0);
        for (int pass = 0; pass < 2; pass++) {
            glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[1]);
            glBindTexture(GL_TEXTURE_2D, bTex_[0]);
            glUniform2f(pBlur_.u("uDir"), 1.f / bW_[0], 0.f);
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[0]);
            glBindTexture(GL_TEXTURE_2D, bTex_[1]);
            glUniform2f(pBlur_.u("uDir"), 0.f, 1.f / bH_[0]);
            glDrawArrays(GL_TRIANGLES, 0, 3);
        }
        // مستوى 2 (أوسع)
        glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[2]);
        glViewport(0, 0, bW_[1], bH_[1]);
        glUseProgram(pDown_.id);
        glBindTexture(GL_TEXTURE_2D, bTex_[0]);
        glUniform1i(pDown_.u("uTex"), 0);
        glUniform2f(pDown_.u("uTexel"), 1.f / bW_[0], 1.f / bH_[0]);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glUseProgram(pBlur_.id);
        for (int pass = 0; pass < 2; pass++) {
            glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[3]);
            glBindTexture(GL_TEXTURE_2D, bTex_[2]);
            glUniform2f(pBlur_.u("uDir"), 1.f / bW_[1], 0.f);
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glBindFramebuffer(GL_FRAMEBUFFER, bFbo_[2]);
            glBindTexture(GL_TEXTURE_2D, bTex_[3]);
            glUniform2f(pBlur_.u("uDir"), 0.f, 1.f / bH_[1]);
            glDrawArrays(GL_TRIANGLES, 0, 3);
        }
        t1 = bTex_[0];
        t2 = bTex_[2];
    }
    // التركيب النهائي على الشاشة
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, W_, H_);
    glUseProgram(pComp_.id);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, sceneTex_);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, t1);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, t2);
    glUniform1i(pComp_.u("uScene"), 0);
    glUniform1i(pComp_.u("uBloom1"), 1);
    glUniform1i(pComp_.u("uBloom2"), 2);
    glUniform1f(pComp_.u("uBloomI"), bloomI);
    glUniform1f(pComp_.u("uDim"), s.dim);
    glUniform1f(pComp_.u("uFade"), s.fade);
    glUniform1f(pComp_.u("uTime"), s.t);
    glUniform2f(pComp_.u("uRes"), (float)W_, (float)H_);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(0);
}

void Renderer::render(const SceneState& s) {
    if (!ready_) return;
    updateCamera(s);
    collectLights(s);
    drawShadowPass(s);
    drawScene(s);
    postProcess(s);
}
