// واجهة بين اللعبة والنظام (أندرويد): نصوص عربية، أيقونات، صوت، ملفات
#pragma once
#include <vector>
#include <string>
#include <cstdint>

struct Pixels {
    int w = 0, h = 0;
    std::vector<uint8_t> rgba;   // RGBA 8 بت (ألفا مباشرة، غير مضروبة)
};

struct Platform {
    virtual ~Platform() {}
    // رسم نص (يدعم العربية) إلى صورة بيضاء شفافة الخلفية
    virtual bool renderText(const char* utf8, float px, bool bold, Pixels& out) = 0;
    // أيقونة متجهة (0..n) بحجم px
    virtual bool renderIcon(int id, int px, Pixels& out) = 0;
    virtual void playTone(float hz, int ms, float vol, int delayMs) = 0;
    virtual std::string dataDir() = 0;
    virtual float density() = 0;     // dpi/160
};

enum IconId {
    ICON_MENU = 0, ICON_HINT, ICON_RESET, ICON_SOUND_ON, ICON_SOUND_OFF, ICON_CAMERA,
    ICON_BACK, ICON_STAR, ICON_STAR_EMPTY, ICON_LOCK, ICON_NEXT, ICON_GRID, ICON_REPLAY,
    ICON_GFX, ICON_COUNT
};
