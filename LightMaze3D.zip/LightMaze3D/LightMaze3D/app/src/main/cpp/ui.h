// واجهة ثنائية الأبعاد (مستطيلات ونصوص وأيقونات) فوق المشهد
#pragma once
#include <GLES3/gl3.h>
#include <string>
#include <unordered_map>
#include "platform.h"
#include "renderer.h"

struct Col { float r, g, b, a; };

class Ui {
public:
    bool init(Platform* pf);
    void shutdown();
    void clearCache();
    void begin(int w, int h);
    void end();
    void rect(float x, float y, float w, float h, float rad, Col top, Col bot, Col border = {0, 0, 0, 0}, float bw = 0);
    // y = مركز النص الرأسي ; anchor: 0 يسار، 1 وسط، 2 يمين
    float text(const std::string& s, float size, bool bold, float x, float y, int anchor, Col c, bool shadow = true);
    float textWidth(const std::string& s, float size, bool bold);
    void icon(int id, float cx, float cy, float size, Col c);
private:
    struct Tex { GLuint id = 0; int w = 0, h = 0; };
    Platform* pf_ = nullptr;
    Prog pRect_, pTex_;
    GLuint vao_ = 0, vbo_ = 0;
    int W_ = 0, H_ = 0;
    std::unordered_map<std::string, Tex> cache_;
    Tex* getTex(const std::string& key, bool isIcon, const std::string& s, float size, bool bold, int iconId);
    void quad(float x, float y, float w, float h);
};
