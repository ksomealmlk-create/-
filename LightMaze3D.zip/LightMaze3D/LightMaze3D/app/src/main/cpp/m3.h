// رياضيات ثلاثية الأبعاد صغيرة (متجهات + مصفوفات) - بدون أي مكتبات خارجية
#pragma once
#include <cmath>
#include <algorithm>
#include <cstring>

struct vec3 {
    float x = 0, y = 0, z = 0;
    vec3() {}
    vec3(float a, float b, float c) : x(a), y(b), z(c) {}
};
inline vec3 operator+(vec3 a, vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline vec3 operator-(vec3 a, vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline vec3 operator*(vec3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline vec3 operator*(float s, vec3 a) { return {a.x * s, a.y * s, a.z * s}; }
inline float dot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline vec3 cross(vec3 a, vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline float length(vec3 a) { return std::sqrt(dot(a, a)); }
inline vec3 normalize(vec3 a) {
    float l = length(a);
    if (l < 1e-8f) return {0, 1, 0};
    return a * (1.0f / l);
}
inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline float smooth01(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }

// مصفوفة 4x4 مرتبة بالأعمدة (column-major) مثل OpenGL
struct mat4 {
    float m[16];
};
inline mat4 identity4() {
    mat4 r;
    std::memset(r.m, 0, sizeof(r.m));
    r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1;
    return r;
}
inline mat4 mul(const mat4& a, const mat4& b) {
    mat4 r;
    for (int c = 0; c < 4; c++)
        for (int row = 0; row < 4; row++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
            r.m[c * 4 + row] = s;
        }
    return r;
}
inline mat4 perspective(float fovy, float aspect, float n, float f) {
    mat4 r;
    std::memset(r.m, 0, sizeof(r.m));
    float t = 1.0f / std::tan(fovy * 0.5f);
    r.m[0] = t / aspect;
    r.m[5] = t;
    r.m[10] = (f + n) / (n - f);
    r.m[11] = -1;
    r.m[14] = 2 * f * n / (n - f);
    return r;
}
inline mat4 lookAt(vec3 eye, vec3 at, vec3 up) {
    vec3 z = normalize(eye - at);
    vec3 x = normalize(cross(up, z));
    vec3 y = cross(z, x);
    mat4 r = identity4();
    r.m[0] = x.x; r.m[4] = x.y; r.m[8] = x.z;
    r.m[1] = y.x; r.m[5] = y.y; r.m[9] = y.z;
    r.m[2] = z.x; r.m[6] = z.y; r.m[10] = z.z;
    r.m[12] = -dot(x, eye);
    r.m[13] = -dot(y, eye);
    r.m[14] = -dot(z, eye);
    return r;
}
inline mat4 ortho(float l, float r_, float b, float t, float n, float f) {
    mat4 r = identity4();
    r.m[0] = 2 / (r_ - l);
    r.m[5] = 2 / (t - b);
    r.m[10] = -2 / (f - n);
    r.m[12] = -(r_ + l) / (r_ - l);
    r.m[13] = -(t + b) / (t - b);
    r.m[14] = -(f + n) / (f - n);
    return r;
}
inline mat4 translate4(vec3 v) {
    mat4 r = identity4();
    r.m[12] = v.x; r.m[13] = v.y; r.m[14] = v.z;
    return r;
}
// دوران حول المحور Y بحيث يصبح المحور المحلي X باتجاه (cos a, 0, sin a) + إزاحة
inline mat4 modelYaw(vec3 pos, float a) {
    mat4 r = identity4();
    float c = std::cos(a), s = std::sin(a);
    r.m[0] = c;  r.m[1] = 0; r.m[2] = s;
    r.m[8] = -s; r.m[9] = 0; r.m[10] = c;
    r.m[12] = pos.x; r.m[13] = pos.y; r.m[14] = pos.z;
    return r;
}
inline mat4 modelScaleYaw(vec3 pos, float a, float sc) {
    mat4 r = modelYaw(pos, a);
    for (int i = 0; i < 3; i++) { r.m[i] *= sc; r.m[4 + i] *= sc; r.m[8 + i] *= sc; }
    return r;
}
inline mat4 rotX(float a) {
    mat4 r = identity4();
    float c = std::cos(a), s = std::sin(a);
    r.m[5] = c; r.m[6] = s; r.m[9] = -s; r.m[10] = c;
    return r;
}
inline mat4 rotY(float a) {
    mat4 r = identity4();
    float c = std::cos(a), s = std::sin(a);
    r.m[0] = c; r.m[2] = s; r.m[8] = -s; r.m[10] = c;
    return r;
}
inline mat4 rotZ(float a) {
    mat4 r = identity4();
    float c = std::cos(a), s = std::sin(a);
    r.m[0] = c; r.m[1] = s; r.m[4] = -s; r.m[5] = c;
    return r;
}
inline mat4 scale4(vec3 v) {
    mat4 r = identity4();
    r.m[0] = v.x; r.m[5] = v.y; r.m[10] = v.z;
    return r;
}
// عكس مصفوفة عامة (نفس طريقة Mesa)
inline bool invert4(const mat4& mm, mat4& out) {
    const float* m = mm.m;
    float inv[16], det;
    inv[0] = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15] + m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10];
    inv[4] = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15] - m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10];
    inv[8] = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15] + m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9];
    inv[12] = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14] - m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9];
    inv[1] = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15] - m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10];
    inv[5] = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15] + m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10];
    inv[9] = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15] - m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9];
    inv[13] = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14] + m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9];
    inv[2] = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15] + m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6];
    inv[6] = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15] - m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6];
    inv[10] = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15] + m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5];
    inv[14] = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14] - m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5];
    inv[3] = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11] - m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6];
    inv[7] = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11] + m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6];
    inv[11] = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11] - m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5];
    inv[15] = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10] + m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5];
    det = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12];
    if (std::fabs(det) < 1e-12f) return false;
    det = 1.0f / det;
    for (int i = 0; i < 16; i++) out.m[i] = inv[i] * det;
    return true;
}
// تحويل نقطة (x,y,z,1) بمصفوفة، مع القسمة على w
inline bool project4(const mat4& vp, vec3 p, float& sx, float& sy) {
    const float* m = vp.m;
    float x = m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12];
    float y = m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13];
    float w = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15];
    if (w < 1e-4f) return false;
    sx = x / w; sy = y / w;
    return true;
}
inline vec3 unprojectPoint(const mat4& invVP, float nx, float ny, float nz) {
    const float* m = invVP.m;
    float x = m[0] * nx + m[4] * ny + m[8] * nz + m[12];
    float y = m[1] * nx + m[5] * ny + m[9] * nz + m[13];
    float z = m[2] * nx + m[6] * ny + m[10] * nz + m[14];
    float w = m[3] * nx + m[7] * ny + m[11] * nz + m[15];
    return {x / w, y / w, z / w};
}
