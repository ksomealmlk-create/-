// المحرك الرسومي ثلاثي الأبعاد (OpenGL ES 3.0)
#pragma once
#include <GLES3/gl3.h>
#include <vector>
#include <string>
#include <unordered_map>
#include "m3.h"
#include "mesh.h"
#include "game.h"

struct Prog {
    GLuint id = 0;
    std::unordered_map<std::string, GLint> cache;
    GLint u(const char* n) {
        auto it = cache.find(n);
        if (it != cache.end()) return it->second;
        GLint l = glGetUniformLocation(id, n);
        cache[n] = l;
        return l;
    }
};

struct GpuMesh {
    GLuint vao = 0, vbo = 0, ibo = 0;
    int count = 0;
    void upload(const MeshData& m);
    void draw() const;
    void destroy();
};

struct Particle {
    vec3 p, v, col;
    float life, maxLife, size;
};

struct SceneState {
    const Board* B = nullptr;
    const TraceResult* R = nullptr;
    float t = 0, dt = 0.016f;
    int sel = -1;
    int dragMode = 0;       // 0 لا شيء، 1 تحريك، 2 تدوير
    float hint = 0;         // 0..1
    float celebrate = -1;   // زمن منذ الفوز (سالب = لا)
    float dim = 0;          // تعتيم (القائمة)
    float fade = 1;
    bool menuMode = false;
    float pitchDeg = 58;    // زاوية الكاميرا
    float uiTopPx = 0, uiBottomPx = 0;
};

class Renderer {
public:
    bool init(int w, int h, int quality);
    void shutdown();
    void resize(int w, int h);
    void setQuality(int q);
    int quality() const { return quality_; }
    void setBoard(const Board* B);
    void update(const SceneState& s);
    void render(const SceneState& s);
    // تحويل لمسة على الشاشة إلى إحداثيات الملعب (بكسل اللعبة) على ارتفاع planeY
    bool screenToPlay(float sx, float sy, float planeY, double& px, double& py) const;
    void burst(vec3 pos, vec3 col, int n, float speed);
    float beamY() const { return 0.55f; }
    int width() const { return W_; }
    int height() const { return H_; }

private:
    int W_ = 0, H_ = 0, quality_ = 2;
    int sceneW_ = 0, sceneH_ = 0;
    bool ready_ = false;
    Prog pFloor_, pWall_, pObj_, pMirror_, pGlass_, pShadow_, pBeam_, pGlow_, pStar_;
    Prog pBright_, pDown_, pBlur_, pComp_;
    GpuMesh mWalls_, mPlatform_, mFloor_, mUnitBox_, mRing_, mSphere_;
    GpuMesh mMirrorGlass_[2], mMirrorFrame_[2], mPedestal_, mBolt_;
    GpuMesh mPrism_, mCrystal_, mTargetBase_, mTargetRing_, mEmitter_, mLens_, mGlassZone_;
    GLuint fxVao_ = 0, fxVbo_ = 0, emptyVao_ = 0;
    GLuint sceneTex_ = 0, sceneFbo_ = 0, sceneDepth_ = 0;
    GLuint msFbo_ = 0, msColor_ = 0, msDepth_ = 0;
    int samples_ = 0;
    GLuint shadowTex_ = 0, shadowFbo_ = 0, dummyShadow_ = 0;
    int shadowSize_ = 0;
    GLuint bTex_[4] = {0, 0, 0, 0}, bFbo_[4] = {0, 0, 0, 0};
    int bW_[2] = {0, 0}, bH_[2] = {0, 0};
    const Board* board_ = nullptr;
    // الكاميرا
    float pitchCur_ = 58, camDist_ = 20, camYaw_ = 0, orbit_ = 0;
    vec3 camTarget_ = {0, 0.2f, 0}, camEye_;
    mat4 view_, proj_, vp_, invVp_, lightVP_;
    float pitchTarget_ = 58;
    // الجسيمات
    std::vector<Particle> parts_;
    struct Mote { vec3 p; float s, ph; };
    std::vector<Mote> dust_;
    // ملفات الأضواء
    float segA_[32 * 4], segB_[32 * 4], segC_[32 * 4];
    int nSeg_ = 0;
    std::vector<float> fxBeam_, fxGlow_, fxStar_;
    unsigned rng_ = 12345;

    float rnd();
    float rnd(float a, float b) { return a + (b - a) * rnd(); }
    bool buildPrograms();
    bool createTargets();
    void destroyTargets();
    void buildStaticMeshes();
    void updateCamera(const SceneState& s);
    void collectLights(const SceneState& s);
    void collectFx(const SceneState& s);
    void setLit(Prog& p, const SceneState& s);
    void drawShadowPass(const SceneState& s);
    void drawScene(const SceneState& s);
    void drawElementsOpaque(const SceneState& s, bool shadowPass);
    void drawElementsTransparent(const SceneState& s);
    void drawFx(const SceneState& s);
    void postProcess(const SceneState& s);
    void flushBatch(std::vector<float>& v, Prog& p, const SceneState& s);
    void addRibbon(std::vector<float>& v, vec3 a, vec3 b, float hw, const float* col4, float aFadeA, float aFadeB);
    void addSprite(std::vector<float>& v, vec3 c, float size, const float* col4, float rot = 0);
    void drawMesh(Prog& p, const GpuMesh& m, const mat4& model);
    void setModelUniform(Prog& p, const mat4& m);
};
