// منطق اللعبة (المراحل + محرك الشعاع) - منقول حرفياً من النسخة الأصلية (core.js)
#pragma once
#include <vector>
#include <string>

// إحداثيات اللعبة بالبكسل مثل النسخة الأصلية: الملعب 576x560
struct Seg4 { double x1, y1, x2, y2; };
struct PathPt { double x, y; char t; };      // t=0 => هدف (نهاية المسار)
struct XDef { char t; double x, y, a; };     // 'p' منشور، 'm' مرآة متحركة، 'f' مرآة ثابتة
struct TDef { double x, y; char c; };        // c = 0 (أي لون) أو 'r','g','b'

struct LevelDef {
    const char* name;
    double ex, ey, edx, edy;
    std::vector<Seg4> walls;
    std::vector<Seg4> glass;                 // x,y,w,h
    std::vector<std::vector<PathPt>> paths;
    std::vector<XDef> X;
    std::vector<TDef> T;
};

struct Target { double x, y, r; float v; char c; };
struct Element {
    double x, y, a, len;
    bool prism, split, fixed;
    double sx, sy, sa;                       // وضع الحل (للتلميح)
};
struct Board {
    const char* name = "";
    double ex = 0, ey = 0, edx = 1, edy = 0;
    std::vector<Seg4> walls, glass;
    std::vector<Target> T;
    std::vector<Element> els;
    int mv = 0;                              // عدد العناصر المتحركة
};

struct TracePt { double x, y; char kind; };  // kind: 'w' جدار, 'e' مرآة, 't' هدف, 'p' منشور
struct Poly { std::vector<TracePt> pts; char c; };
struct TraceResult {
    std::vector<Poly> polys;
    std::vector<bool> hit;
    int hitCount = 0;
};

const std::vector<LevelDef>& allLevels();
Board buildBoard(const LevelDef& L);
void traceBoard(const Board& B, TraceResult& out);
Seg4 elemSeg(const Element& e);
extern const Seg4 BORDERS[4];
// ثوابت الملعب
constexpr double PLAY_W = 576, PLAY_H = 560;
