#include "ui.h"
#include "shaders.h"
#include "log.h"
#include <cmath>

static bool mkProg(Prog& p, const char* vs, const char* fs, const char* name) {
    auto comp = [&](GLenum t, const char* src) -> GLuint {
        GLuint s = glCreateShader(t);
        glShaderSource(s, 1, &src, nullptr);
        glCompileShader(s);
        GLint ok = 0;
        glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
        if (!ok) { char b[1024]; glGetShaderInfoLog(s, sizeof(b), nullptr, b); LOGE("ui shader %s: %s", name, b); return 0; }
        return s;
    };
    GLuint v = comp(GL_VERTEX_SHADER, vs), f = comp(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return false;
    GLuint id = glCreateProgram();
    glAttachShader(id, v); glAttachShader(id, f);
    glLinkProgram(id);
    GLint ok = 0;
    glGetProgramiv(id, GL_LINK_STATUS, &ok);
    glDeleteShader(v); glDeleteShader(f);
    if (!ok) { char b[1024]; glGetProgramInfoLog(id, sizeof(b), nullptr, b); LOGE("ui prog %s: %s", name, b); return false; }
    p.id = id; p.cache.clear();
    return true;
}

bool Ui::init(Platform* pf) {
    pf_ = pf;
    if (!mkProg(pRect_, VS_UI, FS_UI_RECT, "uirect")) return false;
    if (!mkProg(pTex_, VS_UI, FS_UI_TEX, "uitex")) return false;
    glGenVertexArrays(1, &vao_);
    glBindVertexArray(vao_);
    glGenBuffers(1, &vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, 6 * 4 * sizeof(float), nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 16, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 16, (void*)8);
    glBindVertexArray(0);
    return true;
}

void Ui::clearCache() {
    for (auto& kv : cache_) if (kv.second.id) glDeleteTextures(1, &kv.second.id);
    cache_.clear();
}

void Ui::shutdown() {
    clearCache();
    if (pRect_.id) glDeleteProgram(pRect_.id);
    if (pTex_.id) glDeleteProgram(pTex_.id);
    if (vbo_) glDeleteBuffers(1, &vbo_);
    if (vao_) glDeleteVertexArrays(1, &vao_);
    pRect_.id = pTex_.id = 0; vbo_ = vao_ = 0;
}

void Ui::begin(int w, int h) {
    W_ = w; H_ = h;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, w, h);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindVertexArray(vao_);
    if (cache_.size() > 400) clearCache();
}

void Ui::end() {
    glBindVertexArray(0);
    glDisable(GL_BLEND);
}

void Ui::quad(float x, float y, float w, float h) {
    float v[24] = {x, y, 0, 0, x + w, y, 1, 0, x + w, y + h, 1, 1,
                   x, y, 0, 0, x + w, y + h, 1, 1, x, y + h, 0, 1};
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

void Ui::rect(float x, float y, float w, float h, float rad, Col top, Col bot, Col border, float bw) {
    glUseProgram(pRect_.id);
    glUniform2f(pRect_.u("uScreen"), (float)W_, (float)H_);
    glUniform4f(pRect_.u("uRect"), x, y, w, h);
    glUniform1f(pRect_.u("uRad"), std::min(rad, std::min(w, h) * 0.5f));
    glUniform4f(pRect_.u("uColTop"), top.r, top.g, top.b, top.a);
    glUniform4f(pRect_.u("uColBot"), bot.r, bot.g, bot.b, bot.a);
    glUniform4f(pRect_.u("uBorder"), border.r, border.g, border.b, border.a);
    glUniform1f(pRect_.u("uBorderW"), bw);
    quad(x - 2, y - 2, w + 4, h + 4);
}

Ui::Tex* Ui::getTex(const std::string& key, bool isIcon, const std::string& s, float size, bool bold, int iconId) {
    auto it = cache_.find(key);
    if (it != cache_.end()) return &it->second;
    Pixels px;
    bool ok = isIcon ? pf_->renderIcon(iconId, (int)size, px) : pf_->renderText(s.c_str(), size, bold, px);
    Tex t;
    if (ok && px.w > 0 && px.h > 0) {
        glGenTextures(1, &t.id);
        glBindTexture(GL_TEXTURE_2D, t.id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, px.w, px.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.rgba.data());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        t.w = px.w; t.h = px.h;
    }
    return &(cache_[key] = t);
}

float Ui::textWidth(const std::string& s, float size, bool bold) {
    std::string key = std::to_string((int)size) + (bold ? "B|" : "N|") + s;
    Tex* t = getTex(key, false, s, size, bold, 0);
    return t ? (float)t->w : 0.f;
}

float Ui::text(const std::string& s, float size, bool bold, float x, float y, int anchor, Col c, bool shadow) {
    if (s.empty()) return 0;
    std::string key = std::to_string((int)size) + (bold ? "B|" : "N|") + s;
    Tex* t = getTex(key, false, s, size, bold, 0);
    if (!t || !t->id) return 0;
    float w = (float)t->w, h = (float)t->h;
    float x0 = anchor == 0 ? x : (anchor == 1 ? x - w * 0.5f : x - w);
    float y0 = y - h * 0.5f;
    x0 = std::floor(x0 + 0.5f); y0 = std::floor(y0 + 0.5f);
    glUseProgram(pTex_.id);
    glUniform2f(pTex_.u("uScreen"), (float)W_, (float)H_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, t->id);
    glUniform1i(pTex_.u("uTex"), 0);
    if (shadow) {
        glUniform4f(pTex_.u("uTint"), 0, 0, 0, c.a * 0.55f);
        float o = std::max(1.0f, size * 0.07f);
        quad(x0 + o, y0 + o, w, h);
    }
    glUniform4f(pTex_.u("uTint"), c.r, c.g, c.b, c.a);
    quad(x0, y0, w, h);
    return w;
}

void Ui::icon(int id, float cx, float cy, float size, Col c) {
    std::string key = "I" + std::to_string(id) + "|" + std::to_string((int)size);
    Tex* t = getTex(key, true, "", size, false, id);
    if (!t || !t->id) return;
    float w = (float)t->w, h = (float)t->h;
    glUseProgram(pTex_.id);
    glUniform2f(pTex_.u("uScreen"), (float)W_, (float)H_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, t->id);
    glUniform1i(pTex_.u("uTex"), 0);
    glUniform4f(pTex_.u("uTint"), c.r, c.g, c.b, c.a);
    quad(std::floor(cx - w * 0.5f + 0.5f), std::floor(cy - h * 0.5f + 0.5f), w, h);
}
