#include "app.h"
#include "log.h"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>

enum Bid { B_MENU = 1, B_HINT, B_RESET, B_SOUND, B_CAM, B_NEXT, B_AGAIN, B_LIST, B_QUALITY, B_LEVEL0 = 100 };

static const float PITCHES[3] = {58.f, 72.f, 87.f};
static const Col GOLD = {1.0f, 0.78f, 0.25f, 1};
static const Col WHITE = {0.93f, 0.95f, 1.0f, 1};
static const Col SOFT = {0.62f, 0.69f, 0.84f, 1};

static float distSegP(double px, double py, const Seg4& s) {
    double ex = s.x2 - s.x1, ey = s.y2 - s.y1, l2 = ex * ex + ey * ey;
    if (l2 < 1e-9) l2 = 1;
    double u = std::max(0.0, std::min(1.0, ((px - s.x1) * ex + (py - s.y1) * ey) / l2));
    return (float)std::hypot(px - s.x1 - u * ex, py - s.y1 - u * ey);
}

const char* App::qualityName() const {
    return quality_ == 0 ? "الجودة: منخفضة" : (quality_ == 1 ? "الجودة: متوسطة" : "الجودة: عالية");
}

void App::tone(float hz, int ms, float vol, int delay) {
    if (!mute_) pf_->playTone(hz, ms, vol, delay);
}

// ---------------------------------------------------------------- حفظ
void App::loadSave() {
    stars_.assign(allLevels().size(), 0);
    std::string path = pf_->dataDir() + "/lightmaze3d.sav";
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return;
    char tag[16];
    while (fscanf(f, "%15s", tag) == 1) {
        if (!strcmp(tag, "q")) { int v; if (fscanf(f, "%d", &v) == 1) quality_ = std::max(0, std::min(2, v)); }
        else if (!strcmp(tag, "m")) { int v; if (fscanf(f, "%d", &v) == 1) mute_ = v != 0; }
        else if (!strcmp(tag, "s")) {
            int n = 0;
            if (fscanf(f, "%d", &n) == 1)
                for (int i = 0; i < n; i++) { int v = 0; if (fscanf(f, "%d", &v) != 1) break; if (i < (int)stars_.size()) stars_[i] = std::max(0, std::min(3, v)); }
        }
    }
    fclose(f);
}

void App::save() {
    std::string path = pf_->dataDir() + "/lightmaze3d.sav";
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return;
    fprintf(f, "q %d\nm %d\ns %d", quality_, mute_ ? 1 : 0, (int)stars_.size());
    for (int v : stars_) fprintf(f, " %d", v);
    fprintf(f, "\n");
    fclose(f);
}

// ---------------------------------------------------------------- سطح الرسم
bool App::onSurface(int w, int h) {
    W_ = w; H_ = h;
    dp_ = std::max(1.0f, pf_->density());
    if (stars_.empty()) loadSave();
    if (!r_.init(w, h, quality_)) { LOGE("renderer init failed"); return false; }
    if (!ui_.init(pf_)) { LOGE("ui init failed"); return false; }
    if (screen_ == MENU) { B_ = buildBoard(allLevels()[25 % allLevels().size()]); for (auto& e : B_.els) if (!e.fixed) { e.x = e.sx; e.y = e.sy; e.a = e.sa; } }
    r_.setBoard(&B_);
    fade_ = 0;
    return true;
}

void App::onSurfaceLost() {
    ui_.shutdown();
    r_.shutdown();
}

void App::onResize(int w, int h) {
    W_ = w; H_ = h;
    r_.resize(w, h);
}

// ---------------------------------------------------------------- مراحل
void App::startLevel(int i) {
    li_ = i;
    B_ = buildBoard(allLevels()[i]);
    r_.setBoard(&B_);
    traceBoard(B_, R_);
    sel_ = -1;
    for (size_t k = 0; k < B_.els.size(); k++) if (!B_.els[k].fixed) { sel_ = (int)k; break; }
    moves_ = 0; won_ = false; winT_ = 0; celebT_ = -1; hintT_ = 0; drag_ = 0; changed_ = false;
    screen_ = PLAY;
    fade_ = 0;
}

void App::showMenu() {
    screen_ = MENU;
    B_ = buildBoard(allLevels()[25 % allLevels().size()]);
    for (auto& e : B_.els) if (!e.fixed) { e.x = e.sx; e.y = e.sy; e.a = e.sa; }
    r_.setBoard(&B_);
    traceBoard(B_, R_);
    for (auto& t : B_.T) t.v = 1.f;
    won_ = false;
    fade_ = 0;
}

void App::setSolvedForTest(bool s) {
    if (!s) return;
    for (auto& e : B_.els) if (!e.fixed) { e.x = e.sx; e.y = e.sy; e.a = e.sa; }
}

void App::doWin() {
    won_ = true;
    celebT_ = 0;
    int par = B_.mv * 4;
    int st = moves_ <= par ? 3 : (moves_ <= par * 2 ? 2 : 1);
    stars_[li_] = std::max(stars_[li_], st);
    save();
    for (const auto& t : B_.T) {
        float k[3] = {0.5f, 0.7f, 1.f};
        if (t.c == 'r') { k[0] = 1; k[1] = .35f; k[2] = .15f; }
        if (t.c == 'g') { k[0] = .3f; k[1] = 1; k[2] = .55f; }
        if (t.c == 'b') { k[0] = .3f; k[1] = .6f; k[2] = 1; }
        r_.burst({(float)((t.x - 288) / 40), 0.9f, (float)((t.y - 280) / 40)}, {k[0], k[1], k[2]}, 70, 4.5f);
        r_.burst({(float)((t.x - 288) / 40), 0.9f, (float)((t.y - 280) / 40)}, {1, 0.95f, 0.8f}, 30, 3.f);
    }
    float f[4] = {523, 659, 784, 1047};
    for (int k = 0; k < 4; k++) tone(f[k], 500, 0.05f, k * 130);
}

// ---------------------------------------------------------------- لمس
int App::hitBtn(float x, float y) const {
    for (int i = (int)btns_.size() - 1; i >= 0; i--) {
        const Btn& b = btns_[i];
        if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return b.id;
    }
    return -1;
}

bool App::toPlay(float sx, float sy, double& px, double& py) {
    return r_.screenToPlay(sx, sy, r_.beamY(), px, py);
}

void App::playDown(float x, float y) {
    double px, py;
    if (!toPlay(x, y, px, py)) return;
    if (sel_ >= 0) {
        const Element& e = B_.els[sel_];
        double hx = e.x + std::cos(e.a - M_PI / 2) * 52, hy = e.y + std::sin(e.a - M_PI / 2) * 52;
        if (std::hypot(px - hx, py - hy) < 38) { drag_ = 2; changed_ = false; return; }
    }
    int best = -1;
    double bd = 1e9;
    for (size_t i = 0; i < B_.els.size(); i++) {
        const Element& e = B_.els[i];
        if (e.fixed) continue;
        double d = std::min(std::hypot(px - e.x, py - e.y) * 0.6, (double)distSegP(px, py, elemSeg(e)));
        if (d < bd && d < 30) { bd = d; best = (int)i; }
    }
    if (best >= 0) {
        sel_ = best; drag_ = 1; changed_ = false;
        offx_ = B_.els[best].x - px; offy_ = B_.els[best].y - py;
        tone(520, 80, 0.03f);
    }
}

void App::playMove(float x, float y) {
    if (!drag_ || sel_ < 0) return;
    double px, py;
    if (!toPlay(x, y, px, py)) return;
    Element& e = B_.els[sel_];
    changed_ = true;
    if (drag_ == 1) {
        e.x = std::min(515.0, std::max(60.0, px + offx_));
        e.y = std::min(512.0, std::max(48.0, py + offy_));
    } else {
        e.a = std::atan2(py - e.y, px - e.x) + M_PI / 2;
    }
}

void App::playUp() {
    if (drag_ && changed_) { moves_++; tone(330, 100, 0.03f); }
    drag_ = 0; changed_ = false;
}

void App::onButton(int id) {
    if (id >= B_LEVEL0) { int i = id - B_LEVEL0; if (i < (int)allLevels().size() && unlocked(i)) { tone(600, 90, 0.04f); startLevel(i); } return; }
    switch (id) {
        case B_MENU: case B_LIST: showMenu(); break;
        case B_HINT: hintT_ = 4.f; break;
        case B_RESET: case B_AGAIN: startLevel(li_); break;
        case B_NEXT: if (li_ + 1 < (int)allLevels().size()) startLevel(li_ + 1); break;
        case B_CAM: camMode_ = (camMode_ + 1) % 3; break;
        case B_SOUND: mute_ = !mute_; save(); break;
        case B_QUALITY:
            quality_ = (quality_ + 1) % 3;
            r_.setQuality(quality_);
            save();
            break;
    }
}

void App::onTouch(int action, float x, float y) {
    if (action == 0) {
        down_ = true; moved_ = false; downX_ = x; downY_ = y; lastY_ = y; scrollVel_ = 0;
        pressBtn_ = hitBtn(x, y);
        if (screen_ == PLAY && !won_ && pressBtn_ < 0) playDown(x, y);
    } else if (action == 1 && down_) {
        if (std::hypot(x - downX_, y - downY_) > 10 * dp_) moved_ = true;
        if (screen_ == MENU) { scroll_ -= (y - lastY_); scrollVel_ = -(y - lastY_); }
        else if (!won_) playMove(x, y);
        lastY_ = y;
    } else if (action == 2 || action == 3) {
        if (!down_) return;
        down_ = false;
        if (screen_ == PLAY) playUp();
        if (action == 2 && !moved_) {
            int b = hitBtn(x, y);
            if (b >= 0 && b == pressBtn_) onButton(b);
        }
        pressBtn_ = -1;
    }
}

bool App::onBack() {
    if (screen_ == PLAY) { showMenu(); return true; }
    return false;
}

// ---------------------------------------------------------------- الإطار
void App::frame(float dt) {
    dt = std::min(dt, 0.05f);
    t_ += dt;
    fade_ = std::min(1.f, fade_ + dt * 2.5f);
    btns_.clear();
    if (screen_ == MENU) drawMenu(dt); else drawPlay(dt);
}

static Col mulA(Col c, float a) { c.a *= a; return c; }

void App::drawPlay(float dt) {
    float top = (56 + 30) * dp_, bottom = 76 * dp_;
    traceBoard(B_, R_);
    for (size_t i = 0; i < B_.T.size(); i++) {
        float tgt = R_.hit[i] ? 1.f : 0.f;
        B_.T[i].v += (tgt - B_.T[i].v) * std::min(1.f, dt * 5.f);
    }
    if (!won_ && R_.hitCount == (int)B_.T.size() && !drag_) {
        winT_ += dt;
        if (winT_ > 0.8f) doWin();
    } else if (!won_) winT_ = 0;
    if (won_) celebT_ += dt;
    if (hintT_ > 0) hintT_ -= dt;

    SceneState s;
    s.B = &B_; s.R = &R_; s.t = t_; s.dt = dt; s.sel = sel_; s.dragMode = drag_;
    s.hint = std::min(1.f, std::max(0.f, hintT_));
    s.celebrate = celebT_; s.dim = won_ ? 0.45f : 0.f; s.fade = fade_;
    s.menuMode = false; s.pitchDeg = PITCHES[camMode_];
    s.uiTopPx = top; s.uiBottomPx = bottom;
    r_.update(s);
    r_.render(s);

    ui_.begin(W_, H_);
    float gap = 8 * dp_, m = 10 * dp_, y0 = 12 * dp_;
    float bs = std::min(46 * dp_, (W_ - 2 * m - 4 * gap) / 5.f);
    Col bt = {0.13f, 0.17f, 0.28f, 0.88f}, bb = {0.07f, 0.09f, 0.16f, 0.88f}, bd = {0.3f, 0.4f, 0.7f, 0.9f};
    auto button = [&](int id, int icon, float x) {
        ui_.rect(x, y0, bs, bs, 12 * dp_, bt, bb, bd, 1.5f);
        ui_.icon(icon, x + bs / 2, y0 + bs / 2, 26 * dp_, WHITE);
        addBtn(id, x, y0, bs, bs);
    };
    button(B_MENU, ICON_GRID, W_ - m - bs);
    float x = m;
    button(B_SOUND, mute_ ? ICON_SOUND_OFF : ICON_SOUND_ON, x); x += bs + gap;
    button(B_CAM, ICON_CAMERA, x); x += bs + gap;
    button(B_RESET, ICON_RESET, x); x += bs + gap;
    button(B_HINT, ICON_HINT, x);
    // اسم المرحلة
    char nb[96];
    snprintf(nb, sizeof(nb), "%d. %s", li_ + 1, B_.name);
    ui_.text(nb, 20 * dp_, true, W_ * 0.5f, y0 + bs + 18 * dp_, 1, WHITE);
    // الأسفل
    char info[96];
    snprintf(info, sizeof(info), "الأهداف %d/%d  ·  الحركات %d", R_.hitCount, (int)B_.T.size(), moves_);
    ui_.text(info, 17 * dp_, false, W_ * 0.5f, H_ - 24 * dp_, 1, SOFT);
    const char* tip = nullptr;
    if (li_ == 0) tip = "اسحب المرآة لتحريكها، واسحب النقطة البرتقالية لتدويرها";
    else if (li_ == 4) tip = "المقسّم الزجاجي يمرّر الشعاع ويفرّعه إلى شعاعين";
    else if (li_ == 25) tip = "المنشور يحلّل الضوء إلى ألوان، وكل هدف ملوّن يريد لونه";
    else if (li_ == 12) tip = "جرّب زر المصباح للحصول على تلميح";
    if (tip && !won_) {
        float sz = 14 * dp_, w = ui_.textWidth(tip, sz, false);
        if (w > W_ - 20 * dp_) sz *= (W_ - 20 * dp_) / w;
        ui_.text(tip, sz, false, W_ * 0.5f, H_ - 54 * dp_, 1, mulA(WHITE, 0.8f));
    }
    // شاشة الفوز
    if (won_) {
        float pw = std::min((float)W_ * 0.88f, 340 * dp_), ph = 356 * dp_;
        float px = (W_ - pw) / 2, py = (H_ - ph) / 2;
        float a = std::min(1.f, celebT_ * 3.f);
        ui_.rect(px, py, pw, ph, 22 * dp_, {0.08f, 0.11f, 0.2f, 0.93f * a}, {0.03f, 0.04f, 0.09f, 0.95f * a}, {0.4f, 0.55f, 0.95f, 0.9f * a}, 2.f);
        ui_.text("أحسنت!", 34 * dp_, true, W_ * 0.5f, py + 42 * dp_, 1, mulA(WHITE, a));
        int st = stars_[li_];
        for (int k = 0; k < 3; k++) {
            float sc = std::min(1.f, std::max(0.f, celebT_ * 2.5f - k * 0.35f));
            float ss = 44 * dp_ * (0.6f + 0.4f * sc);
            ui_.icon(k < st ? ICON_STAR : ICON_STAR_EMPTY, W_ * 0.5f + (1 - k) * 56 * dp_, py + 100 * dp_, ss, k < st ? mulA(GOLD, sc) : mulA(SOFT, a * 0.6f));
        }
        char mv[64];
        snprintf(mv, sizeof(mv), "الحركات: %d", moves_);
        ui_.text(mv, 18 * dp_, false, W_ * 0.5f, py + 148 * dp_, 1, mulA(SOFT, a));
        bool last = li_ + 1 >= (int)allLevels().size();
        float bw = pw - 44 * dp_, bh = 46 * dp_, bx = px + 22 * dp_;
        auto wbtn = [&](int id, const char* label, float yy, bool primary) {
            ui_.rect(bx, yy, bw, bh, 13 * dp_, primary ? Col{0.2f, 0.3f, 0.6f, a} : Col{0.1f, 0.13f, 0.22f, a}, primary ? Col{0.11f, 0.17f, 0.38f, a} : Col{0.06f, 0.08f, 0.15f, a}, {0.35f, 0.5f, 0.9f, a}, 1.5f);
            ui_.text(label, 18 * dp_, true, W_ * 0.5f, yy + bh / 2, 1, mulA(WHITE, a));
            addBtn(id, bx, yy, bw, bh);
        };
        if (!last) wbtn(B_NEXT, "المرحلة التالية", py + 180 * dp_, true);
        else ui_.text("أنهيت كل المراحل!", 20 * dp_, true, W_ * 0.5f, py + 200 * dp_, 1, mulA(GOLD, a));
        wbtn(B_AGAIN, "إعادة المرحلة", py + 238 * dp_, false);
        wbtn(B_LIST, "قائمة المراحل", py + 292 * dp_, false);
        if (!last) {}
    }
    ui_.end();
}

void App::drawMenu(float dt) {
    // خلفية ثلاثية الأبعاد تدور ببطء
    traceBoard(B_, R_);
    SceneState s;
    s.B = &B_; s.R = &R_; s.t = t_; s.dt = dt; s.sel = -1; s.menuMode = true; s.dim = 0.62f; s.fade = fade_;
    for (auto& t : B_.T) t.v = 1.f;
    r_.update(s);
    r_.render(s);

    ui_.begin(W_, H_);
    float m = 14 * dp_, gap = 10 * dp_;
    int n = (int)allLevels().size();
    int cols = std::max(3, (int)((W_ - 2 * m + gap) / (104 * dp_ + gap)));
    float cw = (W_ - 2 * m - (cols - 1) * gap) / cols, ch = std::max(cw * 1.08f, 96 * dp_);
    int rows = (n + cols - 1) / cols;
    float headH = 188 * dp_;
    float contentH = headH + rows * (ch + gap) + 24 * dp_;
    scrollMax_ = std::max(0.f, contentH - H_);
    if (!down_) { scroll_ += scrollVel_; scrollVel_ *= 0.92f; if (std::fabs(scrollVel_) < 0.2f) scrollVel_ = 0; }
    scroll_ = std::max(0.f, std::min(scrollMax_, scroll_));
    float oy = -scroll_;

    int total = 0;
    for (int v : stars_) total += v;
    ui_.text("مرايا الضوء", 42 * dp_, true, W_ * 0.5f, oy + 54 * dp_, 1, WHITE);
    ui_.text("وجّه الشعاع بالمرايا حتى يصل إلى كل الأهداف", 15 * dp_, false, W_ * 0.5f, oy + 94 * dp_, 1, SOFT);
    char sb[64];
    snprintf(sb, sizeof(sb), "النجوم: %d/%d", total, n * 3);
    ui_.text(sb, 16 * dp_, true, W_ * 0.5f, oy + 122 * dp_, 1, GOLD);
    // أزرار الإعدادات
    float ow = std::min(170 * dp_, (W_ - 2 * m - gap) / 2), oh = 42 * dp_, oyy = oy + 142 * dp_;
    Col bt = {0.13f, 0.17f, 0.28f, 0.9f}, bb = {0.07f, 0.09f, 0.16f, 0.9f}, bd = {0.3f, 0.4f, 0.7f, 0.9f};
    float ox1 = W_ * 0.5f + gap / 2, ox2 = W_ * 0.5f - gap / 2 - ow;
    ui_.rect(ox1, oyy, ow, oh, 12 * dp_, bt, bb, bd, 1.5f);
    ui_.text(qualityName(), 14 * dp_, true, ox1 + ow / 2, oyy + oh / 2, 1, WHITE);
    addBtn(B_QUALITY, ox1, oyy, ow, oh);
    ui_.rect(ox2, oyy, ow, oh, 12 * dp_, bt, bb, bd, 1.5f);
    ui_.icon(mute_ ? ICON_SOUND_OFF : ICON_SOUND_ON, ox2 + ow * 0.28f, oyy + oh / 2, 22 * dp_, WHITE);
    ui_.text(mute_ ? "الصوت: مطفأ" : "الصوت: شغّال", 14 * dp_, true, ox2 + ow * 0.62f, oyy + oh / 2, 1, WHITE);
    addBtn(B_SOUND, ox2, oyy, ow, oh);
    // المراحل (من اليمين لليسار مثل العربية)
    for (int i = 0; i < n; i++) {
        int row = i / cols, col = i % cols;
        float x = W_ - m - (col + 1) * cw - col * gap;
        float y = oy + headH + row * (ch + gap);
        if (y > H_ || y + ch < 0) { if (unlocked(i)) addBtn(B_LEVEL0 + i, x, y, cw, ch); continue; }
        bool ok = unlocked(i);
        int st = stars_[i];
        Col top = st ? Col{0.12f, 0.22f, 0.24f, 0.92f} : Col{0.12f, 0.15f, 0.26f, 0.92f};
        Col bot = st ? Col{0.06f, 0.12f, 0.14f, 0.94f} : Col{0.06f, 0.07f, 0.14f, 0.94f};
        Col brd = st ? Col{0.3f, 0.7f, 0.55f, 0.9f} : Col{0.28f, 0.34f, 0.6f, 0.9f};
        float al = ok ? 1.f : 0.45f;
        ui_.rect(x, y, cw, ch, 14 * dp_, mulA(top, al), mulA(bot, al), mulA(brd, al), 1.5f);
        if (ok) {
            char num[16];
            snprintf(num, sizeof(num), "%d", i + 1);
            ui_.text(num, 28 * dp_, true, x + cw / 2, y + ch * 0.30f, 1, WHITE);
            float sz = 12.5f * dp_, w = ui_.textWidth(allLevels()[i].name, sz, false);
            if (w > cw - 10 * dp_) sz *= (cw - 10 * dp_) / w;
            ui_.text(allLevels()[i].name, sz, false, x + cw / 2, y + ch * 0.56f, 1, SOFT);
            for (int k = 0; k < 3; k++)
                ui_.icon(k < st ? ICON_STAR : ICON_STAR_EMPTY, x + cw / 2 + (1 - k) * 20 * dp_, y + ch * 0.8f, 18 * dp_, k < st ? GOLD : mulA(SOFT, 0.5f));
            addBtn(B_LEVEL0 + i, x, y, cw, ch);
        } else {
            ui_.icon(ICON_LOCK, x + cw / 2, y + ch / 2, 30 * dp_, mulA(SOFT, 0.7f));
        }
    }
    ui_.end();
}
