// منطق التطبيق: القوائم، اللعب، اللمس، الحفظ
#pragma once
#include <vector>
#include <string>
#include "platform.h"
#include "renderer.h"
#include "ui.h"
#include "game.h"

class App {
public:
    explicit App(Platform* pf) : pf_(pf) {}
    bool onSurface(int w, int h);      // يُستدعى عند توفر سطح الرسم (إعادة إنشاء الموارد)
    void onSurfaceLost();
    void onResize(int w, int h);
    void onTouch(int action, float x, float y);  // 0 ضغط، 1 حركة، 2 رفع، 3 إلغاء
    bool inPlay() const { return screen_ == 1; }
    bool onBack();                      // true = تم التعامل معه
    void frame(float dt);
    void save();
    void openLevelForTest(int i) { startLevel(i); }
    void setSolvedForTest(bool s);
    void setScreenForTest(int s) { screen_ = s; }
private:
    enum { MENU = 0, PLAY = 1 };
    struct Btn { int id; float x, y, w, h; };
    Platform* pf_;
    Renderer r_;
    Ui ui_;
    int W_ = 0, H_ = 0;
    float dp_ = 2.f;
    int screen_ = MENU;
    float t_ = 0, fade_ = 0;
    // التقدم والإعدادات
    std::vector<int> stars_;
    bool mute_ = false;
    int quality_ = 2;
    // اللعب
    int li_ = 0, moves_ = 0, sel_ = -1, drag_ = 0;
    bool changed_ = false, won_ = false;
    double offx_ = 0, offy_ = 0;
    float winT_ = 0, celebT_ = -1, hintT_ = 0;
    int camMode_ = 0;
    Board B_;
    TraceResult R_;
    // القائمة
    float scroll_ = 0, scrollVel_ = 0, scrollMax_ = 0;
    // اللمس
    bool down_ = false, moved_ = false;
    float downX_ = 0, downY_ = 0, lastY_ = 0;
    int pressBtn_ = -1;
    std::vector<Btn> btns_;

    void loadSave();
    bool unlocked(int i) const { return i == 0 || stars_[i - 1] > 0; }
    void startLevel(int i);
    void showMenu();
    void tone(float hz, int ms, float vol = 0.05f, int delay = 0);
    void doWin();
    void drawMenu(float dt);
    void drawPlay(float dt);
    void addBtn(int id, float x, float y, float w, float h) { btns_.push_back({id, x, y, w, h}); }
    int hitBtn(float x, float y) const;
    void onButton(int id);
    void playDown(float x, float y);
    void playMove(float x, float y);
    void playUp();
    bool toPlay(float sx, float sy, double& px, double& py);
    const char* qualityName() const;
};
