#include "game.h"
#include <cmath>
#include <set>

const Seg4 BORDERS[4] = {{40, 30, 536, 30}, {40, 530, 536, 530}, {40, 30, 40, 530}, {536, 30, 536, 530}};

const std::vector<LevelDef>& allLevels() {
    static const std::vector<LevelDef> L = {
#include "levels_data.inc"
    };
    return L;
}

static void norm2(double x, double y, double& ox, double& oy) {
    double l = std::hypot(x, y);
    if (l == 0) l = 1;
    ox = x / l; oy = y / l;
}

Board buildBoard(const LevelDef& L) {
    Board B;
    B.name = L.name;
    B.ex = L.ex; B.ey = L.ey; B.edx = L.edx; B.edy = L.edy;
    B.walls = L.walls;
    B.glass = L.glass;
    if (!L.X.empty()) {
        for (const auto& x : L.X) {
            Element e;
            e.x = x.x; e.y = x.y; e.a = x.a;
            e.len = x.t == 'p' ? 22 : 38;
            e.prism = x.t == 'p';
            e.split = false;
            e.fixed = x.t == 'f';
            e.sx = x.x; e.sy = x.y; e.sa = x.a;
            B.els.push_back(e);
        }
        for (const auto& t : L.T) B.T.push_back({t.x, t.y, 20, 0.f, t.c});
    }
    for (const auto& p : L.paths) {
        std::vector<PathPt> pts;
        pts.push_back({L.ex, L.ey, 1});
        for (const auto& q : p) pts.push_back(q);
        for (size_t i = 1; i < pts.size(); i++) {
            const PathPt& q = pts[i];
            if (q.t == 0) {
                bool found = false;
                for (const auto& t : B.T) if (t.x == q.x && t.y == q.y) found = true;
                if (!found) B.T.push_back({q.x, q.y, 20, 0.f, 0});
                continue;
            }
            bool dup = false;
            for (const auto& e : B.els) if (e.x == q.x && e.y == q.y) dup = true;
            if (dup) continue;
            const PathPt& a0 = pts[i - 1];
            const PathPt& b = pts[i + 1];
            double dix, diy, dox, doy;
            norm2(q.x - a0.x, q.y - a0.y, dix, diy);
            norm2(b.x - q.x, b.y - q.y, dox, doy);
            double ang = std::atan2(dox - dix, -(doy - diy));
            char t = q.t;
            Element e;
            e.x = q.x; e.y = q.y; e.a = ang;
            e.split = (t == 's' || t == 'S');
            e.len = e.split ? 34 : 38;
            e.fixed = (t == 'f' || t == 's');
            e.prism = false;
            e.sx = q.x; e.sy = q.y; e.sa = ang;
            B.els.push_back(e);
        }
    }
    std::vector<int> mv;
    for (size_t i = 0; i < B.els.size(); i++) if (!B.els[i].fixed) mv.push_back((int)i);
    double step = 440.0 / (mv.size() + 1);
    for (size_t k = 0; k < mv.size(); k++) {
        Element& e = B.els[mv[k]];
        e.x = 40 + step * (k + 1);
        e.y = 505;
        e.a = 0.4 + k * 0.9;
    }
    B.mv = (int)mv.size();
    return B;
}

Seg4 elemSeg(const Element& e) {
    double dx = std::cos(e.a) * e.len, dy = std::sin(e.a) * e.len;
    return {e.x - dx, e.y - dy, e.x + dx, e.y + dy};
}

static bool raySeg(double px, double py, double dx, double dy, const Seg4& s, double& tOut) {
    double ex = s.x2 - s.x1, ey = s.y2 - s.y1, den = dx * ey - dy * ex;
    if (std::fabs(den) < 1e-9) return false;
    double t = ((s.x1 - px) * ey - (s.y1 - py) * ex) / den;
    double u = ((s.x1 - px) * dy - (s.y1 - py) * dx) / den;
    if (t > 1e-4 && u >= 0 && u <= 1) { tOut = t; return true; }
    return false;
}
static bool rayCircle(double px, double py, double dx, double dy, double cx, double cy, double r, double& tOut) {
    double fx = px - cx, fy = py - cy, b = fx * dx + fy * dy, d = b * b - (fx * fx + fy * fy - r * r);
    if (d < 0) return false;
    double t = -b - std::sqrt(d);
    if (t > 1e-4) { tOut = t; return true; }
    return false;
}

struct Ray { double x, y, dx, dy; char c; };

void traceBoard(const Board& B, TraceResult& out) {
    out.polys.clear();
    out.hit.assign(B.T.size(), false);
    out.hitCount = 0;

    std::vector<Seg4> walls(BORDERS, BORDERS + 4);
    walls.insert(walls.end(), B.walls.begin(), B.walls.end());
    std::vector<Seg4> segs;
    for (const auto& e : B.els) segs.push_back(e.prism ? Seg4{0, 0, 0, 0} : elemSeg(e));
    struct P { double x, y, r, a; };
    std::vector<P> ps;
    for (const auto& e : B.els) if (e.prism) ps.push_back({e.x, e.y, 24, e.a});

    std::vector<Ray> q;
    q.push_back({B.ex, B.ey, B.edx, B.edy, 'w'});
    int g = 0;
    while (!q.empty() && g++ < 60) {
        Ray r = q.back(); q.pop_back();
        Poly poly;
        poly.c = r.c;
        poly.pts.push_back({r.x, r.y, 0});
        double px = r.x, py = r.y, dx = r.dx, dy = r.dy;
        for (int i = 0; i < 14; i++) {
            double best = 1e9;
            char kind = 0;
            int idx = -1;
            double t;
            for (const auto& w : walls) if (raySeg(px, py, dx, dy, w, t) && t < best) { best = t; kind = 'w'; }
            for (size_t k = 0; k < segs.size(); k++) if (raySeg(px, py, dx, dy, segs[k], t) && t < best) { best = t; kind = 'e'; idx = (int)k; }
            for (size_t k = 0; k < B.T.size(); k++) if (rayCircle(px, py, dx, dy, B.T[k].x, B.T[k].y, B.T[k].r, t) && t < best) { best = t; kind = 't'; idx = (int)k; }
            for (size_t k = 0; k < ps.size(); k++) if (rayCircle(px, py, dx, dy, ps[k].x, ps[k].y, ps[k].r, t) && t < best) { best = t; kind = 'p'; idx = (int)k; }
            if (!kind) break;
            px += dx * best; py += dy * best;
            poly.pts.push_back({px, py, kind});
            if (kind == 't') {
                const Target& T = B.T[idx];
                if (!T.c || T.c == r.c) out.hit[idx] = true;
                break;
            }
            if (kind == 'p') {
                const P& Pm = ps[idx];
                if (r.c == 'w') {
                    poly.pts.back() = {Pm.x, Pm.y, 'p'};
                    double b = std::atan2(dy, dx) + Pm.a;
                    const char cs[3] = {'r', 'g', 'b'};
                    const double os[3] = {-.32, 0, .32};
                    for (int k = 0; k < 3; k++) q.push_back({Pm.x, Pm.y, std::cos(b + os[k]), std::sin(b + os[k]), cs[k]});
                    break;
                }
                continue;
            }
            if (kind != 'e') break;
            const Seg4& s = segs[idx];
            double ex = s.x2 - s.x1, ey = s.y2 - s.y1, l = std::hypot(ex, ey), nx = -ey / l, ny = ex / l;
            double dt = dx * nx + dy * ny, rx = dx - 2 * dt * nx, ry = dy - 2 * dt * ny;
            if (B.els[idx].split) q.push_back({px, py, rx, ry, r.c});
            else { dx = rx; dy = ry; }
        }
        out.polys.push_back(poly);
    }
    int n = 0;
    for (bool h : out.hit) if (h) n++;
    out.hitCount = n;
}
