// نقطة دخول أندرويد: NativeActivity + EGL + اللمس + جسر JNI
#include <android_native_app_glue.h>
#include <android/input.h>
#include <android/configuration.h>
#include <EGL/egl.h>
#include <jni.h>
#include <time.h>
#include <string>
#include "app.h"
#include "log.h"

struct AndroidPlatform : Platform {
    android_app* app = nullptr;
    JNIEnv* env = nullptr;
    jobject act = nullptr;
    jmethodID mText = nullptr, mIcon = nullptr, mTone = nullptr;

    void attach(android_app* a) {
        app = a;
        a->activity->vm->AttachCurrentThread(&env, nullptr);
        act = a->activity->clazz;
        jclass cls = env->GetObjectClass(act);
        mText = env->GetMethodID(cls, "renderText", "(Ljava/lang/String;FZ)[I");
        mIcon = env->GetMethodID(cls, "renderIcon", "(II)[I");
        mTone = env->GetMethodID(cls, "playTone", "(FIFI)V");
        env->DeleteLocalRef(cls);
    }
    void detach() { if (app) app->activity->vm->DetachCurrentThread(); }

    bool fromArray(jintArray arr, Pixels& out) {
        if (!arr) return false;
        jsize n = env->GetArrayLength(arr);
        if (n < 3) { env->DeleteLocalRef(arr); return false; }
        std::vector<jint> buf(n);
        env->GetIntArrayRegion(arr, 0, n, buf.data());
        env->DeleteLocalRef(arr);
        out.w = buf[0]; out.h = buf[1];
        if (out.w <= 0 || out.h <= 0 || (jsize)(2 + out.w * out.h) > n) return false;
        out.rgba.resize((size_t)out.w * out.h * 4);
        for (int i = 0; i < out.w * out.h; i++) {
            uint32_t c = (uint32_t)buf[2 + i];
            out.rgba[i * 4 + 0] = (c >> 16) & 255;
            out.rgba[i * 4 + 1] = (c >> 8) & 255;
            out.rgba[i * 4 + 2] = c & 255;
            out.rgba[i * 4 + 3] = (c >> 24) & 255;
        }
        return true;
    }
    bool renderText(const char* utf8, float px, bool bold, Pixels& out) override {
        jstring js = env->NewStringUTF(utf8);
        jintArray arr = (jintArray)env->CallObjectMethod(act, mText, js, px, (jboolean)bold);
        env->DeleteLocalRef(js);
        if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
        return fromArray(arr, out);
    }
    bool renderIcon(int id, int px, Pixels& out) override {
        jintArray arr = (jintArray)env->CallObjectMethod(act, mIcon, (jint)id, (jint)px);
        if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
        return fromArray(arr, out);
    }
    void playTone(float hz, int ms, float vol, int delayMs) override {
        env->CallVoidMethod(act, mTone, hz, (jint)ms, vol, (jint)delayMs);
        if (env->ExceptionCheck()) env->ExceptionClear();
    }
    std::string dataDir() override { return app->activity->internalDataPath ? app->activity->internalDataPath : "/data/local/tmp"; }
    float density() override {
        int32_t d = app->config ? AConfiguration_getDensity(app->config) : 0;
        if (d <= 0 || d > 1000) d = 320;
        return d / 160.0f;
    }
};

struct Egl {
    EGLDisplay dpy = EGL_NO_DISPLAY;
    EGLSurface surf = EGL_NO_SURFACE;
    EGLContext ctx = EGL_NO_CONTEXT;
    EGLConfig cfg = nullptr;
    int w = 0, h = 0;
};

static bool eglStart(Egl& e, ANativeWindow* win) {
    e.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(e.dpy, nullptr, nullptr);
    const EGLint attrs[] = {EGL_RENDERABLE_TYPE, 0x0040 /*EGL_OPENGL_ES3_BIT*/, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                            EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 0,
                            EGL_DEPTH_SIZE, 0, EGL_NONE};
    EGLint n = 0;
    if (!eglChooseConfig(e.dpy, attrs, &e.cfg, 1, &n) || n < 1) { LOGE("no ES3 EGL config"); return false; }
    EGLint fmt = 0;
    eglGetConfigAttrib(e.dpy, e.cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(win, 0, 0, fmt);
    e.surf = eglCreateWindowSurface(e.dpy, e.cfg, win, nullptr);
    const EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    e.ctx = eglCreateContext(e.dpy, e.cfg, EGL_NO_CONTEXT, ca);
    if (e.surf == EGL_NO_SURFACE || e.ctx == EGL_NO_CONTEXT) { LOGE("EGL create failed"); return false; }
    if (!eglMakeCurrent(e.dpy, e.surf, e.surf, e.ctx)) { LOGE("eglMakeCurrent failed"); return false; }
    eglSwapInterval(e.dpy, 1);
    eglQuerySurface(e.dpy, e.surf, EGL_WIDTH, &e.w);
    eglQuerySurface(e.dpy, e.surf, EGL_HEIGHT, &e.h);
    return true;
}
static void eglStop(Egl& e) {
    if (e.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(e.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (e.ctx != EGL_NO_CONTEXT) eglDestroyContext(e.dpy, e.ctx);
        if (e.surf != EGL_NO_SURFACE) eglDestroySurface(e.dpy, e.surf);
        eglTerminate(e.dpy);
    }
    e.dpy = EGL_NO_DISPLAY; e.surf = EGL_NO_SURFACE; e.ctx = EGL_NO_CONTEXT;
}

struct State {
    android_app* app = nullptr;
    Egl egl;
    AndroidPlatform plat;
    App* game = nullptr;
    bool hasWindow = false, focused = false, gl = false;
};

static void onCmd(android_app* app, int32_t cmd) {
    State* st = (State*)app->userData;
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window) {
                st->hasWindow = true;
                if (eglStart(st->egl, app->window)) {
                    st->gl = st->game->onSurface(st->egl.w, st->egl.h);
                }
            }
            break;
        case APP_CMD_TERM_WINDOW:
            if (st->gl) st->game->onSurfaceLost();
            st->gl = false;
            eglStop(st->egl);
            st->hasWindow = false;
            break;
        case APP_CMD_GAINED_FOCUS: st->focused = true; break;
        case APP_CMD_LOST_FOCUS: st->focused = false; break;
        case APP_CMD_PAUSE: st->game->save(); break;
        default: break;
    }
}

static int32_t onInput(android_app* app, AInputEvent* ev) {
    State* st = (State*)app->userData;
    int32_t type = AInputEvent_getType(ev);
    if (type == AINPUT_EVENT_TYPE_MOTION) {
        int32_t act = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
        float x = AMotionEvent_getX(ev, 0), y = AMotionEvent_getY(ev, 0);
        int a = -1;
        if (act == AMOTION_EVENT_ACTION_DOWN) a = 0;
        else if (act == AMOTION_EVENT_ACTION_MOVE) a = 1;
        else if (act == AMOTION_EVENT_ACTION_UP) a = 2;
        else if (act == AMOTION_EVENT_ACTION_CANCEL) a = 3;
        if (a >= 0 && st->gl) st->game->onTouch(a, x, y);
        return 1;
    }
    if (type == AINPUT_EVENT_TYPE_KEY) {
        if (AKeyEvent_getKeyCode(ev) == AKEYCODE_BACK) {
            if (AKeyEvent_getAction(ev) == AKEY_EVENT_ACTION_UP) return st->game->onBack() ? 1 : 0;
            return st->game->inPlay() ? 1 : 0;
        }
    }
    return 0;
}

static double nowSec() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

void android_main(android_app* app) {
    State st;
    st.app = app;
    st.plat.attach(app);
    st.game = new App(&st.plat);
    app->userData = &st;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    double last = nowSec();
    while (true) {
        int events;
        android_poll_source* src;
        while (ALooper_pollOnce((st.hasWindow && st.focused) ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) {
                if (st.gl) st.game->onSurfaceLost();
                eglStop(st.egl);
                delete st.game;
                st.plat.detach();
                return;
            }
        }
        if (st.hasWindow && st.focused && st.gl) {
            int w = 0, h = 0;
            eglQuerySurface(st.egl.dpy, st.egl.surf, EGL_WIDTH, &w);
            eglQuerySurface(st.egl.dpy, st.egl.surf, EGL_HEIGHT, &h);
            if (w > 0 && h > 0 && (w != st.egl.w || h != st.egl.h)) { st.egl.w = w; st.egl.h = h; st.game->onResize(w, h); }
            double now = nowSec();
            float dt = (float)(now - last);
            last = now;
            st.game->frame(dt);
            eglSwapBuffers(st.egl.dpy, st.egl.surf);
        } else {
            last = nowSec();
        }
    }
}
