// كل الشيدرز (GLSL ES 3.00) مكتوبة كنصوص داخل الكود
#pragma once

// ---------------- رؤوس المجسّمات ----------------
static const char* __attribute__((unused)) VS_MESH = R"GLSL(#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
out vec3 vWP;
out vec3 vN;
out vec2 vUV;
void main(){
  vec4 wp = uModel * vec4(aPos, 1.0);
  vWP = wp.xyz;
  vN = mat3(uModel) * aNrm;
  vUV = aUV;
  gl_Position = uVP * wp;
}
)GLSL";

static const char* __attribute__((unused)) VS_SHADOW = R"GLSL(#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
uniform mat4 uLightVP;
uniform mat4 uModel;
void main(){
  gl_Position = uLightVP * uModel * vec4(aPos, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_SHADOW = R"GLSL(#version 300 es
precision highp float;
void main(){}
)GLSL";

// ---------------- الإضاءة المشتركة ----------------
static const char* __attribute__((unused)) FS_COMMON = R"GLSL(#version 300 es
precision highp float;
precision highp int;
#define MAXSEG 32
in vec3 vWP;
in vec3 vN;
in vec2 vUV;
out vec4 outColor;
uniform vec3 uCam;
uniform vec3 uSunDir;
uniform vec3 uSunCol;
uniform vec3 uAmbSky;
uniform vec3 uAmbGnd;
uniform int uNSeg;
uniform vec4 uSegA[MAXSEG];
uniform vec4 uSegB[MAXSEG];
uniform vec4 uSegC[MAXSEG];
uniform highp sampler2DShadow uShadow;
uniform mat4 uLightVP;
uniform vec2 uShadowTexel;
uniform float uShadowOn;
uniform float uTime;

float hash21(vec2 p){
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float vnoise(vec2 p){
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
// تغيير العمودي حسب ارتفاع السطح (نتوءات) باستخدام المشتقات
vec3 perturbN(vec3 P, vec3 N, float h, float k){
  vec3 dpdx = dFdx(P);
  vec3 dpdy = dFdy(P);
  float dhx = dFdx(h);
  float dhy = dFdy(h);
  vec3 r1 = cross(dpdy, N);
  vec3 r2 = cross(N, dpdx);
  float det = dot(dpdx, r1);
  vec3 grad = sign(det) * (dhx * r1 + dhy * r2);
  return normalize(abs(det) * N - k * grad);
}
float shadowAt(vec3 wp, vec3 n){
  if(uShadowOn < 0.5) return 1.0;
  vec4 lp = uLightVP * vec4(wp + n * 0.025, 1.0);
  vec3 q = lp.xyz / lp.w * 0.5 + 0.5;
  if(q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0 || q.z > 1.0) return 1.0;
  float s = 0.0;
  for(int i = -1; i <= 1; i++){
    for(int j = -1; j <= 1; j++){
      s += texture(uShadow, vec3(q.xy + vec2(float(i), float(j)) * uShadowTexel, q.z - 0.0012));
    }
  }
  return s / 9.0;
}
vec3 envMap(vec3 R){
  float h = R.y * 0.5 + 0.5;
  vec3 top = vec3(0.16, 0.24, 0.46);
  vec3 hor = vec3(0.05, 0.08, 0.16);
  vec3 bot = vec3(0.012, 0.02, 0.04);
  vec3 c = mix(hor, top, smoothstep(0.5, 1.0, h));
  c = mix(c, bot, smoothstep(0.5, 0.15, h));
  float strip = smoothstep(0.90, 0.99, sin(R.x * 3.2 + R.z * 1.7)) * smoothstep(0.55, 0.9, R.y);
  c += vec3(0.55, 0.68, 1.0) * strip * 0.9;
  return c;
}
void beamLight(vec3 p, vec3 n, vec3 V, float shin, out vec3 dif, out vec3 spe){
  dif = vec3(0.0);
  spe = vec3(0.0);
  for(int i = 0; i < MAXSEG; i++){
    if(i >= uNSeg) break;
    vec3 a = uSegA[i].xyz;
    vec3 b = uSegB[i].xyz;
    vec3 ab = b - a;
    float t = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-5), 0.0, 1.0);
    vec3 L = a + ab * t - p;
    float d2 = dot(L, L);
    vec3 Ln = L * inversesqrt(d2 + 1e-4);
    float att = uSegC[i].w / (1.0 + 5.0 * d2);
    float nl = max(dot(n, Ln), 0.0) * 0.7 + 0.3;
    dif += uSegC[i].rgb * att * nl;
    vec3 H = normalize(Ln + V);
    spe += uSegC[i].rgb * att * pow(max(dot(n, H), 0.0), shin);
  }
}
vec3 aces(vec3 x){
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
vec3 finishColor(vec3 c, vec3 wp){
  float d = length(uCam - wp);
  float f = 1.0 - exp(-d * 0.012);
  c = mix(c, vec3(0.012, 0.02, 0.045), f * 0.55);
  c = aces(c);
  return pow(c, vec3(1.0 / 2.2));
}
)GLSL";

// ---------------- الأرضية ----------------
static const char* __attribute__((unused)) FS_FLOOR_MAIN = R"GLSL(
void main(){
  vec2 p = vWP.xz;
  float tile = 0.8;
  vec2 tp = p / tile;
  vec2 id = floor(tp);
  vec2 fp = fract(tp);
  float rnd = hash21(id);
  vec2 e = min(fp, 1.0 - fp) * tile;
  float edge = min(e.x, e.y);
  float groove = smoothstep(0.004, 0.026, edge);
  float bevel = smoothstep(0.026, 0.07, edge);
  float grain = vnoise(p * 9.0) * 0.55 + vnoise(p * 31.0) * 0.3;
  vec3 base = mix(vec3(0.030, 0.042, 0.075), vec3(0.055, 0.072, 0.12), rnd);
  base *= 0.78 + 0.5 * grain;
  vec3 alb = base * (0.35 + 0.65 * groove) * (0.9 + 0.2 * bevel);
  float h = groove * 0.55 + bevel * 0.2 + grain * 0.12;
  vec3 N0 = vec3(0.0, 1.0, 0.0);
  vec3 N = perturbN(vWP, N0, h, 0.02);
  vec3 V = normalize(uCam - vWP);
  float sh = shadowAt(vWP, N0);
  vec3 amb = mix(uAmbGnd, uAmbSky, 0.75);
  float ndl = max(dot(N, uSunDir), 0.0);
  vec3 c = alb * (amb + uSunCol * ndl * sh);
  vec3 dif, spe;
  beamLight(vWP, N, V, 70.0, dif, spe);
  c += alb * dif * 2.2 + spe * 0.5 * (0.4 + 0.6 * groove);
  float fr = pow(1.0 - max(dot(N, V), 0.0), 5.0);
  c += envMap(reflect(-V, N)) * (0.025 + 0.35 * fr) * groove;
  // خطوط مضيئة خفيفة بين البلاطات (طابع تقني)
  c += vec3(0.04, 0.09, 0.2) * (1.0 - groove) * 0.30;
  outColor = vec4(finishColor(c, vWP), 1.0);
}
)GLSL";

// ---------------- الجدران (حجر + طوب) ----------------
static const char* __attribute__((unused)) FS_WALL_MAIN = R"GLSL(
void main(){
  vec3 N0 = normalize(vN);
  vec2 uv;
  if(abs(N0.x) > 0.5) uv = vWP.zy;
  else if(abs(N0.z) > 0.5) uv = vWP.xy;
  else uv = vWP.xz;
  float top = step(0.5, N0.y);
  vec2 bs = vec2(0.42, 0.2);
  float row = floor(uv.y / bs.y);
  float off = mod(row, 2.0) * 0.5;
  vec2 bp = vec2(uv.x / bs.x + off, uv.y / bs.y);
  vec2 bid = floor(bp);
  vec2 bf = fract(bp);
  float rnd = hash21(bid + 7.0);
  vec2 e = min(bf, 1.0 - bf) * bs;
  float edge = min(e.x, e.y);
  float mort = smoothstep(0.008, 0.024, edge);
  float grain = vnoise(uv * 20.0) * 0.55 + vnoise(uv * 63.0) * 0.3;
  vec3 brickCol = mix(vec3(0.16, 0.20, 0.30), vec3(0.25, 0.30, 0.42), rnd) * (0.72 + 0.55 * grain);
  vec3 alb = mix(vec3(0.045, 0.055, 0.085), brickCol, mort);
  vec3 capCol = vec3(0.17, 0.21, 0.31) * (0.8 + 0.4 * grain);
  alb = mix(alb, capCol, top);
  float h = mix(mort * 0.6 + grain * 0.2, 0.5 + grain * 0.1, top);
  vec3 N = perturbN(vWP, N0, h, 0.02);
  vec3 V = normalize(uCam - vWP);
  float sh = shadowAt(vWP, N0);
  vec3 amb = mix(uAmbGnd, uAmbSky, N.y * 0.5 + 0.5);
  float ndl = max(dot(N, uSunDir), 0.0);
  float ao = mix(0.5, 1.0, smoothstep(0.0, 0.55, vWP.y));
  vec3 c = alb * (amb * ao + uSunCol * ndl * sh);
  vec3 dif, spe;
  beamLight(vWP, N, V, 40.0, dif, spe);
  c += alb * dif * 1.9 + spe * 0.25 * mort;
  float fr = pow(1.0 - max(dot(N, V), 0.0), 4.0);
  c += vec3(0.10, 0.16, 0.32) * fr * 0.35 * top;
  outColor = vec4(finishColor(c, vWP), 1.0);
}
)GLSL";

// ---------------- مادة عامة (معدن/حجر) ----------------
static const char* __attribute__((unused)) FS_OBJ_MAIN = R"GLSL(
uniform vec3 uAlbedo;
uniform float uMetal;
uniform float uRough;
uniform vec3 uEmis;
uniform vec3 uRim;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCam - vWP);
  float sh = shadowAt(vWP, N);
  vec3 amb = mix(uAmbGnd, uAmbSky, N.y * 0.5 + 0.5);
  float ndl = max(dot(N, uSunDir), 0.0);
  vec3 diffCol = uAlbedo * (1.0 - uMetal);
  vec3 f0 = mix(vec3(0.045), uAlbedo, uMetal);
  vec3 c = diffCol * (amb + uSunCol * ndl * sh);
  float shin = mix(120.0, 10.0, uRough);
  vec3 dif, spe;
  beamLight(vWP, N, V, shin, dif, spe);
  float ndv = max(dot(N, V), 0.0);
  float fr = pow(1.0 - ndv, 5.0);
  vec3 F = f0 + (1.0 - f0) * fr;
  c += diffCol * dif * 1.6 + spe * F * 2.5;
  vec3 R = reflect(-V, N);
  c += envMap(R) * F * (1.0 - uRough * 0.75) * (0.4 + 0.8 * sh);
  vec3 H = normalize(uSunDir + V);
  c += uSunCol * F * pow(max(dot(N, H), 0.0), shin) * sh * 0.8;
  c += uEmis;
  c += uRim * pow(1.0 - ndv, 2.0);
  outColor = vec4(finishColor(c, vWP), 1.0);
}
)GLSL";

// ---------------- زجاج المرآة (عاكس) ----------------
static const char* __attribute__((unused)) FS_MIRROR_MAIN = R"GLSL(
uniform vec3 uRim;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCam - vWP);
  if(dot(N, V) < 0.0) N = -N;
  float ndv = max(dot(N, V), 0.0);
  float fr = pow(1.0 - ndv, 4.0);
  vec3 R = reflect(-V, N);
  vec3 c = vec3(0.012, 0.02, 0.04);
  c += envMap(R) * (0.55 + 0.6 * fr);
  float sweep = smoothstep(0.55, 1.0, sin(vUV.x * 2.6 + vUV.y * 5.0 + 0.8));
  c += vec3(0.5, 0.7, 1.0) * sweep * 0.22;
  vec3 dif, spe;
  beamLight(vWP, N, V, 90.0, dif, spe);
  c += vec3(0.7, 0.85, 1.0) * dif * 0.9 + spe * 2.2;
  c += uRim * (0.4 + 1.2 * fr);
  outColor = vec4(finishColor(c, vWP), 1.0);
}
)GLSL";

// ---------------- زجاج شفاف (مقسّم/منشور/بلّورة/تلميح) ----------------
static const char* __attribute__((unused)) FS_GLASS_MAIN = R"GLSL(
uniform vec3 uTint;
uniform float uAlpha;
uniform float uGlow;
uniform float uRainbow;
uniform float uStripe;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCam - vWP);
  if(dot(N, V) < 0.0) N = -N;
  float ndv = max(dot(N, V), 0.0);
  float fr = pow(1.0 - ndv, 3.0);
  vec3 R = reflect(-V, N);
  vec3 c = envMap(R) * (0.3 + 0.9 * fr);
  c += uTint * (0.18 + 0.55 * fr);
  vec3 dif, spe;
  beamLight(vWP, N, V, 60.0, dif, spe);
  c += uTint * dif * 0.7 + spe * 0.9;
  c += uTint * uGlow;
  if(uRainbow > 0.0){
    vec3 rb = 0.5 + 0.5 * cos(6.2831 * (vec3(0.0, 0.33, 0.67) + fr * 1.3 + vWP.y * 0.7 + uTime * 0.05));
    c += rb * uRainbow * (0.25 + 0.9 * fr);
  }
  if(uStripe > 0.0){
    float s = smoothstep(0.5, 0.6, abs(sin(vUV.x * 15.0 + uTime * 1.4)));
    c += uTint * s * 0.55 * uStripe;
  }
  float a = clamp(uAlpha + fr * 0.45 + length(spe) * 0.4 + uGlow * 0.15, 0.0, 0.93);
  outColor = vec4(finishColor(c, vWP), a);
}
)GLSL";

// ---------------- مؤثرات الإضاءة (الشعاع / الهالة / النجمة) ----------------
static const char* __attribute__((unused)) VS_FX = R"GLSL(#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aCol;
uniform mat4 uVP;
out vec2 vUV;
out vec4 vCol;
void main(){
  vUV = aUV;
  vCol = aCol;
  gl_Position = uVP * vec4(aPos, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_BEAM = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
in vec4 vCol;
out vec4 outColor;
uniform float uTime;
void main(){
  float x = abs(vUV.x);
  float core = exp(-x * x * 55.0);
  float mid = exp(-x * x * 9.0);
  float halo = exp(-x * x * 2.8);
  float edgeFade = 1.0 - smoothstep(0.65, 1.0, x);
  float fl = 0.93 + 0.07 * sin(vUV.y * 16.0 - uTime * 13.0) + 0.04 * sin(vUV.y * 41.0 + uTime * 7.0);
  vec3 coreC = mix(vec3(1.0), vCol.rgb, 0.16);
  vec3 c = coreC * core * 1.15 + vCol.rgb * mid * 0.7 + vCol.rgb * halo * 0.22;
  outColor = vec4(c * fl * edgeFade * vCol.a, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_GLOW = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
in vec4 vCol;
out vec4 outColor;
void main(){
  float d = length(vUV);
  float g = exp(-d * d * 5.0) * (1.0 - smoothstep(0.75, 1.0, d));
  outColor = vec4(vCol.rgb * g * vCol.a, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_STAR = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
in vec4 vCol;
out vec4 outColor;
void main(){
  float ax = abs(vUV.x);
  float ay = abs(vUV.y);
  float s = exp(-ay * 34.0) * exp(-ax * 3.2) + exp(-ax * 34.0) * exp(-ay * 3.2);
  float d = length(vUV);
  s *= 1.0 - smoothstep(0.7, 1.0, d);
  outColor = vec4(vCol.rgb * s * vCol.a, 1.0);
}
)GLSL";

// ---------------- ما بعد المعالجة ----------------
static const char* __attribute__((unused)) VS_FULL = R"GLSL(#version 300 es
precision highp float;
out vec2 vUV;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUV = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_BRIGHT = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform float uThresh;
void main(){
  vec3 c = texture(uTex, vUV + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(1.0, 1.0)).rgb;
  c *= 0.25;
  float l = max(c.r, max(c.g, c.b));
  float w = smoothstep(uThresh, uThresh + 0.4, l);
  outColor = vec4(c * w, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_DOWN = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uTex;
uniform vec2 uTexel;
void main(){
  vec3 c = texture(uTex, vUV + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture(uTex, vUV + uTexel * vec2(1.0, 1.0)).rgb;
  outColor = vec4(c * 0.25, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_BLUR = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uTex;
uniform vec2 uDir;
void main(){
  vec3 c = texture(uTex, vUV).rgb * 0.2270270270;
  c += texture(uTex, vUV + uDir * 1.3846153846).rgb * 0.3162162162;
  c += texture(uTex, vUV - uDir * 1.3846153846).rgb * 0.3162162162;
  c += texture(uTex, vUV + uDir * 3.2307692308).rgb * 0.0702702703;
  c += texture(uTex, vUV - uDir * 3.2307692308).rgb * 0.0702702703;
  outColor = vec4(c, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_COMPOSITE = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
out vec4 outColor;
uniform sampler2D uScene;
uniform sampler2D uBloom1;
uniform sampler2D uBloom2;
uniform float uBloomI;
uniform float uDim;
uniform float uFade;
uniform float uTime;
uniform vec2 uRes;
void main(){
  vec2 uv = vUV;
  vec2 cc = uv - 0.5;
  float r2 = dot(cc, cc);
  vec2 ca = cc * r2 * 0.014;
  vec3 c;
  c.r = texture(uScene, uv + ca).r;
  c.g = texture(uScene, uv).g;
  c.b = texture(uScene, uv - ca).b;
  vec3 bl = texture(uBloom1, uv).rgb * 0.7 + texture(uBloom2, uv).rgb * 0.9;
  c += bl * uBloomI;
  float lum = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(lum), c, 1.1);
  float vg = 1.0 - smoothstep(0.30, 0.95, length(cc) * 1.35);
  c *= mix(0.42, 1.0, vg);
  float g = fract(sin(dot(uv * uRes + fract(uTime) * 91.7, vec2(12.9898, 78.233))) * 43758.5453);
  c += (g - 0.5) * 0.016;
  c *= mix(1.0, 0.36, uDim) * uFade;
  outColor = vec4(c, 1.0);
}
)GLSL";

// ---------------- الواجهة ثنائية الأبعاد ----------------
static const char* __attribute__((unused)) VS_UI = R"GLSL(#version 300 es
precision highp float;
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
uniform vec2 uScreen;
out vec2 vUV;
out vec2 vPx;
void main(){
  vUV = aUV;
  vPx = aPos;
  vec2 n = aPos / uScreen * 2.0 - 1.0;
  gl_Position = vec4(n.x, -n.y, 0.0, 1.0);
}
)GLSL";

static const char* __attribute__((unused)) FS_UI_RECT = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
in vec2 vPx;
out vec4 outColor;
uniform vec4 uRect;
uniform float uRad;
uniform vec4 uColTop;
uniform vec4 uColBot;
uniform vec4 uBorder;
uniform float uBorderW;
float sdRound(vec2 p, vec2 b, float r){
  vec2 q = abs(p) - b + r;
  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}
void main(){
  vec2 c = uRect.xy + uRect.zw * 0.5;
  float sd = sdRound(vPx - c, uRect.zw * 0.5, uRad);
  float fillA = 1.0 - smoothstep(-0.75, 0.75, sd);
  float t = clamp((vPx.y - uRect.y) / max(uRect.w, 1.0), 0.0, 1.0);
  vec4 col = mix(uColTop, uColBot, t);
  float ring = fillA * smoothstep(-uBorderW - 0.75, -uBorderW + 0.25, sd) * step(0.01, uBorderW);
  vec3 rgb = mix(col.rgb, uBorder.rgb, ring * uBorder.a);
  float a = max(col.a * fillA, ring * uBorder.a);
  outColor = vec4(rgb, a);
}
)GLSL";

static const char* __attribute__((unused)) FS_UI_TEX = R"GLSL(#version 300 es
precision highp float;
in vec2 vUV;
in vec2 vPx;
out vec4 outColor;
uniform sampler2D uTex;
uniform vec4 uTint;
void main(){
  vec4 t = texture(uTex, vUV);
  outColor = vec4(uTint.rgb * t.rgb, t.a * uTint.a);
}
)GLSL";
