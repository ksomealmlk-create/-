// توليد المجسّمات الثلاثية الأبعاد برمجياً (بدون ملفات خارجية)
// كل رأس: موضع(3) + عمودي(3) + إحداثيات نسيج(2)
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include "m3.h"

struct MeshData {
    std::vector<float> v;
    std::vector<uint16_t> i;
    uint16_t base() const { return (uint16_t)(v.size() / 8); }
    void vert(vec3 p, vec3 n, float u, float w) {
        v.push_back(p.x); v.push_back(p.y); v.push_back(p.z);
        v.push_back(n.x); v.push_back(n.y); v.push_back(n.z);
        v.push_back(u); v.push_back(w);
    }
    void tri(int a, int b, int c) { i.push_back((uint16_t)a); i.push_back((uint16_t)b); i.push_back((uint16_t)c); }
    void quad(int a, int b, int c, int d) { tri(a, b, c); tri(a, c, d); }
};

inline void meshFace(MeshData& m, vec3 a, vec3 b, vec3 c, vec3 d, vec3 n) {
    uint16_t o = m.base();
    auto uvOf = [&](vec3 p, float& u, float& w) {
        if (std::fabs(n.x) > 0.5f) { u = p.z; w = p.y; }
        else if (std::fabs(n.y) > 0.5f) { u = p.x; w = p.z; }
        else { u = p.x; w = p.y; }
    };
    float u, w;
    uvOf(a, u, w); m.vert(a, n, u, w);
    uvOf(b, u, w); m.vert(b, n, u, w);
    uvOf(c, u, w); m.vert(c, n, u, w);
    uvOf(d, u, w); m.vert(d, n, u, w);
    m.quad(o, o + 1, o + 2, o + 3);
}

// صندوق محوري: المركز c ونصف الأبعاد h
inline void addBox(MeshData& m, vec3 c, vec3 h) {
    float x0 = c.x - h.x, x1 = c.x + h.x, y0 = c.y - h.y, y1 = c.y + h.y, z0 = c.z - h.z, z1 = c.z + h.z;
    meshFace(m, {x1, y0, z1}, {x1, y0, z0}, {x1, y1, z0}, {x1, y1, z1}, {1, 0, 0});
    meshFace(m, {x0, y0, z0}, {x0, y0, z1}, {x0, y1, z1}, {x0, y1, z0}, {-1, 0, 0});
    meshFace(m, {x0, y1, z1}, {x1, y1, z1}, {x1, y1, z0}, {x0, y1, z0}, {0, 1, 0});
    meshFace(m, {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1}, {0, -1, 0});
    meshFace(m, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}, {0, 0, 1});
    meshFace(m, {x1, y0, z0}, {x0, y0, z0}, {x0, y1, z0}, {x1, y1, z0}, {0, 0, -1});
}

// أسطوانة/مخروط ناقص حول المحور Y: القاعدة عند base.y
inline void addCyl(MeshData& m, vec3 base, float r0, float r1, float h, int seg, bool caps = true) {
    uint16_t o = m.base();
    float slope = (r0 - r1) / (h > 1e-6f ? h : 1.f);
    for (int k = 0; k <= seg; k++) {
        float a = 6.2831853f * k / seg, cs = std::cos(a), sn = std::sin(a);
        vec3 n = normalize(vec3(cs, slope, sn));
        m.vert({base.x + cs * r0, base.y, base.z + sn * r0}, n, (float)k / seg, 0);
        m.vert({base.x + cs * r1, base.y + h, base.z + sn * r1}, n, (float)k / seg, 1);
    }
    for (int k = 0; k < seg; k++) {
        int a = o + k * 2;
        m.quad(a, a + 2, a + 3, a + 1);
    }
    if (caps) {
        for (int side = 0; side < 2; side++) {
            float r = side ? r1 : r0, y = base.y + (side ? h : 0);
            vec3 n = {0, side ? 1.f : -1.f, 0};
            uint16_t c = m.base();
            m.vert({base.x, y, base.z}, n, 0.5f, 0.5f);
            for (int k = 0; k <= seg; k++) {
                float a = 6.2831853f * k / seg;
                m.vert({base.x + std::cos(a) * r, y, base.z + std::sin(a) * r}, n, 0.5f + 0.5f * std::cos(a), 0.5f + 0.5f * std::sin(a));
            }
            for (int k = 0; k < seg; k++) m.tri(c, c + 1 + k, c + 2 + k);
        }
    }
}

// أسطوانة أفقية على المحور X (للماسورة)
inline void addCylX(MeshData& m, vec3 c, float r, float len, int seg) {
    uint16_t o = m.base();
    for (int k = 0; k <= seg; k++) {
        float a = 6.2831853f * k / seg, cs = std::cos(a), sn = std::sin(a);
        vec3 n = {0, cs, sn};
        m.vert({c.x - len * 0.5f, c.y + cs * r, c.z + sn * r}, n, 0, (float)k / seg);
        m.vert({c.x + len * 0.5f, c.y + cs * r, c.z + sn * r}, n, 1, (float)k / seg);
    }
    for (int k = 0; k < seg; k++) {
        int a = o + k * 2;
        m.quad(a, a + 2, a + 3, a + 1);
    }
}

inline void addSphere(MeshData& m, vec3 c, float r, int lat, int lon) {
    uint16_t o = m.base();
    for (int i = 0; i <= lat; i++) {
        float th = 3.14159265f * i / lat, st = std::sin(th), ct = std::cos(th);
        for (int j = 0; j <= lon; j++) {
            float ph = 6.2831853f * j / lon;
            vec3 n = {st * std::cos(ph), ct, st * std::sin(ph)};
            m.vert(c + n * r, n, (float)j / lon, (float)i / lat);
        }
    }
    for (int i = 0; i < lat; i++)
        for (int j = 0; j < lon; j++) {
            int a = o + i * (lon + 1) + j, b = a + lon + 1;
            m.quad(a, b, b + 1, a + 1);
        }
}

// حلقة (توروس) أفقية حول Y
inline void addTorus(MeshData& m, vec3 c, float R, float r, int seg, int sides) {
    uint16_t o = m.base();
    for (int i = 0; i <= seg; i++) {
        float a = 6.2831853f * i / seg, ca = std::cos(a), sa = std::sin(a);
        for (int j = 0; j <= sides; j++) {
            float b = 6.2831853f * j / sides, cb = std::cos(b), sb = std::sin(b);
            vec3 n = {cb * ca, sb, cb * sa};
            m.vert({c.x + (R + r * cb) * ca, c.y + r * sb, c.z + (R + r * cb) * sa}, n, (float)i / seg, (float)j / sides);
        }
    }
    for (int i = 0; i < seg; i++)
        for (int j = 0; j < sides; j++) {
            int a = o + i * (sides + 1) + j, b = a + sides + 1;
            m.quad(a, b, b + 1, a + 1);
        }
}

// ثماني السطوح (بلّورة) بعمودي مسطّح لكل وجه
inline void addOcta(MeshData& m, vec3 c, float rx, float ry, float rz) {
    vec3 P[6] = {{rx, 0, 0}, {-rx, 0, 0}, {0, ry, 0}, {0, -ry, 0}, {0, 0, rz}, {0, 0, -rz}};
    int F[8][3] = {{0, 2, 4}, {4, 2, 1}, {1, 2, 5}, {5, 2, 0}, {4, 3, 0}, {1, 3, 4}, {5, 3, 1}, {0, 3, 5}};
    for (auto& f : F) {
        vec3 a = P[f[0]], b = P[f[1]], d = P[f[2]];
        vec3 n = normalize(cross(b - a, d - a));
        uint16_t o = m.base();
        m.vert(c + a, n, 0, 0);
        m.vert(c + b, n, 1, 0);
        m.vert(c + d, n, 0.5f, 1);
        m.tri(o, o + 1, o + 2);
    }
}

// منشور مثلثي: رؤوس المثلث على زوايا -90°+k*120° في المستوى XZ
inline void addTriPrism(MeshData& m, vec3 base, float R, float h) {
    vec3 p[3];
    for (int k = 0; k < 3; k++) {
        float a = -1.5707963f + k * 2.0943951f;
        p[k] = {base.x + std::cos(a) * R, base.y, base.z + std::sin(a) * R};
    }
    for (int k = 0; k < 3; k++) {
        vec3 a = p[k], b = p[(k + 1) % 3];
        vec3 n = normalize(cross(vec3(0, 1, 0), b - a));
        n = n * -1.0f;
        // التأكد أن العمودي يتجه للخارج
        vec3 mid = (a + b) * 0.5f;
        if (dot(n, mid - base) < 0) n = n * -1.0f;
        uint16_t o = m.base();
        m.vert(a, n, 0, 0);
        m.vert(b, n, 1, 0);
        m.vert(b + vec3(0, h, 0), n, 1, 1);
        m.vert(a + vec3(0, h, 0), n, 0, 1);
        m.quad(o, o + 1, o + 2, o + 3);
    }
    for (int side = 0; side < 2; side++) {
        vec3 n = {0, side ? 1.f : -1.f, 0};
        uint16_t o = m.base();
        for (int k = 0; k < 3; k++) m.vert(p[k] + vec3(0, side ? h : 0, 0), n, p[k].x, p[k].z);
        m.tri(o, o + 1, o + 2);
    }
}
