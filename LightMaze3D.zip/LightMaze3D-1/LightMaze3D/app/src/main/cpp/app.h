// منطق التطبيق: القوائم، اللعب، اللمس، الحفظ
#pragma once
#include <vector>
#include <string>
#include "platform.h"
#include "renderer.h"
#include "ui.h"
#include "game.h"

class App {
public:
    explicit App(Platform* pf) : pf_(pf) {}
    bool onSurface(int w, int h);      // يُستدعى عند توفر سطح الرسم (إعادة إنشاء الموارد)
    void onSurfaceLost();
    void onResize(int w, int h);
    void onTouch(int action, float x, float y);  // 0 ضغط، 1 حركة، 2 رفع، 3 إلغاء
    bool inPlay() const { return screen_ == 1; }
    bool onBack();                      // true = تم التعامل معه
    void frame(float dt);
    void save();
    void openLevelForTest(int i, int mode = 1) { startLevel(i, mode); }
    void setSolvedForTest(bool s);
    void setScreenForTest(int s) { screen_ = s; }
    void exhaustForTest() { moves_ = limit_; }
    void tabForTest(int t) { menuTab_ = t; autoScroll_ = true; }
private:
    enum { MENU = 0, PLAY = 1 };
    struct Btn { int id; float x, y, w, h; };
    Platform* pf_;
    Renderer r_;
    Ui ui_;
    int W_ = 0, H_ = 0;
    float dp_ = 2.f;
    int screen_ = MENU;
    float t_ = 0, fade_ = 0;
    // التقدم والإعدادات
    std::vector<int> stars_, cstars_;      // نجوم الوضع الحر / وضع التحدي
    int menuTab_ = 0;                      // 0 تحدي، 1 حر
    int playMode_ = 0;                     // الوضع الجاري لعبه
    bool mute_ = false;
    int quality_ = 2;
    // اللعب
    int li_ = 0, moves_ = 0, sel_ = -1, drag_ = 0;
    bool changed_ = false, won_ = false, lost_ = false;
    int hintEl_ = -1, limit_ = 0, lastTap_ = 0;
    float loseT_ = 0, toastT_ = 0, titleTapT_ = 0;
    int titleTaps_ = 0;
    bool autoScroll_ = true;
    std::string toast_;
    char nameBuf_[64] = {0};
    double offx_ = 0, offy_ = 0;
    float winT_ = 0, celebT_ = -1, hintT_ = 0;
    int camMode_ = 0;
    Board B_;
    TraceResult R_;
    // القائمة
    float scroll_ = 0, scrollVel_ = 0, scrollMax_ = 0;
    // اللمس
    bool down_ = false, moved_ = false;
    float downX_ = 0, downY_ = 0, lastY_ = 0;
    int pressBtn_ = -1;
    std::vector<Btn> btns_;

    void loadSave();
    int levelCount() const;
    bool unlockedIn(int mode, int i) const;
    int& starsOf(int mode, int i);
    void startLevel(int i, int mode);
    void playTap(float x, float y);
    void showToast(const char* s) { toast_ = s; toastT_ = 2.2f; }
    static const char* tierName(int L);
    void showMenu();
    void tone(float hz, int ms, float vol = 0.05f, int delay = 0);
    void doWin();
    void drawMenu(float dt);
    void drawPlay(float dt);
    void addBtn(int id, float x, float y, float w, float h) { btns_.push_back({id, x, y, w, h}); }
    int hitBtn(float x, float y) const;
    void onButton(int id);
    void playDown(float x, float y);
    void playMove(float x, float y);
    void playUp();
    bool toPlay(float sx, float sy, double& px, double& py);
    const char* qualityName() const;
};
