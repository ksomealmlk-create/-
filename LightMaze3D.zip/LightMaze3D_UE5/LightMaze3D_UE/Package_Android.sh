#!/usr/bin/env bash
# Local APK build on Linux/macOS. Set UE_ROOT to your Unreal Engine 5.4 folder.
UE_ROOT="${UE_ROOT:-/opt/UE_5.4}"
DIR="$(cd "$(dirname "$0")" && pwd)"
"$UE_ROOT/Engine/Build/BatchFiles/RunUAT.sh" BuildCookRun -project="$DIR/LightMaze3D.uproject" -noP4 -utf8output \
  -platform=Android -targetplatform=Android -cookflavor=ASTC -clientconfig=Development \
  -build -cook -map=/Engine/Maps/Entry -stage -pak -package -archive -archivedirectory="$DIR/Build"
echo "APK is in: $DIR/Build/Android_ASTC"
