#pragma once
#include "CoreMinimal.h"
#include "ProceduralMeshComponent.h"

// Small helper that builds colored geometry for a UProceduralMeshComponent.
// Everything is drawn with an unlit vertex-color material, so the look does not
// depend on scene lights or mobile lighting limits (shading is baked per face).
struct FLMMesh
{
	TArray<FVector> V;
	TArray<int32> I;
	TArray<FVector> N;
	TArray<FVector2D> UV;
	TArray<FLinearColor> C;
	TArray<FProcMeshTangent> T;

	void Reset();
	static FLinearColor Shaded(const FLinearColor& Col, const FVector& Normal);

	void Quad(const FVector& A, const FVector& B, const FVector& Cc, const FVector& D, const FLinearColor& Col);
	void Tri(const FVector& A, const FVector& B, const FVector& Cc, const FLinearColor& Col);
	// Box with local X along YawDeg. Center = center of the box.
	void Box(const FVector& Center, float Hx, float Hy, float Hz, float YawDeg, const FLinearColor& Col);
	// Cylinder standing on Base (z = base height), radius R, height H.
	void Cyl(const FVector& Base, float R, float H, int32 Seg, const FLinearColor& Col);
	void Dome(const FVector& Base, float R, const FLinearColor& Col);
	void Disc(const FVector& Center, float R, int32 Seg, const FLinearColor& Col);
	void Ring(const FVector& Center, float R, float Width, int32 Seg, const FLinearColor& Col);
	// Flat ribbon (unshaded) between two world points at height Z.
	void Ribbon(const FVector& A, const FVector& B, float Width, float Z, const FLinearColor& Col);

	void Upload(UProceduralMeshComponent* P, int32 Section);
};
