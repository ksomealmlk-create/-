#include "LMGameMode.h"
#include "LMGameActor.h"
#include "LMPlayerController.h"
#include "LMHUD.h"
#include "Engine/World.h"

ALMGameMode::ALMGameMode()
{
	PlayerControllerClass = ALMPlayerController::StaticClass();
	HUDClass = ALMHUD::StaticClass();
	DefaultPawnClass = nullptr;
}

void ALMGameMode::BeginPlay()
{
	Super::BeginPlay();
	FActorSpawnParameters Sp;
	Game = GetWorld()->SpawnActor<ALMGameActor>(FVector::ZeroVector, FRotator::ZeroRotator, Sp);
}
