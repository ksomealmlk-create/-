#include "LMMesh.h"

void FLMMesh::Reset()
{
	V.Reset(); I.Reset(); N.Reset(); UV.Reset(); C.Reset(); T.Reset();
}

FLinearColor FLMMesh::Shaded(const FLinearColor& Col, const FVector& Normal)
{
	static const FVector LightDir = FVector(-0.30, 0.35, 0.89).GetSafeNormal();
	const float D = static_cast<float>(FVector::DotProduct(Normal.GetSafeNormal(), LightDir));
	const float S = 0.38f + 0.62f * FMath::Max(0.f, D);
	return FLinearColor(Col.R * S, Col.G * S, Col.B * S, 1.f);
}

void FLMMesh::Quad(const FVector& A, const FVector& B, const FVector& Cc, const FVector& D, const FLinearColor& Col)
{
	const int32 Base = V.Num();
	V.Add(A); V.Add(B); V.Add(Cc); V.Add(D);
	for (int32 k = 0; k < 4; k++)
	{
		N.Add(FVector::UpVector);
		UV.Add(FVector2D::ZeroVector);
		C.Add(Col);
	}
	// both windings => visible from either side (material may be one-sided)
	const int32 Idx[12] = { 0, 1, 2, 0, 2, 3, 0, 2, 1, 0, 3, 2 };
	for (int32 k = 0; k < 12; k++) I.Add(Base + Idx[k]);
}

void FLMMesh::Tri(const FVector& A, const FVector& B, const FVector& Cc, const FLinearColor& Col)
{
	const int32 Base = V.Num();
	V.Add(A); V.Add(B); V.Add(Cc);
	for (int32 k = 0; k < 3; k++)
	{
		N.Add(FVector::UpVector);
		UV.Add(FVector2D::ZeroVector);
		C.Add(Col);
	}
	const int32 Idx[6] = { 0, 1, 2, 0, 2, 1 };
	for (int32 k = 0; k < 6; k++) I.Add(Base + Idx[k]);
}

void FLMMesh::Box(const FVector& Center, float Hx, float Hy, float Hz, float YawDeg, const FLinearColor& Col)
{
	const float Yaw = FMath::DegreesToRadians(YawDeg);
	const FVector X(FMath::Cos(Yaw), FMath::Sin(Yaw), 0.f);
	const FVector Y(-FMath::Sin(Yaw), FMath::Cos(Yaw), 0.f);
	const FVector Z(0.f, 0.f, 1.f);
	auto P = [&](float sx, float sy, float sz) -> FVector
	{
		return Center + X * (sx * Hx) + Y * (sy * Hy) + Z * (sz * Hz);
	};
	Quad(P(-1, -1, 1), P(1, -1, 1), P(1, 1, 1), P(-1, 1, 1), Shaded(Col, Z));
	Quad(P(1, -1, -1), P(1, 1, -1), P(1, 1, 1), P(1, -1, 1), Shaded(Col, X));
	Quad(P(-1, 1, -1), P(-1, -1, -1), P(-1, -1, 1), P(-1, 1, 1), Shaded(Col, -X));
	Quad(P(1, 1, -1), P(-1, 1, -1), P(-1, 1, 1), P(1, 1, 1), Shaded(Col, Y));
	Quad(P(-1, -1, -1), P(1, -1, -1), P(1, -1, 1), P(-1, -1, 1), Shaded(Col, -Y));
}

void FLMMesh::Cyl(const FVector& Base, float R, float H, int32 Seg, const FLinearColor& Col)
{
	for (int32 i = 0; i < Seg; i++)
	{
		const float A0 = 2.f * PI * i / Seg;
		const float A1 = 2.f * PI * (i + 1) / Seg;
		const FVector D0(FMath::Cos(A0), FMath::Sin(A0), 0.f);
		const FVector D1(FMath::Cos(A1), FMath::Sin(A1), 0.f);
		const FVector Mid = (D0 + D1).GetSafeNormal();
		Quad(Base + D0 * R, Base + D1 * R, Base + D1 * R + FVector(0, 0, H), Base + D0 * R + FVector(0, 0, H), Shaded(Col, Mid));
		Tri(Base + FVector(0, 0, H), Base + D0 * R + FVector(0, 0, H), Base + D1 * R + FVector(0, 0, H), Shaded(Col, FVector::UpVector));
	}
}

void FLMMesh::Dome(const FVector& Base, float R, const FLinearColor& Col)
{
	const int32 Rings = 4, Seg = 14;
	for (int32 r = 0; r < Rings; r++)
	{
		const float L0 = 0.5f * PI * r / Rings;
		const float L1 = 0.5f * PI * (r + 1) / Rings;
		const float Lm = 0.5f * (L0 + L1);
		for (int32 i = 0; i < Seg; i++)
		{
			const float A0 = 2.f * PI * i / Seg;
			const float A1 = 2.f * PI * (i + 1) / Seg;
			const float Am = 0.5f * (A0 + A1);
			auto P = [&](float Lat, float Az) -> FVector
			{
				return Base + FVector(FMath::Cos(Lat) * FMath::Cos(Az) * R, FMath::Cos(Lat) * FMath::Sin(Az) * R, FMath::Sin(Lat) * R);
			};
			const FVector Nm(FMath::Cos(Lm) * FMath::Cos(Am), FMath::Cos(Lm) * FMath::Sin(Am), FMath::Sin(Lm));
			Quad(P(L0, A0), P(L0, A1), P(L1, A1), P(L1, A0), Shaded(Col, Nm));
		}
	}
}

void FLMMesh::Disc(const FVector& Center, float R, int32 Seg, const FLinearColor& Col)
{
	for (int32 i = 0; i < Seg; i++)
	{
		const float A0 = 2.f * PI * i / Seg;
		const float A1 = 2.f * PI * (i + 1) / Seg;
		Tri(Center, Center + FVector(FMath::Cos(A0), FMath::Sin(A0), 0.f) * R, Center + FVector(FMath::Cos(A1), FMath::Sin(A1), 0.f) * R, Col);
	}
}

void FLMMesh::Ring(const FVector& Center, float R, float Width, int32 Seg, const FLinearColor& Col)
{
	const float R0 = FMath::Max(0.f, R - Width * 0.5f), R1 = R + Width * 0.5f;
	for (int32 i = 0; i < Seg; i++)
	{
		const float A0 = 2.f * PI * i / Seg;
		const float A1 = 2.f * PI * (i + 1) / Seg;
		const FVector D0(FMath::Cos(A0), FMath::Sin(A0), 0.f);
		const FVector D1(FMath::Cos(A1), FMath::Sin(A1), 0.f);
		Quad(Center + D0 * R0, Center + D1 * R0, Center + D1 * R1, Center + D0 * R1, Col);
	}
}

void FLMMesh::Ribbon(const FVector& A, const FVector& B, float Width, float Z, const FLinearColor& Col)
{
	FVector D = B - A;
	D.Z = 0.f;
	const float Len = static_cast<float>(D.Size());
	if (Len < 0.01f) return;
	const FVector Side = FVector(-D.Y, D.X, 0.f) / Len * (Width * 0.5f);
	const FVector Za(0, 0, Z);
	const FVector A2(A.X, A.Y, 0.f), B2(B.X, B.Y, 0.f);
	Quad(A2 + Side + Za, B2 + Side + Za, B2 - Side + Za, A2 - Side + Za, Col);
}

void FLMMesh::Upload(UProceduralMeshComponent* P, int32 Section)
{
	if (!P) return;
	if (V.Num() == 0)
	{
		P->ClearMeshSection(Section);
		return;
	}
	T.Reset();
	P->CreateMeshSection_LinearColor(Section, V, I, N, UV, C, T, false);
}
