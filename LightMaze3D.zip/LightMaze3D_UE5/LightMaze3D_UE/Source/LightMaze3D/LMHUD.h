#pragma once
#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "LMHUD.generated.h"

class ALMGameActor;
class UFont;

// Canvas based UI (no UMG assets needed): menu, in-game bar, win/lose panels.
UCLASS()
class ALMHUD : public AHUD
{
	GENERATED_BODY()
public:
	ALMHUD();
	virtual void DrawHUD() override;

	// action: 0 = down, 1 = move, 2 = up. Returns true if the HUD consumed the touch.
	bool OnTouch(int32 Action, const FVector2D& P);

private:
	struct FBtn { int32 Id; float X, Y, W, H; };
	TArray<FBtn> Btns;
	UPROPERTY() UFont* Font = nullptr;
	float Dp = 2.f;
	float Scroll = 0.f, ScrollMax = 0.f;
	int32 LastSerial = -1;
	bool bUITouch = false, bUIMoved = false;
	int32 PressBtn = -1;
	FVector2D DownPos = FVector2D::ZeroVector, LastPos = FVector2D::ZeroVector;

	ALMGameActor* GetGame() const;
	int32 HitBtn(const FVector2D& P) const;
	void OnButton(int32 Id);
	void AddBtn(int32 Id, float X, float Y, float W, float H) { Btns.Add({ Id, X, Y, W, H }); }

	void DrawMenu(ALMGameActor* G);
	void DrawPlay(ALMGameActor* G);
	void DrawPanelButton(int32 Id, const FString& Label, float X, float Y, float W, float H, const FLinearColor& Col);
	void DrawTxt(const FString& S, float X, float Y, float SizePx, const FLinearColor& C, int32 Align = 1);
	void DrawStar(float Cx, float Cy, float R, const FLinearColor& C);
	void DrawStars(int32 N, float Cx, float Cy, float R, float Gap);
};
