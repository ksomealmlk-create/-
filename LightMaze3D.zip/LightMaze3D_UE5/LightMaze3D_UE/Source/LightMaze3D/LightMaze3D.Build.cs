using UnrealBuildTool;

public class LightMaze3D : ModuleRules
{
	public LightMaze3D(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		bEnableExceptions = true; // the ported game logic is plain std C++ (std::vector etc.)
		PublicDependencyModuleNames.AddRange(new string[] {
			"Core", "CoreUObject", "Engine", "InputCore", "RenderCore", "RHI", "ProceduralMeshComponent"
		});
	}
}
