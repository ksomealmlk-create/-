#include "LMPlayerController.h"
#include "LMGameMode.h"
#include "LMGameActor.h"
#include "LMHUD.h"
#include "Components/InputComponent.h"
#include "Engine/World.h"

ALMPlayerController::ALMPlayerController()
{
	bShowMouseCursor = false;
	bEnableTouchEvents = true;
	bEnableClickEvents = false;
}

ALMGameActor* ALMPlayerController::GetGame() const
{
	if (const ALMGameMode* GM = GetWorld() ? GetWorld()->GetAuthGameMode<ALMGameMode>() : nullptr) return GM->Game;
	return nullptr;
}

ALMHUD* ALMPlayerController::GetLMHUD() const
{
	return Cast<ALMHUD>(GetHUD());
}

void ALMPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	if (!InputComponent) return;
	InputComponent->BindTouch(IE_Pressed, this, &ALMPlayerController::TouchPressed);
	InputComponent->BindTouch(IE_Repeat, this, &ALMPlayerController::TouchMoved);
	InputComponent->BindTouch(IE_Released, this, &ALMPlayerController::TouchReleased);
}

void ALMPlayerController::TouchPressed(ETouchIndex::Type Finger, FVector Loc)
{
	if (Finger != ETouchIndex::Touch1) return;
	const FVector2D P(Loc.X, Loc.Y);
	DownPos = P;
	bMovedFar = false;
	bGameTouch = false;
	ALMHUD* H = GetLMHUD();
	if (H && H->OnTouch(0, P)) return;
	if (ALMGameActor* G = GetGame()) { G->PlayDown(P); bGameTouch = true; }
}

void ALMPlayerController::TouchMoved(ETouchIndex::Type Finger, FVector Loc)
{
	if (Finger != ETouchIndex::Touch1) return;
	const FVector2D P(Loc.X, Loc.Y);
	if (FVector2D::Distance(P, DownPos) > 24.0) bMovedFar = true;
	if (bGameTouch)
	{
		if (ALMGameActor* G = GetGame()) G->PlayMove(P);
		return;
	}
	if (ALMHUD* H = GetLMHUD()) H->OnTouch(1, P);
}

void ALMPlayerController::TouchReleased(ETouchIndex::Type Finger, FVector Loc)
{
	if (Finger != ETouchIndex::Touch1) return;
	const FVector2D P(Loc.X, Loc.Y);
	if (bGameTouch)
	{
		if (ALMGameActor* G = GetGame()) G->PlayUp(P, !bMovedFar);
		bGameTouch = false;
		return;
	}
	if (ALMHUD* H = GetLMHUD()) H->OnTouch(2, P);
}
