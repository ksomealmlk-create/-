#pragma once
#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "LMPlayerController.generated.h"

class ALMGameActor;
class ALMHUD;

UCLASS()
class ALMPlayerController : public APlayerController
{
	GENERATED_BODY()
public:
	ALMPlayerController();
	virtual void SetupInputComponent() override;

private:
	void TouchPressed(ETouchIndex::Type Finger, FVector Loc);
	void TouchMoved(ETouchIndex::Type Finger, FVector Loc);
	void TouchReleased(ETouchIndex::Type Finger, FVector Loc);

	ALMGameActor* GetGame() const;
	ALMHUD* GetLMHUD() const;

	bool bGameTouch = false;
	FVector2D DownPos = FVector2D::ZeroVector;
	bool bMovedFar = false;
};
