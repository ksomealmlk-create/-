#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "LMGameMode.generated.h"

class ALMGameActor;

UCLASS()
class ALMGameMode : public AGameModeBase
{
	GENERATED_BODY()
public:
	ALMGameMode();
	virtual void BeginPlay() override;

	UPROPERTY() ALMGameActor* Game = nullptr;
};
