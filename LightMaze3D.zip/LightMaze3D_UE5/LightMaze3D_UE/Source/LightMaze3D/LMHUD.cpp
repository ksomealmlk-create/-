#include "LMHUD.h"
#include "LMGameActor.h"
#include "LMGameMode.h"
#include "Engine/Canvas.h"
#include "Engine/Font.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "CanvasItem.h"
#include "RenderResource.h"
#include "UObject/ConstructorHelpers.h"

namespace
{
	enum EBtn : int32 { B_MENU = 1, B_HINT, B_RESET, B_CAM, B_NEXT, B_AGAIN, B_LIST, B_TAB0, B_TAB1, B_TITLE, B_LANG, B_LEVEL0 = 100 };
	const FLinearColor Gold(1.f, 0.82f, 0.25f), Soft(0.55f, 0.6f, 0.7f), White(1, 1, 1), Panel(0.07f, 0.09f, 0.14f, 0.96f);
}

ALMHUD::ALMHUD()
{
	static ConstructorHelpers::FObjectFinder<UFont> FontFinder(TEXT("/Engine/EngineFonts/Roboto"));
	if (FontFinder.Succeeded()) Font = FontFinder.Object;
}

ALMGameActor* ALMHUD::GetGame() const
{
	if (const ALMGameMode* GM = GetWorld() ? GetWorld()->GetAuthGameMode<ALMGameMode>() : nullptr) return GM->Game;
	return nullptr;
}

void ALMHUD::DrawTxt(const FString& S, float X, float Y, float SizePx, const FLinearColor& C, int32 Align)
{
	UFont* F = Font ? Font : GEngine->GetLargeFont();
	const float Base = (F && F->LegacyFontSize > 0) ? static_cast<float>(F->LegacyFontSize) : 16.f;
	const float Sc = SizePx / Base;
	float W = 0, H = 0;
	GetTextSize(S, W, H, F, Sc);
	const float Px = Align == 1 ? X - W * 0.5f : (Align == 2 ? X - W : X);
	DrawText(S, C, Px, Y - H * 0.5f, F, Sc, false);
}

void ALMHUD::DrawStar(float Cx, float Cy, float R, const FLinearColor& C)
{
	if (!Canvas) return;
	FVector2D Outer[5], Inner[5];
	for (int32 i = 0; i < 5; i++)
	{
		const float A = -PI / 2 + i * 2.f * PI / 5.f;
		const float B = A + PI / 5.f;
		Outer[i] = FVector2D(Cx + FMath::Cos(A) * R, Cy + FMath::Sin(A) * R);
		Inner[i] = FVector2D(Cx + FMath::Cos(B) * R * 0.45f, Cy + FMath::Sin(B) * R * 0.45f);
	}
	const FVector2D Ctr(Cx, Cy);
	for (int32 i = 0; i < 5; i++)
	{
		const int32 Nx = (i + 1) % 5;
		FCanvasTriangleItem T1(Ctr, Outer[i], Inner[i], GWhiteTexture);
		T1.SetColor(C);
		Canvas->DrawItem(T1);
		FCanvasTriangleItem T2(Ctr, Inner[i], Outer[Nx], GWhiteTexture);
		T2.SetColor(C);
		Canvas->DrawItem(T2);
	}
}

void ALMHUD::DrawStars(int32 N, float Cx, float Cy, float R, float Gap)
{
	for (int32 k = 0; k < 3; k++)
		DrawStar(Cx + (k - 1) * Gap, Cy, R, k < N ? Gold : FLinearColor(0.3f, 0.33f, 0.4f, 0.8f));
}

void ALMHUD::DrawPanelButton(int32 Id, const FString& Label, float X, float Y, float W, float H, const FLinearColor& Col)
{
	DrawRect(Col * 0.35f, X - 2, Y - 2, W + 4, H + 4);
	DrawRect(Col, X, Y, W, H);
	DrawTxt(Label, X + W * 0.5f, Y + H * 0.5f, 15.f * Dp, FLinearColor(0.05f, 0.06f, 0.1f), 1);
	AddBtn(Id, X, Y, W, H);
}

void ALMHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas) return;
	ALMGameActor* G = GetGame();
	if (!G) return;
	Btns.Reset();
	Dp = FMath::Max(1.f, FMath::Min(Canvas->SizeX, Canvas->SizeY) / 360.f);
	if (G->Screen == ELMScreen::Menu) DrawMenu(G); else DrawPlay(G);
}

// ---------------------------------------------------------------- menu
void ALMHUD::DrawMenu(ALMGameActor* G)
{
	const float W = Canvas->SizeX, H = Canvas->SizeY;
	DrawRect(FLinearColor(0.02f, 0.03f, 0.06f, 0.78f), 0, 0, W, H);

	const int32 N = G->LevelCount(G->MenuTab);
	const int32 Cols = 5;
	const float Pad = 14 * Dp;
	const float Gap = 8 * Dp;
	const float CellW = (W - Pad * 2 - Gap * (Cols - 1)) / Cols;
	const float CellH = CellW * 1.2f;
	const float GridTop = 150 * Dp;
	const int32 Rows = (N + Cols - 1) / Cols;
	const float Content = Rows * (CellH + Gap);
	ScrollMax = FMath::Max(0.f, Content - (H - GridTop - 10 * Dp));

	if (LastSerial != G->MenuSerial)
	{
		LastSerial = G->MenuSerial;
		int32 First = 0;
		while (First < N - 1 && G->StarsOf(G->MenuTab, First) > 0) First++;
		Scroll = FMath::Clamp((First / Cols) * (CellH + Gap) - CellH, 0.f, ScrollMax);
	}
	Scroll = FMath::Clamp(Scroll, 0.f, ScrollMax);

	for (int32 i = 0; i < N; i++)
	{
		const int32 Cx = i % Cols, Ry = i / Cols;
		const float X = Pad + Cx * (CellW + Gap);
		const float Y = GridTop + Ry * (CellH + Gap) - Scroll;
		if (Y + CellH < GridTop || Y > H) continue;
		const bool bOpen = G->Unlocked(G->MenuTab, i);
		const int32 St = G->StarsOf(G->MenuTab, i);
		const FLinearColor Bg = !bOpen ? FLinearColor(0.10f, 0.11f, 0.15f, 0.95f) : (St > 0 ? FLinearColor(0.14f, 0.24f, 0.34f, 0.95f) : FLinearColor(0.16f, 0.18f, 0.28f, 0.95f));
		DrawRect(Bg, X, Y, CellW, CellH);
		DrawTxt(FString::FromInt(i + 1), X + CellW * 0.5f, Y + CellH * 0.30f, 20 * Dp, bOpen ? White : Soft * 0.6f, 1);
		if (bOpen)
		{
			DrawTxt(G->LevelLabel(G->MenuTab, i), X + CellW * 0.5f, Y + CellH * 0.58f, 9 * Dp, Soft, 1);
			DrawStars(St, X + CellW * 0.5f, Y + CellH * 0.82f, 6 * Dp, 13 * Dp);
			AddBtn(B_LEVEL0 + i, X, Y, CellW, CellH);
		}
	}

	// header (drawn after the grid so it covers scrolled cells)
	DrawRect(FLinearColor(0.02f, 0.03f, 0.06f, 0.98f), 0, 0, W, GridTop - 4 * Dp);
	DrawTxt(G->Tr(TEXT("مرايا الضوء 3D"), TEXT("Light Mirrors 3D")), W * 0.5f, 42 * Dp, 30 * Dp, FLinearColor(1.f, 0.9f, 0.6f), 1);
	AddBtn(B_TITLE, W * 0.5f - 130 * Dp, 20 * Dp, 260 * Dp, 44 * Dp);

	int32 Total = 0;
	for (int32 v : G->StarsChal) Total += v;
	int32 TotalFree = 0;
	for (int32 v : G->StarsFree) TotalFree += v;
	DrawTxt(FString::Printf(TEXT("%s %d / %d   |   %s %d / %d"),
		*G->Tr(TEXT("نجوم التحدي"), TEXT("Challenge stars")), Total, G->StarsChal.Num() * 3,
		*G->Tr(TEXT("الحر"), TEXT("Free")), TotalFree, G->StarsFree.Num() * 3),
		W * 0.5f, 78 * Dp, 11 * Dp, Soft, 1);

	const float Bw = (W - Pad * 2 - Gap) / 2.f, By = 98 * Dp, Bh = 38 * Dp;
	DrawPanelButton(B_TAB0, G->Tr(TEXT("التحدي (200)"), TEXT("Challenge (200)")), Pad, By, Bw, Bh, G->MenuTab == 0 ? Gold : FLinearColor(0.35f, 0.4f, 0.5f));
	DrawPanelButton(B_TAB1, G->Tr(TEXT("الوضع الحر (36)"), TEXT("Free mode (36)")), Pad + Bw + Gap, By, Bw, Bh, G->MenuTab == 1 ? Gold : FLinearColor(0.35f, 0.4f, 0.5f));

	// language toggle
	const float Lw = 46 * Dp, Lh = 26 * Dp;
	DrawPanelButton(B_LANG, G->bArabic ? TEXT("EN") : TEXT("AR"), W - Pad - Lw, 8 * Dp, Lw, Lh, FLinearColor(0.45f, 0.5f, 0.6f));
}

// ---------------------------------------------------------------- play
void ALMHUD::DrawPlay(ALMGameActor* G)
{
	const float W = Canvas->SizeX, H = Canvas->SizeY;
	const bool bTap = G->PlayMode == 0;
	const float Inset = 22 * Dp;                   // room for status bar / camera notch
	const float Bs = 44 * Dp, Gp = 8 * Dp;
	float X = 12 * Dp;
	const float Y0 = Inset;

	auto IconBtn = [&](int32 Id, const FString& Lbl, const FLinearColor& Col)
	{
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.55f), X, Y0, Bs, Bs);
		DrawRect(Col * 0.4f, X + 2, Y0 + 2, Bs - 4, Bs - 4);
		DrawTxt(Lbl, X + Bs * 0.5f, Y0 + Bs * 0.5f, 13 * Dp, White, 1);
		AddBtn(Id, X, Y0, Bs, Bs);
		X += Bs + Gp;
	};
	IconBtn(B_MENU, G->Tr(TEXT("القائمة"), TEXT("Menu")), FLinearColor(0.5f, 0.55f, 0.7f));
	IconBtn(B_CAM, TEXT("3D"), FLinearColor(0.4f, 0.7f, 0.9f));
	IconBtn(B_HINT, G->Tr(TEXT("تلميح"), TEXT("Hint")), FLinearColor(1.f, 0.8f, 0.3f));
	IconBtn(B_RESET, G->Tr(TEXT("إعادة"), TEXT("Redo")), FLinearColor(0.9f, 0.45f, 0.4f));

	FString Title;
	if (bTap) Title = FString::Printf(TEXT("%s %d  -  %s"), *G->Tr(TEXT("المرحلة"), TEXT("Level")), G->LevelIndex + 1, *G->TierName(G->LevelIndex + 1));
	else Title = FString::Printf(TEXT("%d. %s"), G->LevelIndex + 1, *FString(UTF8_TO_TCHAR(G->B.name)));
	const bool bHot = bTap && G->LevelIndex + 1 >= 170;
	DrawTxt(Title, W * 0.5f, Y0 + Bs + 22 * Dp, 18 * Dp, bHot ? FLinearColor(1.f, 0.45f, 0.35f) : White, 1);

	// bottom info
	if (bTap)
	{
		const int32 Left = FMath::Max(0, G->Limit - G->Moves);
		const FLinearColor C = Left <= 2 ? FLinearColor(1.f, 0.4f, 0.35f) : (Left <= 5 ? FLinearColor(1.f, 0.8f, 0.35f) : White);
		DrawTxt(FString::Printf(TEXT("%s: %d"), *G->Tr(TEXT("الحركات المتبقية"), TEXT("Moves left")), Left), W * 0.5f, H - 56 * Dp, 20 * Dp, C, 1);
		DrawTxt(FString::Printf(TEXT("%s %d/%d"), *G->Tr(TEXT("الأهداف"), TEXT("Targets")), G->R.hitCount, static_cast<int32>(G->B.T.size())), W * 0.5f, H - 28 * Dp, 15 * Dp, Soft, 1);
		DrawTxt(G->Tr(TEXT("انقر على المرآة لتدويرها 45°"), TEXT("Tap a mirror to rotate it 45°")), W * 0.5f, H - 84 * Dp, 11 * Dp, Soft * 0.9f, 1);
	}
	else
	{
		DrawTxt(FString::Printf(TEXT("%s: %d"), *G->Tr(TEXT("الحركات"), TEXT("Moves")), G->Moves), W * 0.5f, H - 40 * Dp, 18 * Dp, White, 1);
		DrawTxt(G->Tr(TEXT("اسحب المرآة لتحريكها، واسحب النقطة البرتقالية لتدويرها"), TEXT("Drag a mirror to move it, drag the orange dot to rotate")), W * 0.5f, H - 16 * Dp, 10 * Dp, Soft * 0.9f, 1);
	}

	// toast
	if (G->ToastT > 0.f)
	{
		const float A = FMath::Clamp(G->ToastT, 0.f, 1.f);
		DrawRect(FLinearColor(0, 0, 0, 0.7f * A), 14 * Dp, Y0 + Bs + 44 * Dp, W - 28 * Dp, 30 * Dp);
		DrawTxt(G->ToastText, W * 0.5f, Y0 + Bs + 59 * Dp, 12 * Dp, FLinearColor(1, 1, 1, A), 1);
	}

	// win / lose panel
	if ((G->bWon || G->bLost) && G->CelebT > 0.25f)
	{
		const float A = FMath::Clamp((G->CelebT - 0.25f) * 3.f, 0.f, 1.f);
		DrawRect(FLinearColor(0, 0, 0, 0.55f * A), 0, 0, W, H);
		const float Pw = FMath::Min(W - 30 * Dp, 320 * Dp), Ph = 250 * Dp;
		const float Px = (W - Pw) * 0.5f, Py = (H - Ph) * 0.5f;
		DrawRect(Panel, Px, Py, Pw, Ph);
		if (G->bWon)
		{
			DrawTxt(G->Tr(TEXT("أحسنت!"), TEXT("Well done!")), W * 0.5f, Py + 36 * Dp, 28 * Dp, Gold, 1);
			DrawStars(G->StarsOf(G->PlayMode, G->LevelIndex), W * 0.5f, Py + 86 * Dp, 20 * Dp, 56 * Dp);
			if (bTap) DrawTxt(FString::Printf(TEXT("%s: %d / %d   (%s %d)"), *G->Tr(TEXT("الحركات"), TEXT("Moves")), G->Moves, G->Limit, *G->Tr(TEXT("الأفضل"), TEXT("best")), G->B.minMoves), W * 0.5f, Py + 128 * Dp, 12 * Dp, Soft, 1);
			else DrawTxt(FString::Printf(TEXT("%s: %d"), *G->Tr(TEXT("الحركات"), TEXT("Moves")), G->Moves), W * 0.5f, Py + 128 * Dp, 12 * Dp, Soft, 1);
			const float Bw = (Pw - 40 * Dp) / 3.f, By = Py + Ph - 66 * Dp, Bh = 44 * Dp;
			DrawPanelButton(B_LIST, G->Tr(TEXT("القائمة"), TEXT("Menu")), Px + 12 * Dp, By, Bw, Bh, FLinearColor(0.5f, 0.55f, 0.7f));
			DrawPanelButton(B_AGAIN, G->Tr(TEXT("إعادة"), TEXT("Again")), Px + 20 * Dp + Bw, By, Bw, Bh, FLinearColor(0.9f, 0.55f, 0.45f));
			if (G->LevelIndex + 1 < G->LevelCount(G->PlayMode))
				DrawPanelButton(B_NEXT, G->Tr(TEXT("التالي"), TEXT("Next")), Px + 28 * Dp + Bw * 2, By, Bw, Bh, Gold);
		}
		else
		{
			DrawTxt(G->Tr(TEXT("خلصت الحركات"), TEXT("Out of moves")), W * 0.5f, Py + 50 * Dp, 26 * Dp, FLinearColor(1.f, 0.45f, 0.4f), 1);
			DrawTxt(G->Tr(TEXT("جرّب مرة ثانية"), TEXT("Try again")), W * 0.5f, Py + 100 * Dp, 14 * Dp, Soft, 1);
			const float Bw = (Pw - 36 * Dp) / 2.f, By = Py + Ph - 66 * Dp, Bh = 44 * Dp;
			DrawPanelButton(B_LIST, G->Tr(TEXT("القائمة"), TEXT("Menu")), Px + 12 * Dp, By, Bw, Bh, FLinearColor(0.5f, 0.55f, 0.7f));
			DrawPanelButton(B_AGAIN, G->Tr(TEXT("إعادة"), TEXT("Again")), Px + 24 * Dp + Bw, By, Bw, Bh, Gold);
		}
	}
}

// ---------------------------------------------------------------- touch
int32 ALMHUD::HitBtn(const FVector2D& P) const
{
	for (int32 i = Btns.Num() - 1; i >= 0; i--)
	{
		const FBtn& B = Btns[i];
		if (P.X >= B.X && P.X <= B.X + B.W && P.Y >= B.Y && P.Y <= B.Y + B.H) return B.Id;
	}
	return -1;
}

bool ALMHUD::OnTouch(int32 Action, const FVector2D& P)
{
	ALMGameActor* G = GetGame();
	if (!G) return false;
	if (Action == 0)
	{
		PressBtn = HitBtn(P);
		const bool bOverlay = G->bWon || G->bLost;
		if (PressBtn >= 0 || G->Screen == ELMScreen::Menu || bOverlay)
		{
			bUITouch = true; bUIMoved = false; DownPos = LastPos = P;
			return true;
		}
		bUITouch = false;
		return false;
	}
	if (!bUITouch) return false;
	if (Action == 1)
	{
		if (FVector2D::Distance(P, DownPos) > 14.0 * Dp) bUIMoved = true;
		if (G->Screen == ELMScreen::Menu) Scroll = FMath::Clamp(Scroll - static_cast<float>(P.Y - LastPos.Y), 0.f, ScrollMax);
		LastPos = P;
		return true;
	}
	// release
	bUITouch = false;
	if (!bUIMoved && PressBtn >= 0 && HitBtn(P) == PressBtn) OnButton(PressBtn);
	PressBtn = -1;
	return true;
}

void ALMHUD::OnButton(int32 Id)
{
	ALMGameActor* G = GetGame();
	if (!G) return;
	if (Id >= B_LEVEL0)
	{
		const int32 I = Id - B_LEVEL0;
		if (I < G->LevelCount(G->MenuTab) && G->Unlocked(G->MenuTab, I)) G->StartLevel(I, G->MenuTab);
		return;
	}
	switch (Id)
	{
	case B_MENU: case B_LIST: G->ShowMenu(); break;
	case B_HINT: G->ActionHint(); break;
	case B_RESET: case B_AGAIN: G->ActionReset(); break;
	case B_NEXT: G->ActionNext(); break;
	case B_CAM: G->ActionCamera(); break;
	case B_TAB0: G->MenuTab = 0; Scroll = 0; G->MenuSerial++; break;
	case B_TAB1: G->MenuTab = 1; Scroll = 0; G->MenuSerial++; break;
	case B_TITLE: G->TitleTap(); break;
	case B_LANG: G->ToggleLanguage(); break;
	default: break;
	}
}
