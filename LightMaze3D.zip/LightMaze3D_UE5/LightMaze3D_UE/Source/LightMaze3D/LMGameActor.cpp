#include "LMGameActor.h"
#include "ProceduralMeshComponent.h"
#include "Components/PostProcessComponent.h"
#include "Components/SceneComponent.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInterface.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Engine/World.h"
#include "UObject/ConstructorHelpers.h"

namespace
{
	constexpr float BeamZ = 20.f;
	constexpr double Quarter = 3.14159265358979323846 / 4.0;
	const float PitchModes[3] = { 58.f, 72.f, 87.f };

	// Game plane (x right, y down, 576x560) -> Unreal world (X up-screen, Y right-screen, Z up)
	FORCEINLINE FVector Wp(double X, double Y, float Z = 0.f)
	{
		return FVector(-(Y - 280.0), (X - 288.0), Z);
	}
	FORCEINLINE float YawOf(double A) { return FMath::RadiansToDegrees(static_cast<float>(A)) + 90.f; }

	FLinearColor BeamColor(char C)
	{
		switch (C)
		{
		case 'r': return FLinearColor(1.f, 0.30f, 0.25f);
		case 'g': return FLinearColor(0.30f, 1.f, 0.50f);
		case 'b': return FLinearColor(0.30f, 0.55f, 1.f);
		default:  return FLinearColor(1.f, 0.96f, 0.80f);
		}
	}

	double DistSegP(double Px, double Py, const LM::Seg4& S)
	{
		const double Ex = S.x2 - S.x1, Ey = S.y2 - S.y1, L2 = Ex * Ex + Ey * Ey;
		const double U = L2 < 1e-9 ? 0.0 : FMath::Clamp(((Px - S.x1) * Ex + (Py - S.y1) * Ey) / L2, 0.0, 1.0);
		return FMath::Sqrt(FMath::Square(Px - S.x1 - U * Ex) + FMath::Square(Py - S.y1 - U * Ey));
	}

	int32 StateOf(double A)
	{
		return ((FMath::RoundToInt(static_cast<float>(A / Quarter)) % 4) + 4) % 4;
	}
}

ALMGameActor::ALMGameActor()
{
	PrimaryActorTick.bCanEverTick = true;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	StaticMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("StaticMesh"));
	StaticMesh->SetupAttachment(Root);
	StaticMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	StaticMesh->CastShadow = false;

	DynMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("DynMesh"));
	DynMesh->SetupAttachment(Root);
	DynMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	DynMesh->CastShadow = false;

	UPostProcessComponent* PP = CreateDefaultSubobject<UPostProcessComponent>(TEXT("PostProcess"));
	PP->SetupAttachment(Root);
	PP->bUnbound = true;
	PP->Settings.bOverride_BloomIntensity = true;
	PP->Settings.BloomIntensity = 1.6f;
	PP->Settings.bOverride_BloomThreshold = true;
	PP->Settings.BloomThreshold = -1.f;
	PP->Settings.bOverride_AutoExposureMinBrightness = true;
	PP->Settings.AutoExposureMinBrightness = 1.f;
	PP->Settings.bOverride_AutoExposureMaxBrightness = true;
	PP->Settings.AutoExposureMaxBrightness = 1.f;
	PP->Settings.bOverride_VignetteIntensity = true;
	PP->Settings.VignetteIntensity = 0.55f;

	static ConstructorHelpers::FObjectFinder<UMaterialInterface> MatFinder(TEXT("/Engine/EngineDebugMaterials/VertexColorMaterial"));
	if (MatFinder.Succeeded()) VertexMat = MatFinder.Object;
}

void ALMGameActor::BeginPlay()
{
	Super::BeginPlay();
	if (!VertexMat)
	{
		VertexMat = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/EngineDebugMaterials/VertexColorViewMode_ColorOnly.VertexColorViewMode_ColorOnly"));
	}
	if (VertexMat)
	{
		StaticMesh->SetMaterial(0, VertexMat);
		DynMesh->SetMaterial(0, VertexMat);
	}
	FActorSpawnParameters Sp;
	Cam = GetWorld()->SpawnActor<ACameraActor>(FVector(0, 0, 600), FRotator(-60, 0, 0), Sp);
	if (Cam)
	{
		UCameraComponent* CC = Cam->GetCameraComponent();
		CC->SetConstraintAspectRatio(false);
		CC->SetFieldOfView(60.f);
	}
	LoadSave();
	ShowMenu();
}

// ---------------------------------------------------------------- save / load
void ALMGameActor::LoadSave()
{
	StarsFree.Init(0, static_cast<int32>(LM::allLevels().size()));
	StarsChal.Init(0, static_cast<int32>(LM::allChallenge().size()));
	FString Txt;
	if (!FFileHelper::LoadFileToString(Txt, *(FPaths::ProjectSavedDir() / TEXT("LMSave.txt")))) return;
	TArray<FString> Lines;
	Txt.ParseIntoArrayLines(Lines);
	for (const FString& L : Lines)
	{
		TArray<FString> Parts;
		L.ParseIntoArray(Parts, TEXT(" "));
		if (Parts.Num() < 2) continue;
		if (Parts[0] == TEXT("lang")) bArabic = Parts[1] != TEXT("0");
		else if (Parts[0] == TEXT("free") || Parts[0] == TEXT("chal"))
		{
			TArray<int32>& Dst = Parts[0] == TEXT("free") ? StarsFree : StarsChal;
			for (int32 i = 1; i < Parts.Num() && i - 1 < Dst.Num(); i++) Dst[i - 1] = FMath::Clamp(FCString::Atoi(*Parts[i]), 0, 3);
		}
	}
}

void ALMGameActor::SaveGame() const
{
	FString Out = FString::Printf(TEXT("lang %d\n"), bArabic ? 1 : 0);
	Out += TEXT("free");
	for (int32 v : StarsFree) Out += FString::Printf(TEXT(" %d"), v);
	Out += TEXT("\nchal");
	for (int32 v : StarsChal) Out += FString::Printf(TEXT(" %d"), v);
	Out += TEXT("\n");
	FFileHelper::SaveStringToFile(Out, *(FPaths::ProjectSavedDir() / TEXT("LMSave.txt")));
}

// ---------------------------------------------------------------- queries
int32 ALMGameActor::LevelCount(int32 Mode) const
{
	return Mode == 0 ? static_cast<int32>(LM::allChallenge().size()) : static_cast<int32>(LM::allLevels().size());
}

int32 ALMGameActor::StarsOf(int32 Mode, int32 Index) const
{
	const TArray<int32>& A = Mode == 0 ? StarsChal : StarsFree;
	return A.IsValidIndex(Index) ? A[Index] : 0;
}

bool ALMGameActor::Unlocked(int32 Mode, int32 Index) const
{
	return Index == 0 || StarsOf(Mode, Index - 1) > 0;
}

int32& ALMGameActor::StarRef(int32 Mode, int32 Index)
{
	return Mode == 0 ? StarsChal[Index] : StarsFree[Index];
}

FString ALMGameActor::TierName(int32 L) const
{
	if (L < 30) return Tr(TEXT("سهل"), TEXT("Easy"));
	if (L < 70) return Tr(TEXT("متوسط"), TEXT("Medium"));
	if (L < 110) return Tr(TEXT("صعب"), TEXT("Hard"));
	if (L < 150) return Tr(TEXT("صعب جداً"), TEXT("Very hard"));
	if (L < 170) return Tr(TEXT("خبير"), TEXT("Expert"));
	return Tr(TEXT("فائق الصعوبة"), TEXT("Extreme"));
}

FString ALMGameActor::LevelLabel(int32 Mode, int32 Index) const
{
	if (Mode == 0) return TierName(Index + 1);
	return FString(UTF8_TO_TCHAR(LM::allLevels()[Index].name));
}

// ---------------------------------------------------------------- level flow
void ALMGameActor::StartLevel(int32 Index, int32 Mode)
{
	PlayMode = Mode;
	LevelIndex = Index;
	if (Mode == 0)
	{
		B = LM::buildBoardChal(LM::allChallenge()[Index]);
		Limit = B.limit;
	}
	else
	{
		B = LM::buildBoard(LM::allLevels()[Index]);
		Limit = 0;
	}
	LM::traceBoard(B, R);
	Sel = -1;
	if (Mode == 1)
	{
		for (size_t k = 0; k < B.els.size(); k++) if (!B.els[k].fixed) { Sel = static_cast<int32>(k); break; }
	}
	Moves = 0; bWon = false; bLost = false; LoseT = 0; WinT = 0; CelebT = -1.f; HintT = 0; HintEl = -1;
	Drag = 0; bChanged = false; ToastT = 0;
	Particles.Reset();
	Screen = ELMScreen::Play;
	BuildStatic();
}

void ALMGameActor::ShowMenu()
{
	MenuTab = PlayMode;
	Screen = ELMScreen::Menu;
	const auto& Lv = LM::allLevels();
	B = LM::buildBoard(Lv[25 % Lv.size()]);
	for (auto& e : B.els) if (!e.fixed) { e.x = e.sx; e.y = e.sy; e.a = e.sa; }
	LM::traceBoard(B, R);
	for (auto& t : B.T) t.v = 1.f;
	bWon = false; bLost = false; CelebT = -1.f; Sel = -1; Drag = 0;
	Particles.Reset();
	MenuSerial++;
	BuildStatic();
}

void ALMGameActor::DoWin()
{
	bWon = true;
	CelebT = 0.f;
	int32 St;
	if (PlayMode == 0)
	{
		const int32 Mn = B.minMoves, Lim = B.limit;
		St = Moves <= Mn ? 3 : (Moves <= Mn + (Lim - Mn + 1) / 2 ? 2 : 1);
	}
	else
	{
		const int32 Par = B.mv * 4;
		St = Moves <= Par ? 3 : (Moves <= Par * 2 ? 2 : 1);
	}
	int32& Ref = StarRef(PlayMode, LevelIndex);
	Ref = FMath::Max(Ref, St);
	SaveGame();
	for (const auto& t : B.T)
	{
		FLinearColor C(0.5f, 0.7f, 1.f);
		if (t.c == 'r') C = FLinearColor(1.f, 0.35f, 0.15f);
		if (t.c == 'g') C = FLinearColor(0.3f, 1.f, 0.55f);
		if (t.c == 'b') C = FLinearColor(0.3f, 0.6f, 1.f);
		Burst(Wp(t.x, t.y, 24.f), C, 70, 260.f);
		Burst(Wp(t.x, t.y, 24.f), FLinearColor(1.f, 0.95f, 0.8f), 30, 160.f);
	}
}

void ALMGameActor::Burst(const FVector& P, const FLinearColor& Col, int32 N, float Speed)
{
	for (int32 i = 0; i < N; i++)
	{
		const float A = FMath::FRand() * 2.f * PI;
		const float S = Speed * (0.3f + 0.7f * FMath::FRand());
		FLMParticle Pt;
		Pt.Pos = P;
		Pt.Vel = FVector(FMath::Cos(A) * S, FMath::Sin(A) * S, 60.f + FMath::FRand() * 160.f);
		Pt.Col = Col;
		Pt.MaxLife = Pt.Life = 0.8f + FMath::FRand() * 0.8f;
		Pt.Size = 2.f + FMath::FRand() * 3.f;
		Particles.Add(Pt);
	}
}

// ---------------------------------------------------------------- actions
void ALMGameActor::ActionHint()
{
	if (Screen != ELMScreen::Play) return;
	if (PlayMode == 1) { HintT = 4.f; return; }
	if (bWon || bLost) return;
	if (Limit - Moves < 3)
	{
		ShowToast(Tr(TEXT("الحركات لا تكفي للتلميح (يكلّف حركتين)"), TEXT("Not enough moves for a hint (costs 2)")));
		return;
	}
	int32 Found = -1;
	for (size_t k = 0; k < B.els.size(); k++)
	{
		const LM::Element& e = B.els[k];
		if (e.fixed) continue;
		if (StateOf(e.ta) != StateOf(e.sa)) { Found = static_cast<int32>(k); break; }
	}
	if (Found < 0)
	{
		ShowToast(Tr(TEXT("كل المرايا بالوضع الصحيح"), TEXT("All mirrors are already correct")));
		return;
	}
	HintEl = Found; HintT = 4.f; Moves += 2;
	ShowToast(Tr(TEXT("تلميح: يظهر اتجاه مرآة واحدة (كلّف حركتين)"), TEXT("Hint: one mirror's direction is shown (cost 2 moves)")));
}

void ALMGameActor::ActionReset() { if (Screen == ELMScreen::Play) StartLevel(LevelIndex, PlayMode); }
void ALMGameActor::ActionNext() { if (Screen == ELMScreen::Play && LevelIndex + 1 < LevelCount(PlayMode)) StartLevel(LevelIndex + 1, PlayMode); }
void ALMGameActor::ActionCamera() { CamMode = (CamMode + 1) % 3; }
void ALMGameActor::ToggleLanguage() { bArabic = !bArabic; SaveGame(); }

void ALMGameActor::TitleTap()
{
	if (TitleTapT <= 0) TitleTaps = 0;
	TitleTaps++; TitleTapT = 3.f;
	if (TitleTaps >= 7)
	{
		for (int32& v : StarsChal) if (v == 0) v = 1;
		for (int32& v : StarsFree) if (v == 0) v = 1;
		TitleTaps = 0;
		SaveGame();
	}
}

// ---------------------------------------------------------------- input
bool ALMGameActor::ScreenToPlay(const FVector2D& S, double& Px, double& Py) const
{
	APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0);
	if (!PC) return false;
	FVector Org, Dir;
	if (!PC->DeprojectScreenPositionToWorld(static_cast<float>(S.X), static_cast<float>(S.Y), Org, Dir)) return false;
	if (FMath::Abs(Dir.Z) < 1e-4) return false;
	const double T = (BeamZ - Org.Z) / Dir.Z;
	if (T < 0) return false;
	const FVector Hit = Org + Dir * T;
	Px = Hit.Y + 288.0;
	Py = 280.0 - Hit.X;
	return true;
}

void ALMGameActor::PlayDown(const FVector2D& P)
{
	if (Screen != ELMScreen::Play || bWon || bLost) return;
	if (PlayMode == 0) return;          // challenge mode reacts on release (tap)
	double Px, Py;
	if (!ScreenToPlay(P, Px, Py)) return;
	if (Sel >= 0)
	{
		const LM::Element& e = B.els[Sel];
		const double Hx = e.x + std::cos(e.a - PI / 2) * 52, Hy = e.y + std::sin(e.a - PI / 2) * 52;
		if (std::hypot(Px - Hx, Py - Hy) < 38) { Drag = 2; bChanged = false; return; }
	}
	int32 Best = -1;
	double Bd = 1e9;
	for (size_t i = 0; i < B.els.size(); i++)
	{
		const LM::Element& e = B.els[i];
		if (e.fixed) continue;
		const double D = FMath::Min(std::hypot(Px - e.x, Py - e.y) * 0.6, DistSegP(Px, Py, LM::elemSeg(e)));
		if (D < Bd && D < 30) { Bd = D; Best = static_cast<int32>(i); }
	}
	if (Best >= 0)
	{
		Sel = Best; Drag = 1; bChanged = false;
		OffX = B.els[Best].x - Px; OffY = B.els[Best].y - Py;
	}
}

void ALMGameActor::PlayMove(const FVector2D& P)
{
	if (Screen != ELMScreen::Play || !Drag || Sel < 0) return;
	double Px, Py;
	if (!ScreenToPlay(P, Px, Py)) return;
	LM::Element& e = B.els[Sel];
	bChanged = true;
	if (Drag == 1)
	{
		e.x = FMath::Clamp(Px + OffX, 60.0, 515.0);
		e.y = FMath::Clamp(Py + OffY, 48.0, 512.0);
	}
	else
	{
		e.a = std::atan2(Py - e.y, Px - e.x) + PI / 2;
	}
}

void ALMGameActor::PlayUp(const FVector2D& P, bool bWasTap)
{
	if (Screen != ELMScreen::Play) return;
	if (PlayMode == 1)
	{
		if (Drag && bChanged) Moves++;
		Drag = 0; bChanged = false;
		return;
	}
	// challenge mode: tap on a mirror rotates it by 45 degrees
	if (!bWasTap || bWon || bLost || Moves >= Limit) return;
	double Px, Py;
	if (!ScreenToPlay(P, Px, Py)) return;
	int32 Best = -1;
	double Bd = 1e9;
	for (size_t i = 0; i < B.els.size(); i++)
	{
		const LM::Element& e = B.els[i];
		if (e.fixed) continue;
		const double D = std::hypot(Px - e.x, Py - e.y);
		if (D < Bd && D < 38) { Bd = D; Best = static_cast<int32>(i); }
	}
	if (Best < 0) return;
	Sel = Best;
	B.els[Best].ta += Quarter;
	Moves++;
}

// ---------------------------------------------------------------- scene
void ALMGameActor::BuildStatic()
{
	StaticB.Reset();
	// outer ground
	StaticB.Quad(FVector(-1500, -1500, -2), FVector(1500, -1500, -2), FVector(1500, 1500, -2), FVector(-1500, 1500, -2), FLinearColor(0.012f, 0.014f, 0.022f));
	// stone floor tiles (x 40..536, y 30..530)
	const int32 NX = 8, NY = 8;
	const double Tw = 496.0 / NX, Th = 500.0 / NY;
	for (int32 j = 0; j < NY; j++)
		for (int32 i = 0; i < NX; i++)
		{
			const double X0 = 40 + i * Tw, X1 = X0 + Tw - 1.5, Y0 = 30 + j * Th, Y1 = Y0 + Th - 1.5;
			const bool Alt = ((i + j) & 1) != 0;
			const FLinearColor Col = Alt ? FLinearColor(0.085f, 0.095f, 0.125f) : FLinearColor(0.105f, 0.115f, 0.150f);
			StaticB.Quad(Wp(X0, Y0, 0), Wp(X1, Y0, 0), Wp(X1, Y1, 0), Wp(X0, Y1, 0), Col);
		}
	// glass zones (x, y, w, h) tint
	for (const auto& g : B.glass)
		StaticB.Quad(Wp(g.x1, g.y1, 0.4f), Wp(g.x1 + g.x2, g.y1, 0.4f), Wp(g.x1 + g.x2, g.y1 + g.y2, 0.4f), Wp(g.x1, g.y1 + g.y2, 0.4f), FLinearColor(0.10f, 0.32f, 0.40f));

	auto AddWall = [&](const LM::Seg4& S, bool bBorder)
	{
		const double Cx = (S.x1 + S.x2) * 0.5, Cy = (S.y1 + S.y2) * 0.5;
		const double Dx = S.x2 - S.x1, Dy = S.y2 - S.y1;
		const float Len = static_cast<float>(std::hypot(Dx, Dy));
		const float Hw = bBorder ? 7.f : 4.5f;
		const float Ht = bBorder ? 46.f : 40.f;
		const float Ext = bBorder ? Hw : 0.f;
		const FLinearColor Brick = bBorder ? FLinearColor(0.34f, 0.17f, 0.13f) : FLinearColor(0.42f, 0.22f, 0.16f);
		const float Yaw = YawOf(std::atan2(Dy, Dx));
		StaticB.Box(Wp(Cx, Cy, Ht * 0.5f), Len * 0.5f + Ext, Hw, Ht * 0.5f, Yaw, Brick);
		StaticB.Box(Wp(Cx, Cy, Ht + 1.f), Len * 0.5f + Ext, Hw * 0.6f, 1.f, Yaw, Brick * 1.35f);
	};
	for (int32 i = 0; i < 4; i++) AddWall(LM::BORDERS[i], true);
	for (const auto& w : B.walls) AddWall(w, false);

	StaticB.Upload(StaticMesh, 0);
}

void ALMGameActor::RebuildDynamic()
{
	DynB.Reset();
	const float Pulse = 0.5f + 0.5f * FMath::Sin(Time * 6.f);

	// emitter
	DynB.Cyl(Wp(B.ex, B.ey, 0), 14.f, 22.f, 14, FLinearColor(0.55f, 0.58f, 0.66f));
	DynB.Disc(Wp(B.ex, B.ey, 23.f), 9.f, 14, FLinearColor(1.f, 0.95f, 0.7f));

	// floor light pools + beams
	for (const auto& Poly : R.polys)
	{
		const FLinearColor Bc = BeamColor(Poly.c);
		for (size_t k = 1; k < Poly.pts.size(); k++)
		{
			const FVector A = Wp(Poly.pts[k - 1].x, Poly.pts[k - 1].y), Bp = Wp(Poly.pts[k].x, Poly.pts[k].y);
			DynB.Ribbon(A, Bp, 34.f, 0.5f, Bc * 0.14f);
			DynB.Ribbon(A, Bp, 18.f, 0.8f, Bc * 0.30f);
		}
	}

	// targets
	for (size_t i = 0; i < B.T.size(); i++)
	{
		const LM::Target& t = B.T[i];
		FLinearColor Lit = t.c ? BeamColor(t.c) : FLinearColor(1.f, 0.85f, 0.35f);
		const FLinearColor Dim = t.c ? BeamColor(t.c) * 0.22f : FLinearColor(0.30f, 0.32f, 0.42f);
		const float V = FMath::Clamp(t.v, 0.f, 1.f);
		const FLinearColor Col = Dim + (Lit - Dim) * V;
		DynB.Cyl(Wp(t.x, t.y, 0), 21.f, 5.f, 18, FLinearColor(0.16f, 0.17f, 0.22f));
		DynB.Dome(Wp(t.x, t.y, 5.f), 15.f + 2.f * V, Col);
		if (V > 0.05f) DynB.Ring(Wp(t.x, t.y, 6.f), 25.f + 3.f * Pulse, 3.f, 22, Lit * V);
	}

	// mirrors / prisms
	for (size_t i = 0; i < B.els.size(); i++)
	{
		const LM::Element& e = B.els[i];
		const bool bSel = static_cast<int32>(i) == Sel && !e.fixed;
		if (e.prism)
		{
			DynB.Cyl(Wp(e.x, e.y, 0), 22.f, 34.f, 6, bSel ? FLinearColor(0.75f, 0.95f, 1.f) : FLinearColor(0.45f, 0.75f, 0.9f));
			continue;
		}
		FLinearColor Col = e.fixed ? FLinearColor(0.50f, 0.56f, 0.66f) : FLinearColor(0.70f, 0.86f, 1.00f);
		if (e.split) Col = e.fixed ? FLinearColor(0.70f, 0.50f, 0.85f) : FLinearColor(0.90f, 0.70f, 1.00f);
		if (bSel) Col = FLinearColor(1.f, 0.90f, 0.55f);
		const float Len = static_cast<float>(e.len);
		DynB.Cyl(Wp(e.x, e.y, 0), 6.f, 3.f, 8, FLinearColor(0.2f, 0.22f, 0.28f));
		DynB.Box(Wp(e.x, e.y, 20.f), Len, 2.5f, 18.f, YawOf(e.a), Col);
	}

	// selection helpers (free mode)
	if (PlayMode == 1 && Screen == ELMScreen::Play && Sel >= 0 && Sel < static_cast<int32>(B.els.size()))
	{
		const LM::Element& e = B.els[Sel];
		const double Hx = e.x + std::cos(e.a - PI / 2) * 52, Hy = e.y + std::sin(e.a - PI / 2) * 52;
		DynB.Ribbon(Wp(e.x, e.y), Wp(Hx, Hy), 2.5f, 2.f, FLinearColor(1.f, 0.6f, 0.2f) * 0.8f);
		DynB.Disc(Wp(Hx, Hy, 3.f), 11.f, 16, FLinearColor(1.f, 0.55f, 0.1f));
		DynB.Ring(Wp(e.x, e.y, 2.f), 30.f, 2.5f, 24, FLinearColor(1.f, 0.85f, 0.4f));
	}

	// beams on top
	for (const auto& Poly : R.polys)
	{
		const FLinearColor Bc = BeamColor(Poly.c);
		for (size_t k = 1; k < Poly.pts.size(); k++)
		{
			const FVector A = Wp(Poly.pts[k - 1].x, Poly.pts[k - 1].y), Bp = Wp(Poly.pts[k].x, Poly.pts[k].y);
			DynB.Ribbon(A, Bp, 9.f, BeamZ - 1.f, Bc * 0.55f);
			DynB.Ribbon(A, Bp, 4.f, BeamZ, FLinearColor(1.f, 1.f, 1.f) * 0.5f + Bc * 0.5f);
		}
		for (size_t k = 1; k < Poly.pts.size(); k++)
		{
			if (Poly.pts[k].kind == 'e')
				DynB.Disc(Wp(Poly.pts[k].x, Poly.pts[k].y, BeamZ + 1.f), 5.f + 2.f * Pulse, 10, FLinearColor(1.f, 1.f, 1.f));
		}
	}

	// hints
	if (HintT > 0.f)
	{
		const float F = FMath::Clamp(HintT, 0.f, 1.f);
		const FLinearColor Y = FLinearColor(1.f, 0.85f, 0.2f) * F;
		auto GhostOf = [&](double X, double Yy, double A, double Len, bool bPrism)
		{
			if (bPrism) { DynB.Ring(Wp(X, Yy, 40.f), 24.f, 3.f, 20, Y); return; }
			const double Dx = std::cos(A) * (Len + 6), Dy = std::sin(A) * (Len + 6);
			DynB.Ribbon(Wp(X - Dx, Yy - Dy), Wp(X + Dx, Yy + Dy), 5.f, 42.f, Y);
			DynB.Ring(Wp(X, Yy, 41.f), 26.f + 4.f * Pulse, 2.5f, 20, Y);
		};
		if (PlayMode == 0)
		{
			if (HintEl >= 0 && HintEl < static_cast<int32>(B.els.size()))
			{
				const LM::Element& e = B.els[HintEl];
				GhostOf(e.x, e.y, e.sa, e.len, false);
			}
		}
		else
		{
			for (const auto& e : B.els) if (!e.fixed) GhostOf(e.sx, e.sy, e.sa, e.len, e.prism);
		}
	}

	// particles
	for (const FLMParticle& P : Particles)
	{
		const float K = FMath::Clamp(P.Life / P.MaxLife, 0.f, 1.f);
		const float S = P.Size * (0.4f + 0.6f * K);
		const FLinearColor C = P.Col * K;
		DynB.Quad(P.Pos + FVector(-S, -S, 0), P.Pos + FVector(S, -S, 0), P.Pos + FVector(S, S, 0), P.Pos + FVector(-S, S, 0), C);
	}

	DynB.Upload(DynMesh, 0);
}

void ALMGameActor::UpdateCamera(float Dt)
{
	if (!Cam) return;
	APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0);
	if (!PC) return;
	if (!bViewSet) { PC->SetViewTarget(Cam); bViewSet = true; }

	const float Target = Screen == ELMScreen::Menu ? 40.f : PitchModes[CamMode];
	Pitch += (Target - Pitch) * FMath::Min(1.f, Dt * 4.f);

	int32 Vw = 0, Vh = 0;
	PC->GetViewportSize(Vw, Vh);
	const float Aspect = Vh > 0 ? static_cast<float>(Vw) / static_cast<float>(Vh) : 0.5f;
	const float HFov = FMath::DegreesToRadians(60.f);
	const float VFov = 2.f * FMath::Atan(FMath::Tan(HFov * 0.5f) / FMath::Max(0.3f, Aspect));
	const float FitW = (288.f * 1.15f) / FMath::Tan(HFov * 0.5f);
	const float FitH = (280.f * 1.35f) / FMath::Tan(VFov * 0.5f);
	const float Dist = FMath::Max(FitW, FitH);

	const float P = FMath::DegreesToRadians(Pitch);
	const FVector Center(0.f, 0.f, 0.f);
	const FVector Loc = Center + FVector(-FMath::Cos(P) * Dist, 0.f, FMath::Sin(P) * Dist);
	Cam->SetActorLocationAndRotation(Loc, FRotator(-Pitch, 0.f, 0.f));
}

void ALMGameActor::Tick(float Dt)
{
	Super::Tick(Dt);
	Dt = FMath::Min(Dt, 0.05f);
	Time += Dt;
	if (TitleTapT > 0) TitleTapT -= Dt;
	if (ToastT > 0) ToastT -= Dt;

	if (Screen == ELMScreen::Play)
	{
		bool bSettled = true;
		if (B.tap)
		{
			for (auto& e : B.els)
			{
				if (e.fixed) continue;
				const double D = e.ta - e.a, St = Dt * 8.0;
				if (std::fabs(D) > 1e-3)
				{
					bSettled = false;
					if (std::fabs(D) <= St) e.a = e.ta; else e.a += D > 0 ? St : -St;
				}
			}
		}
		LM::traceBoard(B, R);
		for (size_t i = 0; i < B.T.size(); i++)
		{
			const float Tg = R.hit[i] ? 1.f : 0.f;
			B.T[i].v += (Tg - B.T[i].v) * FMath::Min(1.f, Dt * 5.f);
		}
		const bool bSolved = R.hitCount == static_cast<int>(B.T.size()) && bSettled;
		if (!bWon && !bLost && bSolved && !Drag)
		{
			WinT += Dt;
			if (WinT > 0.8f) DoWin();
		}
		else if (!bWon) WinT = 0;

		if (B.tap && !bWon && !bLost && bSettled && !bSolved && Moves >= Limit)
		{
			LoseT += Dt;
			if (LoseT > 0.8f) { bLost = true; CelebT = 0.f; }
		}
		else if (!bLost) LoseT = 0;

		if (bWon || bLost) CelebT += Dt;
		if (HintT > 0) HintT -= Dt;
	}
	else
	{
		LM::traceBoard(B, R);
	}

	for (int32 i = Particles.Num() - 1; i >= 0; i--)
	{
		FLMParticle& P = Particles[i];
		P.Life -= Dt;
		if (P.Life <= 0.f) { Particles.RemoveAtSwap(i); continue; }
		P.Vel.Z -= 260.f * Dt;
		P.Pos += P.Vel * Dt;
		if (P.Pos.Z < 1.f) { P.Pos.Z = 1.f; P.Vel.Z *= -0.4f; P.Vel.X *= 0.7f; P.Vel.Y *= 0.7f; }
	}

	UpdateCamera(Dt);
	RebuildDynamic();
}
