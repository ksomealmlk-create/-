#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LMLogic.h"
#include "LMMesh.h"
#include "LMGameActor.generated.h"

class UProceduralMeshComponent;
class UMaterialInterface;
class ACameraActor;

UENUM()
enum class ELMScreen : uint8 { Menu, Play };

struct FLMParticle
{
	FVector Pos, Vel;
	FLinearColor Col;
	float Life, MaxLife, Size;
};

// Owns the whole game: state, rules (LM:: logic port), 3D scene and camera.
UCLASS()
class ALMGameActor : public AActor
{
	GENERATED_BODY()

public:
	ALMGameActor();
	virtual void BeginPlay() override;
	virtual void Tick(float Dt) override;

	// ---------- state read by the HUD ----------
	ELMScreen Screen = ELMScreen::Menu;
	int32 PlayMode = 0;        // 0 = challenge (tap to rotate), 1 = free (drag)
	int32 MenuTab = 0;
	int32 LevelIndex = 0;
	int32 Moves = 0;
	int32 Limit = 0;
	bool bWon = false, bLost = false;
	float CelebT = -1.f;
	float ToastT = 0.f;
	FString ToastText;
	int32 CamMode = 0;
	int32 MenuSerial = 0;
	bool bArabic = true;
	LM::Board B;
	LM::TraceResult R;
	TArray<int32> StarsFree, StarsChal;

	// ---------- queries ----------
	int32 LevelCount(int32 Mode) const;
	bool Unlocked(int32 Mode, int32 Index) const;
	int32 StarsOf(int32 Mode, int32 Index) const;
	FString TierName(int32 Level1Based) const;
	FString LevelLabel(int32 Mode, int32 Index) const;
	FString Tr(const TCHAR* Ar, const TCHAR* En) const { return bArabic ? FString(Ar) : FString(En); }

	// ---------- actions ----------
	void StartLevel(int32 Index, int32 Mode);
	void ShowMenu();
	void ActionHint();
	void ActionReset();
	void ActionNext();
	void ActionCamera();
	void ToggleLanguage();
	void TitleTap();
	void ShowToast(const FString& S) { ToastText = S; ToastT = 2.2f; }

	// ---------- touch input (screen pixels), forwarded by the PlayerController ----------
	void PlayDown(const FVector2D& P);
	void PlayMove(const FVector2D& P);
	void PlayUp(const FVector2D& P, bool bWasTap);

private:
	UPROPERTY() USceneComponent* Root = nullptr;
	UPROPERTY() UProceduralMeshComponent* StaticMesh = nullptr;
	UPROPERTY() UProceduralMeshComponent* DynMesh = nullptr;
	UPROPERTY() UMaterialInterface* VertexMat = nullptr;
	UPROPERTY() ACameraActor* Cam = nullptr;

	FLMMesh StaticB, DynB;
	TArray<FLMParticle> Particles;

	int32 Sel = -1, Drag = 0, HintEl = -1;
	bool bChanged = false;
	double OffX = 0, OffY = 0;
	float WinT = 0, LoseT = 0, HintT = 0, Time = 0, TitleTapT = 0;
	int32 TitleTaps = 0;
	float Pitch = 40.f;
	bool bViewSet = false;

	void BuildStatic();
	void RebuildDynamic();
	void UpdateCamera(float Dt);
	void DoWin();
	void Burst(const FVector& P, const FLinearColor& Col, int32 N, float Speed);
	bool ScreenToPlay(const FVector2D& S, double& Px, double& Py) const;
	void LoadSave();
	void SaveGame() const;
	int32& StarRef(int32 Mode, int32 Index);
};
