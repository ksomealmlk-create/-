@echo off
REM Local APK build on Windows. Edit UE_ROOT to your Unreal Engine 5.4 folder.
set UE_ROOT=C:\Program Files\Epic Games\UE_5.4
set PROJ=%~dp0LightMaze3D.uproject
"%UE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="%PROJ%" -noP4 -utf8output ^
  -platform=Android -targetplatform=Android -cookflavor=ASTC -clientconfig=Development ^
  -build -cook -map=/Engine/Maps/Entry -stage -pak -package -archive -archivedirectory="%~dp0Build"
echo.
echo APK is in: %~dp0Build\Android_ASTC
pause
