# مرايا الضوء 3D — نسخة Unreal Engine 5.4

إعادة بناء للعبة الأصلية (C++ / OpenGL ES) على محرك **Unreal Engine 5.4** بكود C++ كامل بدون أي ملفات Blueprint أو أصول ثنائية.

## شنو منقول من اللعبة الأصلية
- نفس منطق الشعاع والمرايا (انعكاس، مقسّم، منشور RGB) — منقول حرفياً في `Source/LightMaze3D/LMLogic.cpp`.
- **200 مرحلة تحدي** (نقر لتدوير المرآة 45°، حركات محدودة) + **36 مرحلة حرة** (سحب المرايا).
- تم فحص المنطق: كل مراحل التحدي الـ200 والحرة الـ36 قابلة للحل بالكود المنقول.
- نجوم 1-3، قفل المراحل، حفظ التقدم تلقائياً، تلميح، تغيير زاوية الكاميرا (3 زوايا).
- فتح كل المراحل للتجربة: اضغط عنوان اللعبة 7 مرات.
- واجهة عربية/إنجليزية (زر AR/EN أعلى القائمة).

## شنو مختلف
- الرسم: مجسمات ملونة مبنية بالكود (ProceduralMesh) بإضاءة مخبوزة + Bloom، وليس نفس الشيدرز الأصلية (ظلال ناعمة، غبار، زجاج حقيقي غير موجودين).
- لا يوجد صوت حالياً.
- الواجهة مرسومة بـ Canvas HUD. إذا ما ظهر الخط العربي صح بجهازك، اضغط EN.

## ⚠️ ملاحظة مهمة
هذا المشروع **لم أقدر أجرّبه داخل Unreal** (ما عندي المحرك هنا). منطق اللعبة مفحوص ويشتغل، لكن كود Unreal نفسه مكتوب بدون تجميع فعلي، فممكن تطلع أخطاء صغيرة عند أول Build — أرسل لي نص الخطأ وأصلحه.

## الطريقة المضمونة: بناء APK من جهازك
1. ثبّت **Unreal Engine 5.4** من Epic Games Launcher مع خيار **Android** (Platforms).
2. ثبّت Android Studio ثم شغّل `Engine/Extras/Android/SetupAndroid` (أو من داخل المحرك: Project Settings > Platforms > Android > Configure + SDK).
3. فك الضغط، كليك يمين على `LightMaze3D.uproject` > **Generate Visual Studio project files** (أو افتحه مباشرة).
4. افتح المشروع، ثم من القائمة: **Platforms > Android > Package Project**.
   - أو شغّل `Package_Android.bat` (Windows) / `Package_Android.sh` (Linux/Mac) بعد تعديل مسار `UE_ROOT`.
5. الـ APK يطلع داخل `Build/Android_ASTC`.

## البناء على GitHub
Unreal **غير موجود** على سيرفرات GitHub المجانية، ومصدره متاح فقط لحسابات مربوطة بـ Epic Games. لذلك الملف `.github/workflows/build-apk.yml` فيه خيارين (تجريبيين، غير مجرّبين):
- **self-hosted runner** (الأضمن): جهازك أو سيرفر عليه UE 5.4 + Android SDK. حدّد متغير المستودع `UE_ROOT`.
- **Docker** على سيرفر GitHub: يحتاج Secrets باسم `GHCR_USER` و `GHCR_TOKEN` من حساب مربوط بـ Epic، والصورة ضخمة وقد تفشل بسبب مساحة القرص.

التشغيل: تبويب **Actions > Build APK (Unreal) > Run workflow** واختر النوع.

## هيكل المشروع
- `Source/LightMaze3D/LMLogic.*` منطق اللعبة + `LMLevels.inc` و`LMChal.inc` بيانات المراحل
- `LMGameActor.*` حالة اللعبة والمشهد ثلاثي الأبعاد والكاميرا واللمس
- `LMHUD.*` القوائم والواجهة، `LMPlayerController.*` اللمس، `LMMesh.*` بناء المجسمات
- `Config/DefaultEngine.ini` إعدادات أندرويد (اسم الحزمة، عمودي، OpenGL ES 3.1)
- الخريطة المستخدمة `/Engine/Maps/Entry` (فارغة)، واللعبة تبني كل شي بالكود.
